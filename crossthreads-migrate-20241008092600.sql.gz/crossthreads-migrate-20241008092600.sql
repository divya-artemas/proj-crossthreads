# WordPress MySQL database migration
#
# Generated: Tuesday 8. October 2024 09:26 UTC
# Hostname: localhost
# Database: `crossthreads`
# URL: //localhost/crossthreads/site
# Path: E:\\XAMPP\\htdocs\\crossthreads\\site
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wc_admin_note_actions, wp_wc_admin_notes, wp_wc_category_lookup, wp_wc_customer_lookup, wp_wc_download_log, wp_wc_order_addresses, wp_wc_order_coupon_lookup, wp_wc_order_operational_data, wp_wc_order_product_lookup, wp_wc_order_stats, wp_wc_order_tax_lookup, wp_wc_orders, wp_wc_orders_meta, wp_wc_product_attributes_lookup, wp_wc_product_download_directories, wp_wc_product_meta_lookup, wp_wc_rate_limits, wp_wc_reserved_stock, wp_wc_tax_rate_classes, wp_wc_webhooks, wp_woocommerce_api_keys, wp_woocommerce_attribute_taxonomies, wp_woocommerce_downloadable_product_permissions, wp_woocommerce_log, wp_woocommerce_order_itemmeta, wp_woocommerce_order_items, wp_woocommerce_payment_tokenmeta, wp_woocommerce_payment_tokens, wp_woocommerce_sessions, wp_woocommerce_shipping_zone_locations, wp_woocommerce_shipping_zone_methods, wp_woocommerce_shipping_zones, wp_woocommerce_tax_rate_locations, wp_woocommerce_tax_rates, wp_yoast_indexable, wp_yoast_indexable_hierarchy, wp_yoast_migrations, wp_yoast_primary_term, wp_yoast_seo_links
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post, product
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT 10,
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook_status_scheduled_date_gmt` (`hook`(163),`status`,`scheduled_date_gmt`),
  KEY `status_scheduled_date_gmt` (`status`,`scheduled_date_gmt`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=289 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `priority`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(281, 'action_scheduler/migration_hook', 'complete', '2024-10-01 07:49:49', '2024-10-01 07:49:49', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1727768989;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1727768989;s:19:"scheduled_timestamp";i:1727768989;s:9:"timestamp";i:1727768989;}', 1, 1, '2024-10-01 07:50:56', '2024-10-01 07:50:56', 0, NULL),
(282, 'woocommerce_cleanup_draft_orders', 'complete', '2024-10-01 07:49:06', '2024-10-01 07:49:06', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1727768946;s:18:"\0*\0first_timestamp";i:1727768946;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1727768946;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1727768946;s:15:"first_timestamp";i:1727768946;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1727768946;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-10-01 07:50:05', '2024-10-01 07:50:05', 0, NULL),
(283, 'woocommerce_cleanup_draft_orders', 'complete', '2024-10-02 07:50:05', '2024-10-02 07:50:05', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1727855405;s:18:"\0*\0first_timestamp";i:1727768946;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1727855405;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1727855405;s:15:"first_timestamp";i:1727768946;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1727855405;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-10-08 09:03:15', '2024-10-08 09:03:15', 0, NULL),
(284, 'woocommerce_update_marketplace_suggestions', 'complete', '2024-10-01 08:05:24', '2024-10-01 08:05:24', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1727769924;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1727769924;s:19:"scheduled_timestamp";i:1727769924;s:9:"timestamp";i:1727769924;}', 2, 1, '2024-10-01 08:07:38', '2024-10-01 08:07:38', 0, NULL),
(285, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'failed', '2024-10-01 08:12:34', '2024-10-01 08:12:34', 10, '[]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 2, 1, '2024-10-01 08:12:45', '2024-10-01 08:12:45', 0, NULL),
(286, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2024-10-01 08:12:40', '2024-10-01 08:12:40', 10, '[287,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1727770360;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1727770360;s:19:"scheduled_timestamp";i:1727770360;s:9:"timestamp";i:1727770360;}', 3, 1, '2024-10-01 08:12:46', '2024-10-01 08:12:46', 0, NULL),
(287, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2024-10-01 09:15:08', '2024-10-01 09:15:08', 10, '[287,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1727774108;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1727774108;s:19:"scheduled_timestamp";i:1727774108;s:9:"timestamp";i:1727774108;}', 3, 1, '2024-10-01 09:16:28', '2024-10-01 09:16:28', 0, NULL),
(288, 'woocommerce_cleanup_draft_orders', 'pending', '2024-10-09 09:03:15', '2024-10-09 09:03:15', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728464595;s:18:"\0*\0first_timestamp";i:1727768946;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728464595;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728464595;s:15:"first_timestamp";i:1727768946;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728464595;s:19:"interval_in_seconds";i:86400;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, ''),
(3, 'woocommerce-db-updates') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 281, 'action created', '2024-10-01 07:48:50', '2024-10-01 07:48:50'),
(2, 282, 'action created', '2024-10-01 07:49:06', '2024-10-01 07:49:06'),
(3, 282, 'action started via WP Cron', '2024-10-01 07:50:05', '2024-10-01 07:50:05'),
(4, 282, 'action complete via WP Cron', '2024-10-01 07:50:05', '2024-10-01 07:50:05'),
(5, 283, 'action created', '2024-10-01 07:50:06', '2024-10-01 07:50:06'),
(6, 281, 'action started via WP Cron', '2024-10-01 07:50:54', '2024-10-01 07:50:54'),
(7, 281, 'action complete via WP Cron', '2024-10-01 07:50:55', '2024-10-01 07:50:55'),
(8, 284, 'action created', '2024-10-01 08:05:24', '2024-10-01 08:05:24'),
(9, 284, 'action started via WP Cron', '2024-10-01 08:07:30', '2024-10-01 08:07:30'),
(10, 284, 'action complete via WP Cron', '2024-10-01 08:07:38', '2024-10-01 08:07:38'),
(11, 285, 'action created', '2024-10-01 08:12:34', '2024-10-01 08:12:34'),
(12, 286, 'action created', '2024-10-01 08:12:39', '2024-10-01 08:12:39'),
(13, 285, 'action started via Async Request', '2024-10-01 08:12:45', '2024-10-01 08:12:45'),
(14, 285, 'action failed via Async Request: Scheduled action for woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications will not be executed as no callbacks are registered.', '2024-10-01 08:12:45', '2024-10-01 08:12:45'),
(15, 286, 'action started via Async Request', '2024-10-01 08:12:45', '2024-10-01 08:12:45'),
(16, 286, 'action complete via Async Request', '2024-10-01 08:12:46', '2024-10-01 08:12:46'),
(17, 287, 'action created', '2024-10-01 09:15:07', '2024-10-01 09:15:07'),
(18, 287, 'action started via WP Cron', '2024-10-01 09:16:26', '2024-10-01 09:16:26'),
(19, 287, 'action complete via WP Cron', '2024-10-01 09:16:28', '2024-10-01 09:16:28'),
(20, 283, 'action started via WP Cron', '2024-10-08 09:03:14', '2024-10-08 09:03:14'),
(21, 283, 'action complete via WP Cron', '2024-10-08 09:03:15', '2024-10-08 09:03:15'),
(22, 288, 'action created', '2024-10-08 09:03:15', '2024-10-08 09:03:15') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-09-13 15:51:53', '2024-09-13 15:51:53', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1516 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'cron', 'a:25:{i:1728379549;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1728380923;a:1:{s:20:"jetpack_clean_nonces";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1728380926;a:1:{s:33:"wc_admin_process_orders_milestone";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1728380980;a:1:{s:29:"wc_admin_unsnooze_admin_notes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1728381114;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1728381798;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1728384510;a:1:{s:24:"woocommerce_cleanup_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728384511;a:1:{s:31:"woocommerce_cleanup_rate_limits";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728395310;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728402714;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728402761;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728402767;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728403039;a:2:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728406308;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728408108;a:1:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728409908;a:1:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728432000;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728460111;a:1:{s:14:"wc_admin_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728460120;a:1:{s:33:"woocommerce_cleanup_personal_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728460121;a:1:{s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728460124;a:1:{s:20:"jetpack_v2_heartbeat";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728662012;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1728748314;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1729064971;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"fifteendays";s:4:"args";a:0:{}s:8:"interval";i:1296000;}}}s:7:"version";i:2;}', 'auto'),
(2, 'siteurl', 'http://localhost/crossthreads/site', 'on'),
(3, 'home', 'http://localhost/crossthreads/site', 'on'),
(4, 'blogname', 'Crossthreads', 'on'),
(5, 'blogdescription', '', 'on'),
(6, 'users_can_register', '0', 'on'),
(7, 'admin_email', 'divya@artemasdigital.com', 'on'),
(8, 'start_of_week', '1', 'on'),
(9, 'use_balanceTags', '0', 'on'),
(10, 'use_smilies', '1', 'on'),
(11, 'require_name_email', '1', 'on'),
(12, 'comments_notify', '1', 'on'),
(13, 'posts_per_rss', '10', 'on'),
(14, 'rss_use_excerpt', '0', 'on'),
(15, 'mailserver_url', 'mail.example.com', 'on'),
(16, 'mailserver_login', 'login@example.com', 'on'),
(17, 'mailserver_pass', 'password', 'on'),
(18, 'mailserver_port', '110', 'on'),
(19, 'default_category', '1', 'on'),
(20, 'default_comment_status', 'open', 'on'),
(21, 'default_ping_status', 'open', 'on'),
(22, 'default_pingback_flag', '0', 'on'),
(23, 'posts_per_page', '10', 'on'),
(24, 'date_format', 'F j, Y', 'on'),
(25, 'time_format', 'g:i a', 'on'),
(26, 'links_updated_date_format', 'F j, Y g:i a', 'on'),
(27, 'comment_moderation', '0', 'on'),
(28, 'moderation_notify', '1', 'on'),
(29, 'permalink_structure', '/%postname%/', 'on'),
(30, 'rewrite_rules', 'a:208:{s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:21:"^wc/file/transient/?$";s:33:"index.php?wc-transient-file-name=";s:24:"^wc/file/transient/(.+)$";s:44:"index.php?wc-transient-file-name=$matches[1]";s:7:"shop/?$";s:27:"index.php?post_type=product";s:37:"shop/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:32:"shop/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:24:"shop/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:8:"blogs/?$";s:25:"index.php?post_type=blogs";s:38:"blogs/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=blogs&feed=$matches[1]";s:33:"blogs/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=blogs&feed=$matches[1]";s:25:"blogs/page/([0-9]{1,})/?$";s:43:"index.php?post_type=blogs&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:43:"category/(.+?)/wc/file/transient(/(.*))?/?$";s:65:"index.php?category_name=$matches[1]&wc/file/transient=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:40:"tag/([^/]+)/wc/file/transient(/(.*))?/?$";s:55:"index.php?tag=$matches[1]&wc/file/transient=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"product-category/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:28:"product-tag/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"product/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:44:"product/([^/]+)/wc/file/transient(/(.*))?/?$";s:59:"index.php?product=$matches[1]&wc/file/transient=$matches[3]";s:39:"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:61:"product/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"blogs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"blogs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"blogs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"blogs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"blogs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"blogs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"blogs/([^/]+)/embed/?$";s:38:"index.php?blogs=$matches[1]&embed=true";s:26:"blogs/([^/]+)/trackback/?$";s:32:"index.php?blogs=$matches[1]&tb=1";s:46:"blogs/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?blogs=$matches[1]&feed=$matches[2]";s:41:"blogs/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?blogs=$matches[1]&feed=$matches[2]";s:34:"blogs/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?blogs=$matches[1]&paged=$matches[2]";s:41:"blogs/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?blogs=$matches[1]&cpage=$matches[2]";s:31:"blogs/([^/]+)/wc-api(/(.*))?/?$";s:46:"index.php?blogs=$matches[1]&wc-api=$matches[3]";s:42:"blogs/([^/]+)/wc/file/transient(/(.*))?/?$";s:57:"index.php?blogs=$matches[1]&wc/file/transient=$matches[3]";s:37:"blogs/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:48:"blogs/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:48:"blogs/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:59:"blogs/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:30:"blogs/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?blogs=$matches[1]&page=$matches[2]";s:22:"blogs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"blogs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"blogs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"blogs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"blogs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"blogs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:28:"wc/file/transient(/(.*))?/?$";s:40:"index.php?&wc/file/transient=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:37:"comments/wc/file/transient(/(.*))?/?$";s:40:"index.php?&wc/file/transient=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:40:"search/(.+)/wc/file/transient(/(.*))?/?$";s:53:"index.php?s=$matches[1]&wc/file/transient=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:43:"author/([^/]+)/wc/file/transient(/(.*))?/?$";s:63:"index.php?author_name=$matches[1]&wc/file/transient=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc/file/transient(/(.*))?/?$";s:93:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc/file/transient=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:52:"([0-9]{4})/([0-9]{1,2})/wc/file/transient(/(.*))?/?$";s:77:"index.php?year=$matches[1]&monthnum=$matches[2]&wc/file/transient=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:39:"([0-9]{4})/wc/file/transient(/(.*))?/?$";s:56:"index.php?year=$matches[1]&wc/file/transient=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:36:"(.?.+?)/wc/file/transient(/(.*))?/?$";s:60:"index.php?pagename=$matches[1]&wc/file/transient=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:53:".?.+?/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:36:"([^/]+)/wc/file/transient(/(.*))?/?$";s:56:"index.php?name=$matches[1]&wc/file/transient=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:53:"[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'on'),
(31, 'hack_file', '0', 'on'),
(32, 'blog_charset', 'UTF-8', 'on'),
(33, 'moderation_keys', '', 'off'),
(34, 'active_plugins', 'a:7:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:33:"classic-editor/classic-editor.php";i:2;s:39:"copy-delete-posts/copy-delete-posts.php";i:3;s:38:"post-duplicator/m4c-postduplicator.php";i:4;s:27:"woocommerce/woocommerce.php";i:5;s:24:"wordpress-seo/wp-seo.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'on'),
(35, 'category_base', '', 'on'),
(36, 'ping_sites', 'http://rpc.pingomatic.com/', 'on'),
(37, 'comment_max_links', '2', 'on'),
(38, 'gmt_offset', '0', 'on'),
(39, 'default_email_category', '1', 'on'),
(40, 'recently_edited', '', 'off'),
(41, 'template', 'crossthreads', 'on'),
(42, 'stylesheet', 'crossthreads', 'on'),
(43, 'comment_registration', '0', 'on'),
(44, 'html_type', 'text/html', 'on'),
(45, 'use_trackback', '0', 'on'),
(46, 'default_role', 'subscriber', 'on'),
(47, 'db_version', '57155', 'on'),
(48, 'uploads_use_yearmonth_folders', '1', 'on'),
(49, 'upload_path', '', 'on'),
(50, 'blog_public', '0', 'on'),
(51, 'default_link_category', '2', 'on'),
(52, 'show_on_front', 'page', 'on'),
(53, 'tag_base', '', 'on'),
(54, 'show_avatars', '1', 'on'),
(55, 'avatar_rating', 'G', 'on'),
(56, 'upload_url_path', '', 'on'),
(57, 'thumbnail_size_w', '150', 'on'),
(58, 'thumbnail_size_h', '150', 'on'),
(59, 'thumbnail_crop', '1', 'on'),
(60, 'medium_size_w', '300', 'on'),
(61, 'medium_size_h', '300', 'on'),
(62, 'avatar_default', 'mystery', 'on'),
(63, 'large_size_w', '1024', 'on'),
(64, 'large_size_h', '1024', 'on'),
(65, 'image_default_link_type', 'none', 'on'),
(66, 'image_default_size', '', 'on'),
(67, 'image_default_align', '', 'on'),
(68, 'close_comments_for_old_posts', '0', 'on'),
(69, 'close_comments_days_old', '14', 'on'),
(70, 'thread_comments', '1', 'on'),
(71, 'thread_comments_depth', '5', 'on'),
(72, 'page_comments', '0', 'on'),
(73, 'comments_per_page', '50', 'on'),
(74, 'default_comments_page', 'newest', 'on'),
(75, 'comment_order', 'asc', 'on'),
(76, 'sticky_posts', 'a:0:{}', 'on'),
(77, 'widget_categories', 'a:0:{}', 'on'),
(78, 'widget_text', 'a:0:{}', 'on'),
(79, 'widget_rss', 'a:0:{}', 'on'),
(80, 'uninstall_plugins', 'a:2:{s:24:"wordpress-seo/wp-seo.php";s:14:"__return_false";s:39:"copy-delete-posts/copy-delete-posts.php";a:2:{i:0;s:15:"Account\\Account";i:1;s:25:"onUninstallPluginListener";}}', 'off'),
(81, 'timezone_string', '', 'on'),
(82, 'page_for_posts', '0', 'on'),
(83, 'page_on_front', '5', 'on'),
(84, 'default_post_format', '0', 'on'),
(85, 'link_manager_enabled', '0', 'on'),
(86, 'finished_splitting_shared_terms', '1', 'on'),
(87, 'site_icon', '0', 'on'),
(88, 'medium_large_size_w', '768', 'on'),
(89, 'medium_large_size_h', '0', 'on'),
(90, 'wp_page_for_privacy_policy', '3', 'on'),
(91, 'show_comments_cookies_opt_in', '1', 'on'),
(92, 'admin_email_lifespan', '1741794708', 'on'),
(93, 'disallowed_keys', '', 'off'),
(94, 'comment_previously_approved', '1', 'on'),
(95, 'auto_plugin_theme_update_emails', 'a:0:{}', 'off'),
(96, 'auto_update_core_dev', 'enabled', 'on'),
(97, 'auto_update_core_minor', 'enabled', 'on'),
(98, 'auto_update_core_major', 'enabled', 'on'),
(99, 'wp_force_deactivated_plugins', 'a:0:{}', 'on'),
(100, 'wp_attachment_pages_enabled', '0', 'on') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'initial_db_version', '57155', 'on'),
(102, 'wp_user_roles', 'a:9:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:115:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:38:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;s:23:"view_site_health_checks";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:92:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"edit_theme_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'auto'),
(103, 'fresh_site', '0', 'auto'),
(104, 'user_count', '1', 'off'),
(105, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'auto'),
(106, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'auto'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(124, 'recovery_keys', 'a:0:{}', 'auto'),
(147, 'can_compress_scripts', '1', 'on'),
(149, 'recently_activated', 'a:0:{}', 'auto'),
(150, 'acf_version', '5.9.5', 'auto'),
(159, 'finished_updating_comment_type', '1', 'auto'),
(162, 'yoast_migrations_free', 'a:1:{s:7:"version";s:4:"23.5";}', 'auto'),
(163, 'wpseo', 'a:105:{s:8:"tracking";b:0;s:16:"toggled_tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:0;s:40:"ignore_search_engines_discouraged_notice";b:0;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:20:"taxonomy_made_public";s:29:"indexables_indexing_completed";b:1;s:13:"index_now_key";s:0:"";s:7:"version";s:4:"23.5";s:16:"previous_version";s:4:"23.4";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:0;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:34:"inclusive_language_analysis_active";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:16:"enable_index_now";b:1;s:19:"enable_ai_generator";b:1;s:22:"ai_enabled_pre_default";b:0;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1726243039;s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:12:"/%postname%/";s:8:"home_url";s:34:"http://localhost/crossthreads/site";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:0:"";s:12:"tag_base_url";s:0:"";s:21:"custom_taxonomy_slugs";a:0:{}s:29:"enable_enhanced_slack_sharing";b:1;s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:28:"configuration_finished_steps";a:0:{}s:36:"dismiss_configuration_workout_notice";b:0;s:34:"dismiss_premium_deactivated_notice";b:0;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:1;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:18:"first_time_install";b:1;s:34:"should_redirect_after_install_free";b:0;s:34:"activation_redirect_timestamp_free";i:1726243043;s:18:"remove_feed_global";b:0;s:27:"remove_feed_global_comments";b:0;s:25:"remove_feed_post_comments";b:0;s:19:"remove_feed_authors";b:0;s:22:"remove_feed_categories";b:0;s:16:"remove_feed_tags";b:0;s:29:"remove_feed_custom_taxonomies";b:0;s:22:"remove_feed_post_types";b:0;s:18:"remove_feed_search";b:0;s:21:"remove_atom_rdf_feeds";b:0;s:17:"remove_shortlinks";b:0;s:21:"remove_rest_api_links";b:0;s:20:"remove_rsd_wlw_links";b:0;s:19:"remove_oembed_links";b:0;s:16:"remove_generator";b:0;s:20:"remove_emoji_scripts";b:0;s:24:"remove_powered_by_header";b:0;s:22:"remove_pingback_header";b:0;s:28:"clean_campaign_tracking_urls";b:0;s:16:"clean_permalinks";b:0;s:32:"clean_permalinks_extra_variables";s:0:"";s:14:"search_cleanup";b:0;s:20:"search_cleanup_emoji";b:0;s:23:"search_cleanup_patterns";b:0;s:22:"search_character_limit";i:50;s:20:"deny_search_crawling";b:0;s:21:"deny_wp_json_crawling";b:0;s:20:"deny_adsbot_crawling";b:0;s:19:"deny_ccbot_crawling";b:0;s:29:"deny_google_extended_crawling";b:0;s:20:"deny_gptbot_crawling";b:0;s:27:"redirect_search_pretty_urls";b:0;s:29:"least_readability_ignore_list";a:0:{}s:27:"least_seo_score_ignore_list";a:0:{}s:23:"most_linked_ignore_list";a:0:{}s:24:"least_linked_ignore_list";a:0:{}s:28:"indexables_page_reading_list";a:5:{i:0;b:0;i:1;b:0;i:2;b:0;i:3;b:0;i:4;b:0;}s:25:"indexables_overview_state";s:21:"dashboard-not-visited";s:28:"last_known_public_post_types";a:4:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:7:"product";i:3;s:5:"blogs";}s:28:"last_known_public_taxonomies";a:6:{i:0;s:8:"category";i:1;s:8:"post_tag";i:2;s:11:"post_format";i:3;s:11:"product_cat";i:4;s:11:"product_tag";i:5;s:22:"product_shipping_class";}s:23:"last_known_no_unindexed";a:4:{s:40:"wpseo_total_unindexed_post_type_archives";i:1728378204;s:31:"wpseo_unindexed_post_link_count";i:1728378206;s:31:"wpseo_unindexed_term_link_count";i:1728378207;s:35:"wpseo_total_unindexed_general_items";i:1728378204;}s:14:"new_post_types";a:1:{i:2;s:7:"product";}s:14:"new_taxonomies";a:3:{i:3;s:11:"product_cat";i:4;s:11:"product_tag";i:5;s:22:"product_shipping_class";}s:34:"show_new_content_type_notification";b:1;}', 'auto'),
(164, 'wpseo_titles', 'a:129:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:2:"»";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:22:"company_alternate_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:12:"%%sitename%%";s:25:"open_graph_frontpage_desc";s:0:"";s:26:"open_graph_frontpage_image";s:0:"";s:24:"publishing_principles_id";i:0;s:25:"ownership_funding_info_id";i:0;s:29:"actionable_feedback_policy_id";i:0;s:21:"corrections_policy_id";i:0;s:16:"ethics_policy_id";i:0;s:19:"diversity_policy_id";i:0;s:28:"diversity_staffing_report_id";i:0;s:15:"org-description";s:0:"";s:9:"org-email";s:0:"";s:9:"org-phone";s:0:"";s:14:"org-legal-name";s:0:"";s:17:"org-founding-date";s:0:"";s:20:"org-number-employees";s:0:"";s:10:"org-vat-id";s:0:"";s:10:"org-tax-id";s:0:"";s:7:"org-iso";s:0:"";s:8:"org-duns";s:0:"";s:11:"org-leicode";s:0:"";s:9:"org-naics";s:0:"";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:23:"%%term_title%% Archives";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:26:"taxonomy-category-ptparent";i:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:23:"%%term_title%% Archives";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:26:"taxonomy-post_tag-ptparent";i:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:23:"%%term_title%% Archives";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:29:"taxonomy-post_format-ptparent";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:0;s:17:"company_logo_meta";b:0;s:16:"person_logo_meta";b:0;s:29:"open_graph_frontpage_image_id";i:0;}', 'auto'),
(165, 'wpseo_social', 'a:20:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:17:"other_social_urls";a:0:{}s:12:"mastodon_url";s:0:"";}', 'auto'),
(197, 'analyst_cache', 's:6:"a:0:{}";', 'auto'),
(199, '_cdp_review', 'a:2:{s:9:"installed";i:1726244233;s:5:"users";a:0:{}}', 'auto'),
(200, '_cdp_globals', 'a:1:{s:6:"others";a:14:{s:17:"cdp-content-pages";s:4:"true";s:17:"cdp-content-posts";s:4:"true";s:18:"cdp-content-custom";s:4:"true";s:17:"cdp-display-posts";s:4:"true";s:16:"cdp-display-edit";s:4:"true";s:17:"cdp-display-admin";s:4:"true";s:16:"cdp-display-bulk";s:4:"true";s:21:"cdp-display-gutenberg";s:4:"true";s:19:"cdp-references-post";s:5:"false";s:19:"cdp-references-edit";s:5:"false";s:18:"cdp-premium-import";s:5:"false";s:24:"cdp-premium-hide-tooltip";s:5:"false";s:26:"cdp-premium-replace-domain";s:5:"false";s:20:"cdp-menu-in-settings";s:5:"false";}}', 'auto'),
(201, '_cdp_profiles', 'a:1:{s:7:"default";a:25:{s:5:"title";s:4:"true";s:4:"date";s:5:"false";s:6:"status";s:5:"false";s:4:"slug";s:4:"true";s:7:"excerpt";s:4:"true";s:7:"content";s:4:"true";s:7:"f_image";s:4:"true";s:8:"template";s:4:"true";s:6:"format";s:4:"true";s:6:"author";s:4:"true";s:8:"password";s:4:"true";s:11:"attachments";s:5:"false";s:8:"children";s:5:"false";s:8:"comments";s:5:"false";s:10:"menu_order";s:4:"true";s:8:"category";s:4:"true";s:8:"post_tag";s:4:"true";s:8:"taxonomy";s:4:"true";s:8:"nav_menu";s:4:"true";s:13:"link_category";s:4:"true";s:12:"all_metadata";s:5:"false";s:5:"names";a:5:{s:6:"prefix";s:0:"";s:6:"suffix";s:10:"#[Counter]";s:6:"format";s:1:"1";s:6:"custom";s:5:"m/d/Y";s:7:"display";s:7:"Default";}s:9:"usmplugin";s:5:"false";s:5:"yoast";s:5:"false";s:3:"woo";s:5:"false";}}', 'auto'),
(202, '_cdp_default_setup', '1', 'auto'),
(203, '_irb_h_bn_review', 'a:2:{s:5:"users";a:0:{}s:17:"copy-delete-posts";i:1726244233;}', 'auto'),
(204, '_tifm_force_disable_feature_update', '1', 'auto'),
(207, 'mtphr_post_duplicator_settings', '', 'auto'),
(208, 'theme_mods_twentytwentyfour', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1726244376;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'off'),
(209, 'current_theme', 'Crossthreads', 'auto'),
(210, 'theme_mods_crossthreads', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:6:"header";i:2;s:6:"footer";i:3;}s:18:"custom_css_post_id";i:-1;}', 'on'),
(211, 'theme_switched', '', 'auto'),
(235, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:24:"SSL verification failed.";}}', 'auto'),
(250, 'options_header_logo', '12', 'off'),
(251, '_options_header_logo', 'field_66ebf270f88d9', 'off'),
(252, 'options_footer_logo', '13', 'off'),
(253, '_options_footer_logo', 'field_66ebf284f88da', 'off'),
(255, 'options_header_icons_0_h_icons', '18', 'off'),
(256, '_options_header_icons_0_h_icons', 'field_66ebf447adf39', 'off'),
(257, 'options_header_icons_0_h_link', '', 'off'),
(258, '_options_header_icons_0_h_link', 'field_66ebf46eadf3a', 'off'),
(259, 'options_header_icons_1_h_icons', '19', 'off'),
(260, '_options_header_icons_1_h_icons', 'field_66ebf447adf39', 'off'),
(261, 'options_header_icons_1_h_link', '', 'off'),
(262, '_options_header_icons_1_h_link', 'field_66ebf46eadf3a', 'off'),
(263, 'options_header_icons', '2', 'off'),
(264, '_options_header_icons', 'field_66ebf427adf38', 'off'),
(352, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1728379560;}', 'off'),
(419, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'auto'),
(585, 'recovery_mode_email_last_sent', '1727773660', 'auto'),
(783, '_tifm_feature_enabled', 'enabled', 'auto'),
(784, '_tifm_hide_notice_forever', '1', 'auto'),
(793, 'action_scheduler_hybrid_store_demarkation', '280', 'auto'),
(794, 'schema-ActionScheduler_StoreSchema', '7.0.1727768808', 'auto'),
(795, 'schema-ActionScheduler_LoggerSchema', '3.0.1727768809', 'auto'),
(798, 'woocommerce_newly_installed', 'no', 'auto'),
(799, 'woocommerce_schema_version', '920', 'auto'),
(800, 'woocommerce_store_address', '', 'on'),
(801, 'woocommerce_store_address_2', '', 'on'),
(802, 'woocommerce_store_city', '', 'on'),
(803, 'woocommerce_default_country', 'IN:TN', 'on'),
(804, 'woocommerce_store_postcode', '', 'on'),
(805, 'woocommerce_allowed_countries', 'all', 'on'),
(806, 'woocommerce_all_except_countries', 'a:0:{}', 'on'),
(807, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'on'),
(808, 'woocommerce_ship_to_countries', '', 'on'),
(809, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'on'),
(810, 'woocommerce_default_customer_address', 'base', 'on'),
(811, 'woocommerce_calc_taxes', 'no', 'on'),
(812, 'woocommerce_enable_coupons', 'yes', 'on'),
(813, 'woocommerce_calc_discounts_sequentially', 'no', 'off'),
(814, 'woocommerce_currency', 'INR', 'on'),
(815, 'woocommerce_currency_pos', 'left', 'on'),
(816, 'woocommerce_price_thousand_sep', ',', 'on'),
(817, 'woocommerce_price_decimal_sep', '.', 'on'),
(818, 'woocommerce_price_num_decimals', '2', 'on'),
(819, 'woocommerce_shop_page_id', '281', 'on'),
(820, 'woocommerce_cart_redirect_after_add', 'no', 'on'),
(821, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'on'),
(822, 'woocommerce_placeholder_image', '280', 'on'),
(823, 'woocommerce_weight_unit', 'kg', 'on'),
(824, 'woocommerce_dimension_unit', 'cm', 'on'),
(825, 'woocommerce_enable_reviews', 'yes', 'on'),
(826, 'woocommerce_review_rating_verification_label', 'yes', 'off'),
(827, 'woocommerce_review_rating_verification_required', 'no', 'off'),
(828, 'woocommerce_enable_review_rating', 'yes', 'on'),
(829, 'woocommerce_review_rating_required', 'yes', 'off'),
(830, 'woocommerce_manage_stock', 'yes', 'on'),
(831, 'woocommerce_hold_stock_minutes', '60', 'off'),
(832, 'woocommerce_notify_low_stock', 'yes', 'off'),
(833, 'woocommerce_notify_no_stock', 'yes', 'off') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(834, 'woocommerce_stock_email_recipient', 'divya@artemasdigital.com', 'off'),
(835, 'woocommerce_notify_low_stock_amount', '2', 'off'),
(836, 'woocommerce_notify_no_stock_amount', '0', 'on'),
(837, 'woocommerce_hide_out_of_stock_items', 'no', 'on'),
(838, 'woocommerce_stock_format', '', 'on'),
(839, 'woocommerce_file_download_method', 'force', 'off'),
(840, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'off'),
(841, 'woocommerce_downloads_require_login', 'no', 'off'),
(842, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'off'),
(843, 'woocommerce_downloads_deliver_inline', '', 'off'),
(844, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'on'),
(845, 'woocommerce_downloads_count_partial', 'yes', 'on'),
(847, 'woocommerce_attribute_lookup_direct_updates', 'no', 'on'),
(848, 'woocommerce_attribute_lookup_optimized_updates', 'no', 'on'),
(849, 'woocommerce_product_match_featured_image_by_sku', 'no', 'on'),
(850, 'woocommerce_prices_include_tax', 'no', 'on'),
(851, 'woocommerce_tax_based_on', 'shipping', 'on'),
(852, 'woocommerce_shipping_tax_class', 'inherit', 'on'),
(853, 'woocommerce_tax_round_at_subtotal', 'no', 'on'),
(854, 'woocommerce_tax_classes', '', 'on'),
(855, 'woocommerce_tax_display_shop', 'excl', 'on'),
(856, 'woocommerce_tax_display_cart', 'excl', 'on'),
(857, 'woocommerce_price_display_suffix', '', 'on'),
(858, 'woocommerce_tax_total_display', 'itemized', 'off'),
(859, 'woocommerce_enable_shipping_calc', 'yes', 'off'),
(860, 'woocommerce_shipping_cost_requires_address', 'no', 'on'),
(861, 'woocommerce_ship_to_destination', 'billing', 'off'),
(862, 'woocommerce_shipping_debug_mode', 'no', 'on'),
(863, 'woocommerce_enable_guest_checkout', 'yes', 'off'),
(864, 'woocommerce_enable_checkout_login_reminder', 'no', 'off'),
(865, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'off'),
(866, 'woocommerce_enable_myaccount_registration', 'no', 'off'),
(867, 'woocommerce_registration_generate_username', 'yes', 'off'),
(868, 'woocommerce_registration_generate_password', 'yes', 'off'),
(869, 'woocommerce_erasure_request_removes_order_data', 'no', 'off'),
(870, 'woocommerce_erasure_request_removes_download_data', 'no', 'off'),
(871, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'off'),
(872, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'on'),
(873, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'on'),
(874, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'off'),
(875, 'woocommerce_trash_pending_orders', '', 'off'),
(876, 'woocommerce_trash_failed_orders', '', 'off'),
(877, 'woocommerce_trash_cancelled_orders', '', 'off'),
(878, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'off'),
(879, 'woocommerce_email_from_name', 'Crossthreads', 'off'),
(880, 'woocommerce_email_from_address', 'divya@artemasdigital.com', 'off'),
(881, 'woocommerce_email_header_image', '', 'off'),
(882, 'woocommerce_email_base_color', '#7f54b3', 'off'),
(883, 'woocommerce_email_background_color', '#f7f7f7', 'off'),
(884, 'woocommerce_email_body_background_color', '#ffffff', 'off'),
(885, 'woocommerce_email_text_color', '#3c3c3c', 'off'),
(886, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'off'),
(887, 'woocommerce_email_footer_text_color', '#3c3c3c', 'off'),
(888, 'woocommerce_merchant_email_notifications', 'no', 'off'),
(889, 'woocommerce_cart_page_id', '282', 'off'),
(890, 'woocommerce_checkout_page_id', '283', 'off'),
(891, 'woocommerce_myaccount_page_id', '284', 'off'),
(892, 'woocommerce_terms_page_id', '', 'off'),
(893, 'woocommerce_force_ssl_checkout', 'no', 'on'),
(894, 'woocommerce_unforce_ssl_checkout', 'no', 'on'),
(895, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'on'),
(896, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'on'),
(897, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'on'),
(898, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'on'),
(899, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'on'),
(900, 'woocommerce_myaccount_orders_endpoint', 'orders', 'on'),
(901, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'on'),
(902, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'on'),
(903, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'on'),
(904, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'on'),
(905, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'on'),
(906, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'on'),
(907, 'woocommerce_logout_endpoint', 'customer-logout', 'on'),
(908, 'woocommerce_api_enabled', 'no', 'on'),
(909, 'woocommerce_allow_tracking', 'no', 'off'),
(910, 'woocommerce_show_marketplace_suggestions', 'yes', 'off'),
(911, 'woocommerce_custom_orders_table_enabled', 'yes', 'on'),
(912, 'woocommerce_analytics_enabled', 'yes', 'on'),
(913, 'woocommerce_feature_order_attribution_enabled', 'yes', 'on'),
(914, 'woocommerce_feature_product_block_editor_enabled', 'no', 'on'),
(915, 'woocommerce_hpos_fts_index_enabled', 'no', 'on'),
(916, 'woocommerce_single_image_width', '600', 'on'),
(917, 'woocommerce_thumbnail_image_width', '300', 'on'),
(918, 'woocommerce_checkout_highlight_required_fields', 'yes', 'on'),
(919, 'woocommerce_demo_store', 'no', 'off'),
(920, 'wc_downloads_approved_directories_mode', 'enabled', 'auto'),
(921, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:7:"product";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}', 'auto'),
(922, 'current_theme_supports_woocommerce', 'yes', 'auto'),
(923, 'woocommerce_queue_flush_rewrite_rules', 'no', 'auto'),
(926, 'default_product_cat', '17', 'auto'),
(928, 'woocommerce_refund_returns_page_id', '285', 'auto'),
(931, 'woocommerce_paypal_settings', 'a:23:{s:7:"enabled";s:2:"no";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:5:"email";s:24:"divya@artemasdigital.com";s:8:"advanced";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";s:16:"ipn_notification";s:3:"yes";s:14:"receiver_email";s:24:"divya@artemasdigital.com";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"send_shipping";s:3:"yes";s:16:"address_override";s:2:"no";s:13:"paymentaction";s:4:"sale";s:9:"image_url";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";s:12:"_should_load";s:2:"no";}', 'on'),
(932, 'woocommerce_version', '9.3.3', 'auto'),
(933, 'woocommerce_db_version', '9.3.3', 'auto'),
(934, 'woocommerce_store_id', 'a1362054-05c9-4942-b19e-7240b0954966', 'auto'),
(935, 'woocommerce_admin_install_timestamp', '1727768920', 'auto'),
(936, 'woocommerce_inbox_variant_assignment', '7', 'auto'),
(937, 'woocommerce_remote_variant_assignment', '109', 'auto'),
(938, 'woocommerce_attribute_lookup_enabled', 'no', 'auto'),
(943, 'action_scheduler_lock_async-request-runner', '6704fa06e8edf1.32696193|1728379458', 'no') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(944, 'woocommerce_admin_notices', 'a:1:{i:0;s:20:"no_secure_connection";}', 'auto'),
(945, 'wc_blocks_version', '11.8.0-dev', 'auto'),
(946, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:"database_prefix";s:32:"ilFfDXqlspNEHILQpZ9Nd9LeshSt4Njj";}', 'on'),
(948, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(949, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(950, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(951, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(952, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(953, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(954, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(955, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(956, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(957, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(958, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(959, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(968, 'wcpay_was_in_use', 'no', 'auto'),
(971, 'wc_admin_show_legacy_coupon_menu', '0', 'auto'),
(972, 'woocommerce_custom_orders_table_created', 'yes', 'auto'),
(977, 'woocommerce_coming_soon', 'no', 'auto'),
(978, 'woocommerce_initial_installed_version', '9.3.3', 'off'),
(981, 'wc_remote_inbox_notifications_stored_state', 'O:8:"stdClass":2:{s:22:"there_were_no_products";b:1;s:22:"there_are_now_products";b:1;}', 'off'),
(984, 'wc_blocks_db_schema_version', '260', 'auto'),
(1002, 'jetpack_options', 'a:1:{s:14:"last_heartbeat";i:1728378245;}', 'auto'),
(1009, 'woocommerce_task_list_tracked_completed_tasks', 'a:2:{i:0;s:17:"launch-your-store";i:1;s:8:"products";}', 'auto'),
(1011, 'action_scheduler_migration_status', 'complete', 'auto'),
(1015, 'woocommerce_onboarding_profile', 'a:1:{s:7:"skipped";b:1;}', 'auto'),
(1056, 'product_cat_children', 'a:2:{i:18;a:2:{i:0;i:22;i:1;i:23;}i:19;a:2:{i:0;i:24;i:1;i:25;}}', 'auto'),
(1067, 'woocommerce_marketplace_suggestions', 'a:2:{s:11:"suggestions";a:28:{i:0;a:4:{s:4:"slug";s:28:"product-edit-meta-tab-header";s:7:"context";s:28:"product-edit-meta-tab-header";s:5:"title";s:22:"Recommended extensions";s:13:"allow-dismiss";b:0;}i:1;a:6:{s:4:"slug";s:39:"product-edit-meta-tab-footer-browse-all";s:7:"context";s:28:"product-edit-meta-tab-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:64:"https://woocommerce.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:2;a:9:{s:4:"slug";s:46:"product-edit-mailchimp-woocommerce-memberships";s:7:"product";s:33:"woocommerce-memberships-mailchimp";s:14:"show-if-active";a:1:{i:0;s:23:"woocommerce-memberships";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:116:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/mailchimp-for-memberships.svg";s:5:"title";s:25:"Mailchimp for Memberships";s:4:"copy";s:79:"Completely automate your email lists by syncing membership changes to Mailchimp";s:11:"button-text";s:10:"Learn More";s:3:"url";s:67:"https://woocommerce.com/products/mailchimp-woocommerce-memberships/";}i:3;a:9:{s:4:"slug";s:19:"product-edit-addons";s:7:"product";s:26:"woocommerce-product-addons";s:14:"show-if-active";a:2:{i:0;s:25:"woocommerce-subscriptions";i:1;s:20:"woocommerce-bookings";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:106:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-add-ons.svg";s:5:"title";s:15:"Product Add-Ons";s:4:"copy";s:93:"Offer add-ons like gift wrapping, special messages or other special options for your products";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woocommerce.com/products/product-add-ons/";}i:4;a:9:{s:4:"slug";s:46:"product-edit-woocommerce-subscriptions-gifting";s:7:"product";s:33:"woocommerce-subscriptions-gifting";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:116:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/gifting-for-subscriptions.svg";s:5:"title";s:25:"Gifting for Subscriptions";s:4:"copy";s:70:"Let customers buy subscriptions for others - they\'re the ultimate gift";s:11:"button-text";s:10:"Learn More";s:3:"url";s:67:"https://woocommerce.com/products/woocommerce-subscriptions-gifting/";}i:5;a:9:{s:4:"slug";s:42:"product-edit-teams-woocommerce-memberships";s:7:"product";s:33:"woocommerce-memberships-for-teams";s:14:"show-if-active";a:1:{i:0;s:23:"woocommerce-memberships";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:112:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/teams-for-memberships.svg";s:5:"title";s:21:"Teams for Memberships";s:4:"copy";s:123:"Adds B2B functionality to WooCommerce Memberships, allowing sites to sell team, group, corporate, or family member accounts";s:11:"button-text";s:10:"Learn More";s:3:"url";s:63:"https://woocommerce.com/products/teams-woocommerce-memberships/";}i:6;a:8:{s:4:"slug";s:29:"product-edit-variation-images";s:7:"product";s:39:"woocommerce-additional-variation-images";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:118:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/additional-variation-images.svg";s:5:"title";s:27:"Additional Variation Images";s:4:"copy";s:72:"Showcase your products in the best light with a image for each variation";s:11:"button-text";s:10:"Learn More";s:3:"url";s:73:"https://woocommerce.com/products/woocommerce-additional-variation-images/";}i:7;a:9:{s:4:"slug";s:47:"product-edit-woocommerce-subscription-downloads";s:7:"product";s:34:"woocommerce-subscription-downloads";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:113:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscription-downloads.svg";s:5:"title";s:22:"Subscription Downloads";s:4:"copy";s:57:"Give customers special downloads with their subscriptions";s:11:"button-text";s:10:"Learn More";s:3:"url";s:68:"https://woocommerce.com/products/woocommerce-subscription-downloads/";}i:8;a:8:{s:4:"slug";s:31:"product-edit-min-max-quantities";s:7:"product";s:30:"woocommerce-min-max-quantities";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:109:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/min-max-quantities.svg";s:5:"title";s:18:"Min/Max Quantities";s:4:"copy";s:81:"Specify minimum and maximum allowed product quantities for orders to be completed";s:11:"button-text";s:10:"Learn More";s:3:"url";s:52:"https://woocommerce.com/products/min-max-quantities/";}i:9;a:8:{s:4:"slug";s:28:"product-edit-name-your-price";s:7:"product";s:27:"woocommerce-name-your-price";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:106:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/name-your-price.svg";s:5:"title";s:15:"Name Your Price";s:4:"copy";s:70:"Let customers pay what they want - useful for donations, tips and more";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woocommerce.com/products/name-your-price/";}i:10;a:8:{s:4:"slug";s:42:"product-edit-woocommerce-one-page-checkout";s:7:"product";s:29:"woocommerce-one-page-checkout";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:108:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/one-page-checkout.svg";s:5:"title";s:17:"One Page Checkout";s:4:"copy";s:92:"Don\'t make customers click around - let them choose products, checkout & pay all on one page";s:11:"button-text";s:10:"Learn More";s:3:"url";s:63:"https://woocommerce.com/products/woocommerce-one-page-checkout/";}i:11;a:9:{s:4:"slug";s:24:"product-edit-automatewoo";s:7:"product";s:11:"automatewoo";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:104:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg";s:5:"title";s:23:"Automate your marketing";s:4:"copy";s:89:"Win customers and keep them coming back with a nearly endless range of powerful workflows";s:11:"button-text";s:10:"Learn More";s:3:"url";s:45:"https://woocommerce.com/products/automatewoo/";}i:12;a:4:{s:4:"slug";s:19:"orders-empty-header";s:7:"context";s:24:"orders-list-empty-header";s:5:"title";s:20:"Tools for your store";s:13:"allow-dismiss";b:0;}i:13;a:6:{s:4:"slug";s:30:"orders-empty-footer-browse-all";s:7:"context";s:24:"orders-list-empty-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:64:"https://woocommerce.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:14;a:8:{s:4:"slug";s:19:"orders-empty-wc-pay";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:20:"woocommerce-payments";s:4:"icon";s:111:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/woocommerce-payments.svg";s:5:"title";s:11:"WooPayments";s:4:"copy";s:125:"Securely accept payments and manage transactions directly from your WooCommerce dashboard – no setup costs or monthly fees.";s:11:"button-text";s:10:"Learn More";s:3:"url";s:45:"https://woocommerce.com/products/woopayments/";}i:15;a:8:{s:4:"slug";s:19:"orders-empty-zapier";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:18:"woocommerce-zapier";s:4:"icon";s:97:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/zapier.svg";s:5:"title";s:6:"Zapier";s:4:"copy";s:88:"Save time and increase productivity by connecting your store to more than 1000+ services";s:11:"button-text";s:10:"Learn More";s:3:"url";s:52:"https://woocommerce.com/products/woocommerce-zapier/";}i:16;a:8:{s:4:"slug";s:30:"orders-empty-shipment-tracking";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:29:"woocommerce-shipment-tracking";s:4:"icon";s:108:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipment-tracking.svg";s:5:"title";s:17:"Shipment Tracking";s:4:"copy";s:86:"Let customers know when their orders will arrive by adding shipment tracking to emails";s:11:"button-text";s:10:"Learn More";s:3:"url";s:51:"https://woocommerce.com/products/shipment-tracking/";}i:17;a:8:{s:4:"slug";s:32:"orders-empty-table-rate-shipping";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:31:"woocommerce-table-rate-shipping";s:4:"icon";s:110:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/table-rate-shipping.svg";s:5:"title";s:19:"Table Rate Shipping";s:4:"copy";s:122:"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count";s:11:"button-text";s:10:"Learn More";s:3:"url";s:53:"https://woocommerce.com/products/table-rate-shipping/";}i:18;a:8:{s:4:"slug";s:40:"orders-empty-shipping-carrier-extensions";s:7:"context";s:22:"orders-list-empty-body";s:4:"icon";s:118:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipping-carrier-extensions.svg";s:5:"title";s:27:"Shipping Carrier Extensions";s:4:"copy";s:116:"Show live rates from FedEx, UPS, USPS and more directly on your store - never under or overcharge for shipping again";s:11:"button-text";s:13:"Find Carriers";s:8:"promoted";s:26:"category-shipping-carriers";s:3:"url";s:99:"https://woocommerce.com/product-category/woocommerce-extensions/shipping-methods/shipping-carriers/";}i:19;a:8:{s:4:"slug";s:32:"orders-empty-google-product-feed";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:25:"woocommerce-product-feeds";s:4:"icon";s:110:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/google-product-feed.svg";s:5:"title";s:19:"Google Product Feed";s:4:"copy";s:76:"Increase sales by letting customers find you when they\'re shopping on Google";s:11:"button-text";s:10:"Learn More";s:3:"url";s:53:"https://woocommerce.com/products/google-product-feed/";}i:20;a:4:{s:4:"slug";s:35:"products-empty-header-product-types";s:7:"context";s:26:"products-list-empty-header";s:5:"title";s:23:"Other types of products";s:13:"allow-dismiss";b:0;}i:21;a:6:{s:4:"slug";s:32:"products-empty-footer-browse-all";s:7:"context";s:26:"products-list-empty-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:64:"https://woocommerce.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:22;a:8:{s:4:"slug";s:30:"products-empty-product-vendors";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:27:"woocommerce-product-vendors";s:4:"icon";s:106:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-vendors.svg";s:5:"title";s:15:"Product Vendors";s:4:"copy";s:47:"Turn your store into a multi-vendor marketplace";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woocommerce.com/products/product-vendors/";}i:23;a:8:{s:4:"slug";s:26:"products-empty-memberships";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:23:"woocommerce-memberships";s:4:"icon";s:102:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/memberships.svg";s:5:"title";s:11:"Memberships";s:4:"copy";s:76:"Give members access to restricted content or products, for a fee or for free";s:11:"button-text";s:10:"Learn More";s:3:"url";s:57:"https://woocommerce.com/products/woocommerce-memberships/";}i:24;a:9:{s:4:"slug";s:35:"products-empty-woocommerce-deposits";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:20:"woocommerce-deposits";s:14:"show-if-active";a:1:{i:0;s:20:"woocommerce-bookings";}s:4:"icon";s:99:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/deposits.svg";s:5:"title";s:8:"Deposits";s:4:"copy";s:75:"Make it easier for customers to pay by offering a deposit or a payment plan";s:11:"button-text";s:10:"Learn More";s:3:"url";s:54:"https://woocommerce.com/products/woocommerce-deposits/";}i:25;a:8:{s:4:"slug";s:40:"products-empty-woocommerce-subscriptions";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:25:"woocommerce-subscriptions";s:4:"icon";s:104:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg";s:5:"title";s:13:"Subscriptions";s:4:"copy";s:97:"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis";s:11:"button-text";s:10:"Learn More";s:3:"url";s:59:"https://woocommerce.com/products/woocommerce-subscriptions/";}i:26;a:8:{s:4:"slug";s:35:"products-empty-woocommerce-bookings";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:20:"woocommerce-bookings";s:4:"icon";s:99:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/bookings.svg";s:5:"title";s:8:"Bookings";s:4:"copy";s:99:"Allow customers to book appointments, make reservations or rent equipment without leaving your site";s:11:"button-text";s:10:"Learn More";s:3:"url";s:54:"https://woocommerce.com/products/woocommerce-bookings/";}i:27;a:8:{s:4:"slug";s:30:"products-empty-product-bundles";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:27:"woocommerce-product-bundles";s:4:"icon";s:106:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-bundles.svg";s:5:"title";s:15:"Product Bundles";s:4:"copy";s:49:"Offer customizable bundles and assembled products";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woocommerce.com/products/product-bundles/";}}s:7:"updated";i:1727770054;}', 'off'),
(1152, 'category_children', 'a:0:{}', 'auto'),
(1232, 'options_footer_icons_0_f_icon', '295', 'off'),
(1233, '_options_footer_icons_0_f_icon', 'field_66fbc41673ad7', 'off'),
(1234, 'options_footer_icons_0_f_icon_title', 'Delivery', 'off'),
(1235, '_options_footer_icons_0_f_icon_title', 'field_66fbc41673ad8', 'off'),
(1236, 'options_footer_icons_0_f_icon_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.\r\n', 'off'),
(1237, '_options_footer_icons_0_f_icon_content', 'field_66fbc46a73ad9', 'off'),
(1238, 'options_footer_icons_1_f_icon', '297', 'off'),
(1239, '_options_footer_icons_1_f_icon', 'field_66fbc41673ad7', 'off'),
(1240, 'options_footer_icons_1_f_icon_title', 'Return', 'off'),
(1241, '_options_footer_icons_1_f_icon_title', 'field_66fbc41673ad8', 'off'),
(1242, 'options_footer_icons_1_f_icon_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.\r\n', 'off'),
(1243, '_options_footer_icons_1_f_icon_content', 'field_66fbc46a73ad9', 'off'),
(1244, 'options_footer_icons', '3', 'off'),
(1245, '_options_footer_icons', 'field_66fbc41673ad6', 'off'),
(1252, 'options_footer_icons_2_f_icon', '296', 'off'),
(1253, '_options_footer_icons_2_f_icon', 'field_66fbc41673ad7', 'off'),
(1254, 'options_footer_icons_2_f_icon_title', 'Secure Payment', 'off'),
(1255, '_options_footer_icons_2_f_icon_title', 'field_66fbc41673ad8', 'off'),
(1256, 'options_footer_icons_2_f_icon_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.\r\n', 'off'),
(1257, '_options_footer_icons_2_f_icon_content', 'field_66fbc46a73ad9', 'off'),
(1327, 'options_ft_social_media_0_soc_icon', '307', 'off'),
(1328, '_options_ft_social_media_0_soc_icon', 'field_66fbcfe082b0f', 'off'),
(1329, 'options_ft_social_media_0_soc_link', '#', 'off'),
(1330, '_options_ft_social_media_0_soc_link', 'field_66fbd00a82b10', 'off'),
(1331, 'options_ft_social_media_1_soc_icon', '308', 'off'),
(1332, '_options_ft_social_media_1_soc_icon', 'field_66fbcfe082b0f', 'off'),
(1333, 'options_ft_social_media_1_soc_link', '#', 'off'),
(1334, '_options_ft_social_media_1_soc_link', 'field_66fbd00a82b10', 'off'),
(1335, 'options_ft_social_media', '2', 'off'),
(1336, '_options_ft_social_media', 'field_66fbcfa782b0e', 'off'),
(1337, 'options_copyright_text', '© 2024 | All rights reserved.', 'off'),
(1338, '_options_copyright_text', 'field_66fbd0c766978', 'off'),
(1339, 'options_footer_links_0_ft_page_title', 'Return Policy', 'off'),
(1340, '_options_footer_links_0_ft_page_title', 'field_66fbd1156697a', 'off'),
(1341, 'options_footer_links_0_ft_page_url', '285', 'off'),
(1342, '_options_footer_links_0_ft_page_url', 'field_66fbd1236697b', 'off'),
(1343, 'options_footer_links_1_ft_page_title', 'Terms &amp; Conditions', 'off'),
(1344, '_options_footer_links_1_ft_page_title', 'field_66fbd1156697a', 'off'),
(1345, 'options_footer_links_1_ft_page_url', '266', 'off'),
(1346, '_options_footer_links_1_ft_page_url', 'field_66fbd1236697b', 'off'),
(1347, 'options_footer_links_2_ft_page_title', 'Privacy', 'off'),
(1348, '_options_footer_links_2_ft_page_title', 'field_66fbd1156697a', 'off'),
(1349, 'options_footer_links_2_ft_page_url', '3', 'off'),
(1350, '_options_footer_links_2_ft_page_url', 'field_66fbd1236697b', 'off'),
(1351, 'options_footer_links', '3', 'off'),
(1352, '_options_footer_links', 'field_66fbd0f166979', 'off') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_last', '1'),
(4, 5, '_edit_lock', '1727597960:1'),
(5, 5, '_wp_page_template', 'template-home.php'),
(6, 5, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(7, 7, '_wp_attached_file', '2024/09/banner.webp'),
(8, 7, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1094;s:4:"file";s:19:"2024/09/banner.webp";s:8:"filesize";i:1847584;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:19:"banner-300x171.webp";s:5:"width";i:300;s:6:"height";i:171;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:5786;}s:5:"large";a:5:{s:4:"file";s:20:"banner-1024x583.webp";s:5:"width";i:1024;s:6:"height";i:583;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:58060;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"banner-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:3572;}s:12:"medium_large";a:5:{s:4:"file";s:19:"banner-768x438.webp";s:5:"width";i:768;s:6:"height";i:438;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:34730;}s:9:"1536x1536";a:5:{s:4:"file";s:20:"banner-1536x875.webp";s:5:"width";i:1536;s:6:"height";i:875;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:104330;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(9, 5, '_thumbnail_id', '7'),
(10, 8, '_edit_last', '1'),
(11, 8, '_edit_lock', '1727782363:1'),
(12, 12, '_wp_attached_file', '2024/09/logo.svg'),
(13, 12, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:458559;}'),
(14, 13, '_wp_attached_file', '2024/09/cross-ft-logo.svg'),
(15, 13, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:391410;}'),
(16, 18, '_wp_attached_file', '2024/09/account.svg'),
(17, 18, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:1700;}'),
(18, 19, '_wp_attached_file', '2024/09/cart.svg'),
(19, 19, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:993;}'),
(20, 21, '_menu_item_type', 'custom'),
(21, 21, '_menu_item_menu_item_parent', '0'),
(22, 21, '_menu_item_object_id', '21'),
(23, 21, '_menu_item_object', 'custom'),
(24, 21, '_menu_item_target', ''),
(25, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(26, 21, '_menu_item_xfn', ''),
(27, 21, '_menu_item_url', '#'),
(29, 22, '_menu_item_type', 'custom'),
(30, 22, '_menu_item_menu_item_parent', '0'),
(31, 22, '_menu_item_object_id', '22'),
(32, 22, '_menu_item_object', 'custom'),
(33, 22, '_menu_item_target', ''),
(34, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(35, 22, '_menu_item_xfn', ''),
(36, 22, '_menu_item_url', '#'),
(38, 23, '_menu_item_type', 'custom'),
(39, 23, '_menu_item_menu_item_parent', '0'),
(40, 23, '_menu_item_object_id', '23'),
(41, 23, '_menu_item_object', 'custom'),
(42, 23, '_menu_item_target', ''),
(43, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(44, 23, '_menu_item_xfn', ''),
(45, 23, '_menu_item_url', '#'),
(47, 24, '_menu_item_type', 'custom'),
(48, 24, '_menu_item_menu_item_parent', '0'),
(49, 24, '_menu_item_object_id', '24'),
(50, 24, '_menu_item_object', 'custom'),
(51, 24, '_menu_item_target', ''),
(52, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(53, 24, '_menu_item_xfn', ''),
(54, 24, '_menu_item_url', '#'),
(56, 25, '_menu_item_type', 'custom'),
(57, 25, '_menu_item_menu_item_parent', '0'),
(58, 25, '_menu_item_object_id', '25'),
(59, 25, '_menu_item_object', 'custom'),
(60, 25, '_menu_item_target', ''),
(61, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(62, 25, '_menu_item_xfn', ''),
(63, 25, '_menu_item_url', '#'),
(65, 26, '_edit_last', '1'),
(66, 26, '_edit_lock', '1727598110:1'),
(67, 81, '_edit_last', '1'),
(68, 81, '_wp_page_template', 'template-about.php'),
(69, 81, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(70, 81, '_edit_lock', '1727689196:1'),
(71, 5, 'banner_heading', 'Wear your values.'),
(72, 5, '_banner_heading', 'field_66f6eaf08a8c6'),
(73, 5, 'banner_content', 'Choose Crossthreads for ethically crafted, sustainable fashion.'),
(74, 5, '_banner_content', 'field_66f6eb3c8a8c7'),
(75, 5, 'categ_title', 'From earth to your wardrobe'),
(76, 5, '_categ_title', 'field_66f6eb7a03748'),
(77, 5, 'prod_categories_0_categ_name', 'MEN'),
(78, 5, '_prod_categories_0_categ_name', 'field_66f6ebe60374a'),
(79, 5, 'prod_categories_0_categ_image', '104'),
(80, 5, '_prod_categories_0_categ_image', 'field_66f6ec080374b'),
(81, 5, 'prod_categories_0_categ_link', ''),
(82, 5, '_prod_categories_0_categ_link', 'field_66f6ec470374c'),
(83, 5, 'prod_categories_1_categ_name', 'WOMEN'),
(84, 5, '_prod_categories_1_categ_name', 'field_66f6ebe60374a'),
(85, 5, 'prod_categories_1_categ_image', '105'),
(86, 5, '_prod_categories_1_categ_image', 'field_66f6ec080374b'),
(87, 5, 'prod_categories_1_categ_link', ''),
(88, 5, '_prod_categories_1_categ_link', 'field_66f6ec470374c'),
(89, 5, 'prod_categories_2_categ_name', 'Kids'),
(90, 5, '_prod_categories_2_categ_name', 'field_66f6ebe60374a'),
(91, 5, 'prod_categories_2_categ_image', '106'),
(92, 5, '_prod_categories_2_categ_image', 'field_66f6ec080374b'),
(93, 5, 'prod_categories_2_categ_link', ''),
(94, 5, '_prod_categories_2_categ_link', 'field_66f6ec470374c'),
(95, 5, 'prod_categories_3_categ_name', 'Wellness Cloths'),
(96, 5, '_prod_categories_3_categ_name', 'field_66f6ebe60374a'),
(97, 5, 'prod_categories_3_categ_image', '107'),
(98, 5, '_prod_categories_3_categ_image', 'field_66f6ec080374b'),
(99, 5, 'prod_categories_3_categ_link', ''),
(100, 5, '_prod_categories_3_categ_link', 'field_66f6ec470374c'),
(101, 5, 'prod_categories', '4'),
(102, 5, '_prod_categories', 'field_66f6ebc803749'),
(103, 5, 'categ_button_text', 'See All'),
(104, 5, '_categ_button_text', 'field_66f6ec6d591d0'),
(105, 5, 'categ_button_link', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(106, 5, '_categ_button_link', 'field_66f6ec81591d1'),
(107, 5, 'icon_title', 'Finest ethical and sustainable products'),
(108, 5, '_icon_title', 'field_66f6ed3bace0c'),
(109, 5, 'icon_details', '4'),
(110, 5, '_icon_details', 'field_66f6ed42ace0d'),
(111, 5, 'ab_background_image', '88'),
(112, 5, '_ab_background_image', 'field_66f6edf727793'),
(113, 5, 'ab_heading', 'About Crosstherads'),
(114, 5, '_ab_heading', 'field_66f6ee4c27797'),
(115, 5, 'ab_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(116, 5, '_ab_content', 'field_66f6ee5027798'),
(117, 5, 'ab_button_text', 'Learn More'),
(118, 5, '_ab_button_text', 'field_66f6ee3b27795'),
(119, 5, 'ab_button_link', 'a:3:{s:5:"title";s:8:"About Us";s:3:"url";s:44:"http://localhost/crossthreads/site/about-us/";s:6:"target";s:0:"";}'),
(120, 5, '_ab_button_link', 'field_66f6ee4127796'),
(121, 5, 'season_title', 'Seasonal Products'),
(122, 5, '_season_title', 'field_66f6ef5882d5b'),
(123, 5, 'sea_prod', '3'),
(124, 5, '_sea_prod', 'field_66f6ef8b82d5c'),
(125, 5, 'coll_button_text', 'See All Collections'),
(126, 5, '_coll_button_text', 'field_66f6f0a26790d'),
(127, 5, 'coll_button_link', ''),
(128, 5, '_coll_button_link', 'field_66f6f0a66790e'),
(129, 5, 'discount_prod', '2'),
(130, 5, '_discount_prod', 'field_66f6f130f781c'),
(131, 5, 'cust_title', 'Happy Customers'),
(132, 5, '_cust_title', 'field_66f6fca3242e1'),
(133, 5, 'customers_quotes', '3'),
(134, 5, '_customers_quotes', 'field_66f6fcb5242e2'),
(135, 5, 'product_slider', '4'),
(136, 5, '_product_slider', 'field_66f6fd852dbae'),
(137, 6, 'banner_heading', 'Wear your values.'),
(138, 6, '_banner_heading', 'field_66f6eaf08a8c6'),
(139, 6, 'banner_content', 'Choose Crossthreads for ethically crafted, sustainable fashion.'),
(140, 6, '_banner_content', 'field_66f6eb3c8a8c7'),
(141, 6, 'categ_title', 'From earth to your wardrobe'),
(142, 6, '_categ_title', 'field_66f6eb7a03748'),
(143, 6, 'prod_categories_0_categ_name', ''),
(144, 6, '_prod_categories_0_categ_name', 'field_66f6ebe60374a'),
(145, 6, 'prod_categories_0_categ_image', ''),
(146, 6, '_prod_categories_0_categ_image', 'field_66f6ec080374b'),
(147, 6, 'prod_categories_0_categ_link', ''),
(148, 6, '_prod_categories_0_categ_link', 'field_66f6ec470374c'),
(149, 6, 'prod_categories_1_categ_name', ''),
(150, 6, '_prod_categories_1_categ_name', 'field_66f6ebe60374a'),
(151, 6, 'prod_categories_1_categ_image', ''),
(152, 6, '_prod_categories_1_categ_image', 'field_66f6ec080374b'),
(153, 6, 'prod_categories_1_categ_link', ''),
(154, 6, '_prod_categories_1_categ_link', 'field_66f6ec470374c'),
(155, 6, 'prod_categories_2_categ_name', ''),
(156, 6, '_prod_categories_2_categ_name', 'field_66f6ebe60374a'),
(157, 6, 'prod_categories_2_categ_image', ''),
(158, 6, '_prod_categories_2_categ_image', 'field_66f6ec080374b'),
(159, 6, 'prod_categories_2_categ_link', ''),
(160, 6, '_prod_categories_2_categ_link', 'field_66f6ec470374c'),
(161, 6, 'prod_categories_3_categ_name', ''),
(162, 6, '_prod_categories_3_categ_name', 'field_66f6ebe60374a'),
(163, 6, 'prod_categories_3_categ_image', ''),
(164, 6, '_prod_categories_3_categ_image', 'field_66f6ec080374b'),
(165, 6, 'prod_categories_3_categ_link', ''),
(166, 6, '_prod_categories_3_categ_link', 'field_66f6ec470374c'),
(167, 6, 'prod_categories', '4'),
(168, 6, '_prod_categories', 'field_66f6ebc803749'),
(169, 6, 'categ_button_text', ''),
(170, 6, '_categ_button_text', 'field_66f6ec6d591d0'),
(171, 6, 'categ_button_link', ''),
(172, 6, '_categ_button_link', 'field_66f6ec81591d1'),
(173, 6, 'icon_title', ''),
(174, 6, '_icon_title', 'field_66f6ed3bace0c'),
(175, 6, 'icon_details', ''),
(176, 6, '_icon_details', 'field_66f6ed42ace0d'),
(177, 6, 'ab_background_image', ''),
(178, 6, '_ab_background_image', 'field_66f6edf727793'),
(179, 6, 'ab_heading', ''),
(180, 6, '_ab_heading', 'field_66f6ee4c27797'),
(181, 6, 'ab_content', ''),
(182, 6, '_ab_content', 'field_66f6ee5027798'),
(183, 6, 'ab_button_text', ''),
(184, 6, '_ab_button_text', 'field_66f6ee3b27795'),
(185, 6, 'ab_button_link', ''),
(186, 6, '_ab_button_link', 'field_66f6ee4127796'),
(187, 6, 'season_title', ''),
(188, 6, '_season_title', 'field_66f6ef5882d5b'),
(189, 6, 'sea_prod', ''),
(190, 6, '_sea_prod', 'field_66f6ef8b82d5c'),
(191, 6, 'coll_button_text', ''),
(192, 6, '_coll_button_text', 'field_66f6f0a26790d'),
(193, 6, 'coll_button_link', ''),
(194, 6, '_coll_button_link', 'field_66f6f0a66790e'),
(195, 6, 'discount_prod', ''),
(196, 6, '_discount_prod', 'field_66f6f130f781c'),
(197, 6, 'cust_title', ''),
(198, 6, '_cust_title', 'field_66f6fca3242e1'),
(199, 6, 'customers_quotes', ''),
(200, 6, '_customers_quotes', 'field_66f6fcb5242e2'),
(201, 6, 'product_slider', ''),
(202, 6, '_product_slider', 'field_66f6fd852dbae'),
(203, 84, '_wp_attached_file', '2024/09/icon-one.svg'),
(204, 84, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:6586;}'),
(205, 85, '_wp_attached_file', '2024/09/icon-four.svg') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(206, 85, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:18272;}'),
(207, 86, '_wp_attached_file', '2024/09/icon-three.svg'),
(208, 86, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:7454;}'),
(209, 87, '_wp_attached_file', '2024/09/icon-two.svg'),
(210, 87, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:4782;}'),
(211, 88, '_wp_attached_file', '2024/09/banner-two.jpg'),
(212, 88, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1024;s:4:"file";s:22:"2024/09/banner-two.jpg";s:8:"filesize";i:937152;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(213, 89, '_wp_attached_file', '2024/09/img-eight.jpg'),
(214, 89, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:568;s:6:"height";i:669;s:4:"file";s:21:"2024/09/img-eight.jpg";s:8:"filesize";i:96216;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(215, 90, '_wp_attached_file', '2024/09/img-seven.jpg'),
(216, 90, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:568;s:6:"height";i:669;s:4:"file";s:21:"2024/09/img-seven.jpg";s:8:"filesize";i:288372;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(217, 91, '_wp_attached_file', '2024/09/img-nine.jpg'),
(218, 91, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:568;s:6:"height";i:669;s:4:"file";s:20:"2024/09/img-nine.jpg";s:8:"filesize";i:123263;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(219, 92, '_wp_attached_file', '2024/09/discount-img.jpg'),
(220, 92, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:914;s:4:"file";s:24:"2024/09/discount-img.jpg";s:8:"filesize";i:620914;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(221, 93, '_wp_attached_file', '2024/09/img-eleven.jpg'),
(222, 93, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:914;s:4:"file";s:22:"2024/09/img-eleven.jpg";s:8:"filesize";i:549315;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(223, 94, '_wp_attached_file', '2024/09/profile-pic.jpg'),
(224, 94, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:153;s:6:"height";i:153;s:4:"file";s:23:"2024/09/profile-pic.jpg";s:8:"filesize";i:23158;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(225, 95, '_wp_attached_file', '2024/09/star.png'),
(226, 95, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:220;s:6:"height";i:40;s:4:"file";s:16:"2024/09/star.png";s:8:"filesize";i:1306;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(227, 5, 'icon_details_0_icon_image', '84'),
(228, 5, '_icon_details_0_icon_image', 'field_66f6ed42ace0f'),
(229, 5, 'icon_details_0_icon_name', 'Sustainable Materials'),
(230, 5, '_icon_details_0_icon_name', 'field_66f6ed42ace0e'),
(231, 5, 'icon_details_1_icon_image', '87'),
(232, 5, '_icon_details_1_icon_image', 'field_66f6ed42ace0f'),
(233, 5, 'icon_details_1_icon_name', 'Garment Care'),
(234, 5, '_icon_details_1_icon_name', 'field_66f6ed42ace0e'),
(235, 5, 'icon_details_2_icon_image', '86'),
(236, 5, '_icon_details_2_icon_image', 'field_66f6ed42ace0f'),
(237, 5, 'icon_details_2_icon_name', 'Recycled/ Upcycled'),
(238, 5, '_icon_details_2_icon_name', 'field_66f6ed42ace0e'),
(239, 5, 'icon_details_3_icon_image', '85'),
(240, 5, '_icon_details_3_icon_image', 'field_66f6ed42ace0f'),
(241, 5, 'icon_details_3_icon_name', 'Made in INDIA'),
(242, 5, '_icon_details_3_icon_name', 'field_66f6ed42ace0e'),
(243, 5, 'sea_prod_0_prod_name', 'Organic Linen Shirt'),
(244, 5, '_sea_prod_0_prod_name', 'field_66f6ef8b82d5d'),
(245, 5, 'sea_prod_0_prod_image', '90'),
(246, 5, '_sea_prod_0_prod_image', 'field_66f6ef8b82d5e'),
(247, 5, 'sea_prod_0_prod_link', ''),
(248, 5, '_sea_prod_0_prod_link', 'field_66f6ef8b82d5f'),
(249, 5, 'sea_prod_0_prod_price', '$49.99'),
(250, 5, '_sea_prod_0_prod_price', 'field_66f6efca82d60'),
(251, 5, 'sea_prod_0_prod_button_link', ''),
(252, 5, '_sea_prod_0_prod_button_link', 'field_66f6f07082d61'),
(253, 5, 'sea_prod_1_prod_name', 'Organic Cotton Button-Up'),
(254, 5, '_sea_prod_1_prod_name', 'field_66f6ef8b82d5d'),
(255, 5, 'sea_prod_1_prod_image', '89'),
(256, 5, '_sea_prod_1_prod_image', 'field_66f6ef8b82d5e'),
(257, 5, 'sea_prod_1_prod_link', ''),
(258, 5, '_sea_prod_1_prod_link', 'field_66f6ef8b82d5f'),
(259, 5, 'sea_prod_1_prod_price', '$49.99'),
(260, 5, '_sea_prod_1_prod_price', 'field_66f6efca82d60'),
(261, 5, 'sea_prod_1_prod_button_link', ''),
(262, 5, '_sea_prod_1_prod_button_link', 'field_66f6f07082d61'),
(263, 5, 'sea_prod_2_prod_name', 'Sustainable Classic'),
(264, 5, '_sea_prod_2_prod_name', 'field_66f6ef8b82d5d'),
(265, 5, 'sea_prod_2_prod_image', '91'),
(266, 5, '_sea_prod_2_prod_image', 'field_66f6ef8b82d5e'),
(267, 5, 'sea_prod_2_prod_link', ''),
(268, 5, '_sea_prod_2_prod_link', 'field_66f6ef8b82d5f'),
(269, 5, 'sea_prod_2_prod_price', '$49.99'),
(270, 5, '_sea_prod_2_prod_price', 'field_66f6efca82d60'),
(271, 5, 'sea_prod_2_prod_button_link', ''),
(272, 5, '_sea_prod_2_prod_button_link', 'field_66f6f07082d61'),
(273, 5, 'discount_prod_0_disc_prod_image', '92'),
(274, 5, '_discount_prod_0_disc_prod_image', 'field_66f6f130f781e'),
(275, 5, 'discount_prod_0_disc_percentage', '15%'),
(276, 5, '_discount_prod_0_disc_percentage', 'field_66f6f130f781f'),
(277, 5, 'discount_prod_0_disc_prod_name', 'Herbal Series Linen Shirt'),
(278, 5, '_discount_prod_0_disc_prod_name', 'field_66f6f130f781d'),
(279, 5, 'discount_prod_0_disc_prod_price', '$49.99'),
(280, 5, '_discount_prod_0_disc_prod_price', 'field_66f6f130f7820'),
(281, 5, 'discount_prod_0_prod_button_link', ''),
(282, 5, '_discount_prod_0_prod_button_link', 'field_66f6f130f7821'),
(283, 5, 'discount_prod_1_disc_prod_image', '93'),
(284, 5, '_discount_prod_1_disc_prod_image', 'field_66f6f130f781e'),
(285, 5, 'discount_prod_1_disc_percentage', '30%'),
(286, 5, '_discount_prod_1_disc_percentage', 'field_66f6f130f781f'),
(287, 5, 'discount_prod_1_disc_prod_name', 'Herbal Series Linen Shirt'),
(288, 5, '_discount_prod_1_disc_prod_name', 'field_66f6f130f781d'),
(289, 5, 'discount_prod_1_disc_prod_price', '$49.99'),
(290, 5, '_discount_prod_1_disc_prod_price', 'field_66f6f130f7820'),
(291, 5, 'discount_prod_1_prod_button_link', ''),
(292, 5, '_discount_prod_1_prod_button_link', 'field_66f6f130f7821'),
(293, 5, 'customers_quotes_0_cust_image', '94'),
(294, 5, '_customers_quotes_0_cust_image', 'field_66f6fcb5242e3'),
(295, 5, 'customers_quotes_0_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(296, 5, '_customers_quotes_0_cust_content', 'field_66f6fcb5242e4'),
(297, 5, 'customers_quotes_0_cust_name', 'Deepson'),
(298, 5, '_customers_quotes_0_cust_name', 'field_66f6fcb5242e5'),
(299, 5, 'customers_quotes_0_cust_rating', '95'),
(300, 5, '_customers_quotes_0_cust_rating', 'field_66f6fcb5242e6'),
(301, 5, 'customers_quotes_1_cust_image', '94'),
(302, 5, '_customers_quotes_1_cust_image', 'field_66f6fcb5242e3'),
(303, 5, 'customers_quotes_1_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(304, 5, '_customers_quotes_1_cust_content', 'field_66f6fcb5242e4'),
(305, 5, 'customers_quotes_1_cust_name', 'Deepson') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(306, 5, '_customers_quotes_1_cust_name', 'field_66f6fcb5242e5'),
(307, 5, 'customers_quotes_1_cust_rating', '95'),
(308, 5, '_customers_quotes_1_cust_rating', 'field_66f6fcb5242e6'),
(309, 5, 'customers_quotes_2_cust_image', '94'),
(310, 5, '_customers_quotes_2_cust_image', 'field_66f6fcb5242e3'),
(311, 5, 'customers_quotes_2_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(312, 5, '_customers_quotes_2_cust_content', 'field_66f6fcb5242e4'),
(313, 5, 'customers_quotes_2_cust_name', 'Deepson'),
(314, 5, '_customers_quotes_2_cust_name', 'field_66f6fcb5242e5'),
(315, 5, 'customers_quotes_2_cust_rating', '95'),
(316, 5, '_customers_quotes_2_cust_rating', 'field_66f6fcb5242e6'),
(317, 83, 'banner_heading', 'Wear your values.'),
(318, 83, '_banner_heading', 'field_66f6eaf08a8c6'),
(319, 83, 'banner_content', 'Choose Crossthreads for ethically crafted, sustainable fashion.'),
(320, 83, '_banner_content', 'field_66f6eb3c8a8c7'),
(321, 83, 'categ_title', 'From earth to your wardrobe'),
(322, 83, '_categ_title', 'field_66f6eb7a03748'),
(323, 83, 'prod_categories_0_categ_name', 'MEN'),
(324, 83, '_prod_categories_0_categ_name', 'field_66f6ebe60374a'),
(325, 83, 'prod_categories_0_categ_image', ''),
(326, 83, '_prod_categories_0_categ_image', 'field_66f6ec080374b'),
(327, 83, 'prod_categories_0_categ_link', ''),
(328, 83, '_prod_categories_0_categ_link', 'field_66f6ec470374c'),
(329, 83, 'prod_categories_1_categ_name', 'WOMEN'),
(330, 83, '_prod_categories_1_categ_name', 'field_66f6ebe60374a'),
(331, 83, 'prod_categories_1_categ_image', ''),
(332, 83, '_prod_categories_1_categ_image', 'field_66f6ec080374b'),
(333, 83, 'prod_categories_1_categ_link', ''),
(334, 83, '_prod_categories_1_categ_link', 'field_66f6ec470374c'),
(335, 83, 'prod_categories_2_categ_name', 'Kids'),
(336, 83, '_prod_categories_2_categ_name', 'field_66f6ebe60374a'),
(337, 83, 'prod_categories_2_categ_image', ''),
(338, 83, '_prod_categories_2_categ_image', 'field_66f6ec080374b'),
(339, 83, 'prod_categories_2_categ_link', ''),
(340, 83, '_prod_categories_2_categ_link', 'field_66f6ec470374c'),
(341, 83, 'prod_categories_3_categ_name', 'Wellness Cloths'),
(342, 83, '_prod_categories_3_categ_name', 'field_66f6ebe60374a'),
(343, 83, 'prod_categories_3_categ_image', ''),
(344, 83, '_prod_categories_3_categ_image', 'field_66f6ec080374b'),
(345, 83, 'prod_categories_3_categ_link', ''),
(346, 83, '_prod_categories_3_categ_link', 'field_66f6ec470374c'),
(347, 83, 'prod_categories', '4'),
(348, 83, '_prod_categories', 'field_66f6ebc803749'),
(349, 83, 'categ_button_text', 'See All'),
(350, 83, '_categ_button_text', 'field_66f6ec6d591d0'),
(351, 83, 'categ_button_link', ''),
(352, 83, '_categ_button_link', 'field_66f6ec81591d1'),
(353, 83, 'icon_title', 'Finest ethical and sustainable products'),
(354, 83, '_icon_title', 'field_66f6ed3bace0c'),
(355, 83, 'icon_details', '4'),
(356, 83, '_icon_details', 'field_66f6ed42ace0d'),
(357, 83, 'ab_background_image', '88'),
(358, 83, '_ab_background_image', 'field_66f6edf727793'),
(359, 83, 'ab_heading', 'About Crosstherads'),
(360, 83, '_ab_heading', 'field_66f6ee4c27797'),
(361, 83, 'ab_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(362, 83, '_ab_content', 'field_66f6ee5027798'),
(363, 83, 'ab_button_text', 'Learn More'),
(364, 83, '_ab_button_text', 'field_66f6ee3b27795'),
(365, 83, 'ab_button_link', 'a:3:{s:5:"title";s:8:"About Us";s:3:"url";s:44:"http://localhost/crossthreads/site/about-us/";s:6:"target";s:0:"";}'),
(366, 83, '_ab_button_link', 'field_66f6ee4127796'),
(367, 83, 'season_title', 'Seasonal Products'),
(368, 83, '_season_title', 'field_66f6ef5882d5b'),
(369, 83, 'sea_prod', '3'),
(370, 83, '_sea_prod', 'field_66f6ef8b82d5c'),
(371, 83, 'coll_button_text', ''),
(372, 83, '_coll_button_text', 'field_66f6f0a26790d'),
(373, 83, 'coll_button_link', ''),
(374, 83, '_coll_button_link', 'field_66f6f0a66790e'),
(375, 83, 'discount_prod', '2'),
(376, 83, '_discount_prod', 'field_66f6f130f781c'),
(377, 83, 'cust_title', 'Happy Customers'),
(378, 83, '_cust_title', 'field_66f6fca3242e1'),
(379, 83, 'customers_quotes', '3'),
(380, 83, '_customers_quotes', 'field_66f6fcb5242e2'),
(381, 83, 'product_slider', ''),
(382, 83, '_product_slider', 'field_66f6fd852dbae'),
(383, 83, 'icon_details_0_icon_image', '84'),
(384, 83, '_icon_details_0_icon_image', 'field_66f6ed42ace0f'),
(385, 83, 'icon_details_0_icon_name', 'Sustainable Materials'),
(386, 83, '_icon_details_0_icon_name', 'field_66f6ed42ace0e'),
(387, 83, 'icon_details_1_icon_image', '87'),
(388, 83, '_icon_details_1_icon_image', 'field_66f6ed42ace0f'),
(389, 83, 'icon_details_1_icon_name', 'Garment Care'),
(390, 83, '_icon_details_1_icon_name', 'field_66f6ed42ace0e'),
(391, 83, 'icon_details_2_icon_image', '86'),
(392, 83, '_icon_details_2_icon_image', 'field_66f6ed42ace0f'),
(393, 83, 'icon_details_2_icon_name', 'Recycled/ Upcycled'),
(394, 83, '_icon_details_2_icon_name', 'field_66f6ed42ace0e'),
(395, 83, 'icon_details_3_icon_image', '85'),
(396, 83, '_icon_details_3_icon_image', 'field_66f6ed42ace0f'),
(397, 83, 'icon_details_3_icon_name', 'Made in INDIA'),
(398, 83, '_icon_details_3_icon_name', 'field_66f6ed42ace0e'),
(399, 83, 'sea_prod_0_prod_name', 'Organic Linen Shirt'),
(400, 83, '_sea_prod_0_prod_name', 'field_66f6ef8b82d5d'),
(401, 83, 'sea_prod_0_prod_image', '90'),
(402, 83, '_sea_prod_0_prod_image', 'field_66f6ef8b82d5e'),
(403, 83, 'sea_prod_0_prod_link', ''),
(404, 83, '_sea_prod_0_prod_link', 'field_66f6ef8b82d5f'),
(405, 83, 'sea_prod_0_prod_price', '$49.99') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(406, 83, '_sea_prod_0_prod_price', 'field_66f6efca82d60'),
(407, 83, 'sea_prod_0_prod_button_link', ''),
(408, 83, '_sea_prod_0_prod_button_link', 'field_66f6f07082d61'),
(409, 83, 'sea_prod_1_prod_name', 'Organic Cotton Button-Up'),
(410, 83, '_sea_prod_1_prod_name', 'field_66f6ef8b82d5d'),
(411, 83, 'sea_prod_1_prod_image', '89'),
(412, 83, '_sea_prod_1_prod_image', 'field_66f6ef8b82d5e'),
(413, 83, 'sea_prod_1_prod_link', ''),
(414, 83, '_sea_prod_1_prod_link', 'field_66f6ef8b82d5f'),
(415, 83, 'sea_prod_1_prod_price', '$49.99'),
(416, 83, '_sea_prod_1_prod_price', 'field_66f6efca82d60'),
(417, 83, 'sea_prod_1_prod_button_link', ''),
(418, 83, '_sea_prod_1_prod_button_link', 'field_66f6f07082d61'),
(419, 83, 'sea_prod_2_prod_name', 'Sustainable Classic'),
(420, 83, '_sea_prod_2_prod_name', 'field_66f6ef8b82d5d'),
(421, 83, 'sea_prod_2_prod_image', '91'),
(422, 83, '_sea_prod_2_prod_image', 'field_66f6ef8b82d5e'),
(423, 83, 'sea_prod_2_prod_link', ''),
(424, 83, '_sea_prod_2_prod_link', 'field_66f6ef8b82d5f'),
(425, 83, 'sea_prod_2_prod_price', '$49.99'),
(426, 83, '_sea_prod_2_prod_price', 'field_66f6efca82d60'),
(427, 83, 'sea_prod_2_prod_button_link', ''),
(428, 83, '_sea_prod_2_prod_button_link', 'field_66f6f07082d61'),
(429, 83, 'discount_prod_0_disc_prod_image', '92'),
(430, 83, '_discount_prod_0_disc_prod_image', 'field_66f6f130f781e'),
(431, 83, 'discount_prod_0_disc_percentage', '15%'),
(432, 83, '_discount_prod_0_disc_percentage', 'field_66f6f130f781f'),
(433, 83, 'discount_prod_0_disc_prod_name', 'Herbal Series Linen Shirt'),
(434, 83, '_discount_prod_0_disc_prod_name', 'field_66f6f130f781d'),
(435, 83, 'discount_prod_0_disc_prod_price', '$49.99'),
(436, 83, '_discount_prod_0_disc_prod_price', 'field_66f6f130f7820'),
(437, 83, 'discount_prod_0_prod_button_link', ''),
(438, 83, '_discount_prod_0_prod_button_link', 'field_66f6f130f7821'),
(439, 83, 'discount_prod_1_disc_prod_image', '93'),
(440, 83, '_discount_prod_1_disc_prod_image', 'field_66f6f130f781e'),
(441, 83, 'discount_prod_1_disc_percentage', '30%'),
(442, 83, '_discount_prod_1_disc_percentage', 'field_66f6f130f781f'),
(443, 83, 'discount_prod_1_disc_prod_name', 'Herbal Series Linen Shirt'),
(444, 83, '_discount_prod_1_disc_prod_name', 'field_66f6f130f781d'),
(445, 83, 'discount_prod_1_disc_prod_price', '$49.99'),
(446, 83, '_discount_prod_1_disc_prod_price', 'field_66f6f130f7820'),
(447, 83, 'discount_prod_1_prod_button_link', ''),
(448, 83, '_discount_prod_1_prod_button_link', 'field_66f6f130f7821'),
(449, 83, 'customers_quotes_0_cust_image', '94'),
(450, 83, '_customers_quotes_0_cust_image', 'field_66f6fcb5242e3'),
(451, 83, 'customers_quotes_0_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(452, 83, '_customers_quotes_0_cust_content', 'field_66f6fcb5242e4'),
(453, 83, 'customers_quotes_0_cust_name', 'Deepson'),
(454, 83, '_customers_quotes_0_cust_name', 'field_66f6fcb5242e5'),
(455, 83, 'customers_quotes_0_cust_rating', '95'),
(456, 83, '_customers_quotes_0_cust_rating', 'field_66f6fcb5242e6'),
(457, 83, 'customers_quotes_1_cust_image', '94'),
(458, 83, '_customers_quotes_1_cust_image', 'field_66f6fcb5242e3'),
(459, 83, 'customers_quotes_1_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(460, 83, '_customers_quotes_1_cust_content', 'field_66f6fcb5242e4'),
(461, 83, 'customers_quotes_1_cust_name', 'Deepson'),
(462, 83, '_customers_quotes_1_cust_name', 'field_66f6fcb5242e5'),
(463, 83, 'customers_quotes_1_cust_rating', '95'),
(464, 83, '_customers_quotes_1_cust_rating', 'field_66f6fcb5242e6'),
(465, 83, 'customers_quotes_2_cust_image', '94'),
(466, 83, '_customers_quotes_2_cust_image', 'field_66f6fcb5242e3'),
(467, 83, 'customers_quotes_2_cust_content', ''),
(468, 83, '_customers_quotes_2_cust_content', 'field_66f6fcb5242e4'),
(469, 83, 'customers_quotes_2_cust_name', ''),
(470, 83, '_customers_quotes_2_cust_name', 'field_66f6fcb5242e5'),
(471, 83, 'customers_quotes_2_cust_rating', '95'),
(472, 83, '_customers_quotes_2_cust_rating', 'field_66f6fcb5242e6'),
(473, 97, '_wp_attached_file', '2024/09/banner-inner-one.jpg'),
(474, 97, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1024;s:4:"file";s:28:"2024/09/banner-inner-one.jpg";s:8:"filesize";i:838482;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(475, 98, '_wp_attached_file', '2024/09/banner-thre.jpg'),
(476, 98, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1380;s:6:"height";i:800;s:4:"file";s:23:"2024/09/banner-thre.jpg";s:8:"filesize";i:166691;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(477, 99, '_wp_attached_file', '2024/09/banner-four.jpg'),
(478, 99, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1380;s:6:"height";i:800;s:4:"file";s:23:"2024/09/banner-four.jpg";s:8:"filesize";i:120499;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(479, 100, '_wp_attached_file', '2024/09/banner-five.jpg'),
(480, 100, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1380;s:6:"height";i:800;s:4:"file";s:23:"2024/09/banner-five.jpg";s:8:"filesize";i:252839;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(481, 5, 'product_slider_0_slider_prod_image', '97'),
(482, 5, '_product_slider_0_slider_prod_image', 'field_66f6fd852dbaf'),
(483, 5, 'product_slider_0_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(484, 5, '_product_slider_0_slider_prod_name', 'field_66f6fd852dbb1'),
(485, 5, 'product_slider_0_slider_prod_price', '$49.99'),
(486, 5, '_product_slider_0_slider_prod_price', 'field_66f6fd852dbb2'),
(487, 5, 'product_slider_0_slider_detail_link', ''),
(488, 5, '_product_slider_0_slider_detail_link', 'field_66f6fd852dbb3'),
(489, 5, 'product_slider_0_slider_buy_link', ''),
(490, 5, '_product_slider_0_slider_buy_link', 'field_66f6fdf12dbb4'),
(491, 5, 'product_slider_1_slider_prod_image', '98'),
(492, 5, '_product_slider_1_slider_prod_image', 'field_66f6fd852dbaf'),
(493, 5, 'product_slider_1_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(494, 5, '_product_slider_1_slider_prod_name', 'field_66f6fd852dbb1'),
(495, 5, 'product_slider_1_slider_prod_price', '$49.99'),
(496, 5, '_product_slider_1_slider_prod_price', 'field_66f6fd852dbb2'),
(497, 5, 'product_slider_1_slider_detail_link', ''),
(498, 5, '_product_slider_1_slider_detail_link', 'field_66f6fd852dbb3'),
(499, 5, 'product_slider_1_slider_buy_link', ''),
(500, 5, '_product_slider_1_slider_buy_link', 'field_66f6fdf12dbb4'),
(501, 5, 'product_slider_2_slider_prod_image', '99'),
(502, 5, '_product_slider_2_slider_prod_image', 'field_66f6fd852dbaf'),
(503, 5, 'product_slider_2_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(504, 5, '_product_slider_2_slider_prod_name', 'field_66f6fd852dbb1'),
(505, 5, 'product_slider_2_slider_prod_price', '$49.99') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(506, 5, '_product_slider_2_slider_prod_price', 'field_66f6fd852dbb2'),
(507, 5, 'product_slider_2_slider_detail_link', ''),
(508, 5, '_product_slider_2_slider_detail_link', 'field_66f6fd852dbb3'),
(509, 5, 'product_slider_2_slider_buy_link', ''),
(510, 5, '_product_slider_2_slider_buy_link', 'field_66f6fdf12dbb4'),
(511, 5, 'product_slider_3_slider_prod_image', '100'),
(512, 5, '_product_slider_3_slider_prod_image', 'field_66f6fd852dbaf'),
(513, 5, 'product_slider_3_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(514, 5, '_product_slider_3_slider_prod_name', 'field_66f6fd852dbb1'),
(515, 5, 'product_slider_3_slider_prod_price', '$49.99'),
(516, 5, '_product_slider_3_slider_prod_price', 'field_66f6fd852dbb2'),
(517, 5, 'product_slider_3_slider_detail_link', ''),
(518, 5, '_product_slider_3_slider_detail_link', 'field_66f6fd852dbb3'),
(519, 5, 'product_slider_3_slider_buy_link', ''),
(520, 5, '_product_slider_3_slider_buy_link', 'field_66f6fdf12dbb4'),
(521, 96, 'banner_heading', 'Wear your values.'),
(522, 96, '_banner_heading', 'field_66f6eaf08a8c6'),
(523, 96, 'banner_content', 'Choose Crossthreads for ethically crafted, sustainable fashion.'),
(524, 96, '_banner_content', 'field_66f6eb3c8a8c7'),
(525, 96, 'categ_title', 'From earth to your wardrobe'),
(526, 96, '_categ_title', 'field_66f6eb7a03748'),
(527, 96, 'prod_categories_0_categ_name', 'MEN'),
(528, 96, '_prod_categories_0_categ_name', 'field_66f6ebe60374a'),
(529, 96, 'prod_categories_0_categ_image', ''),
(530, 96, '_prod_categories_0_categ_image', 'field_66f6ec080374b'),
(531, 96, 'prod_categories_0_categ_link', ''),
(532, 96, '_prod_categories_0_categ_link', 'field_66f6ec470374c'),
(533, 96, 'prod_categories_1_categ_name', 'WOMEN'),
(534, 96, '_prod_categories_1_categ_name', 'field_66f6ebe60374a'),
(535, 96, 'prod_categories_1_categ_image', ''),
(536, 96, '_prod_categories_1_categ_image', 'field_66f6ec080374b'),
(537, 96, 'prod_categories_1_categ_link', ''),
(538, 96, '_prod_categories_1_categ_link', 'field_66f6ec470374c'),
(539, 96, 'prod_categories_2_categ_name', 'Kids'),
(540, 96, '_prod_categories_2_categ_name', 'field_66f6ebe60374a'),
(541, 96, 'prod_categories_2_categ_image', ''),
(542, 96, '_prod_categories_2_categ_image', 'field_66f6ec080374b'),
(543, 96, 'prod_categories_2_categ_link', ''),
(544, 96, '_prod_categories_2_categ_link', 'field_66f6ec470374c'),
(545, 96, 'prod_categories_3_categ_name', 'Wellness Cloths'),
(546, 96, '_prod_categories_3_categ_name', 'field_66f6ebe60374a'),
(547, 96, 'prod_categories_3_categ_image', ''),
(548, 96, '_prod_categories_3_categ_image', 'field_66f6ec080374b'),
(549, 96, 'prod_categories_3_categ_link', ''),
(550, 96, '_prod_categories_3_categ_link', 'field_66f6ec470374c'),
(551, 96, 'prod_categories', '4'),
(552, 96, '_prod_categories', 'field_66f6ebc803749'),
(553, 96, 'categ_button_text', 'See All'),
(554, 96, '_categ_button_text', 'field_66f6ec6d591d0'),
(555, 96, 'categ_button_link', ''),
(556, 96, '_categ_button_link', 'field_66f6ec81591d1'),
(557, 96, 'icon_title', 'Finest ethical and sustainable products'),
(558, 96, '_icon_title', 'field_66f6ed3bace0c'),
(559, 96, 'icon_details', '4'),
(560, 96, '_icon_details', 'field_66f6ed42ace0d'),
(561, 96, 'ab_background_image', '88'),
(562, 96, '_ab_background_image', 'field_66f6edf727793'),
(563, 96, 'ab_heading', 'About Crosstherads'),
(564, 96, '_ab_heading', 'field_66f6ee4c27797'),
(565, 96, 'ab_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(566, 96, '_ab_content', 'field_66f6ee5027798'),
(567, 96, 'ab_button_text', 'Learn More'),
(568, 96, '_ab_button_text', 'field_66f6ee3b27795'),
(569, 96, 'ab_button_link', 'a:3:{s:5:"title";s:8:"About Us";s:3:"url";s:44:"http://localhost/crossthreads/site/about-us/";s:6:"target";s:0:"";}'),
(570, 96, '_ab_button_link', 'field_66f6ee4127796'),
(571, 96, 'season_title', 'Seasonal Products'),
(572, 96, '_season_title', 'field_66f6ef5882d5b'),
(573, 96, 'sea_prod', '3'),
(574, 96, '_sea_prod', 'field_66f6ef8b82d5c'),
(575, 96, 'coll_button_text', ''),
(576, 96, '_coll_button_text', 'field_66f6f0a26790d'),
(577, 96, 'coll_button_link', ''),
(578, 96, '_coll_button_link', 'field_66f6f0a66790e'),
(579, 96, 'discount_prod', '2'),
(580, 96, '_discount_prod', 'field_66f6f130f781c'),
(581, 96, 'cust_title', 'Happy Customers'),
(582, 96, '_cust_title', 'field_66f6fca3242e1'),
(583, 96, 'customers_quotes', '3'),
(584, 96, '_customers_quotes', 'field_66f6fcb5242e2'),
(585, 96, 'product_slider', '4'),
(586, 96, '_product_slider', 'field_66f6fd852dbae'),
(587, 96, 'icon_details_0_icon_image', '84'),
(588, 96, '_icon_details_0_icon_image', 'field_66f6ed42ace0f'),
(589, 96, 'icon_details_0_icon_name', 'Sustainable Materials'),
(590, 96, '_icon_details_0_icon_name', 'field_66f6ed42ace0e'),
(591, 96, 'icon_details_1_icon_image', '87'),
(592, 96, '_icon_details_1_icon_image', 'field_66f6ed42ace0f'),
(593, 96, 'icon_details_1_icon_name', 'Garment Care'),
(594, 96, '_icon_details_1_icon_name', 'field_66f6ed42ace0e'),
(595, 96, 'icon_details_2_icon_image', '86'),
(596, 96, '_icon_details_2_icon_image', 'field_66f6ed42ace0f'),
(597, 96, 'icon_details_2_icon_name', 'Recycled/ Upcycled'),
(598, 96, '_icon_details_2_icon_name', 'field_66f6ed42ace0e'),
(599, 96, 'icon_details_3_icon_image', '85'),
(600, 96, '_icon_details_3_icon_image', 'field_66f6ed42ace0f'),
(601, 96, 'icon_details_3_icon_name', 'Made in INDIA'),
(602, 96, '_icon_details_3_icon_name', 'field_66f6ed42ace0e'),
(603, 96, 'sea_prod_0_prod_name', 'Organic Linen Shirt'),
(604, 96, '_sea_prod_0_prod_name', 'field_66f6ef8b82d5d'),
(605, 96, 'sea_prod_0_prod_image', '90') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(606, 96, '_sea_prod_0_prod_image', 'field_66f6ef8b82d5e'),
(607, 96, 'sea_prod_0_prod_link', ''),
(608, 96, '_sea_prod_0_prod_link', 'field_66f6ef8b82d5f'),
(609, 96, 'sea_prod_0_prod_price', '$49.99'),
(610, 96, '_sea_prod_0_prod_price', 'field_66f6efca82d60'),
(611, 96, 'sea_prod_0_prod_button_link', ''),
(612, 96, '_sea_prod_0_prod_button_link', 'field_66f6f07082d61'),
(613, 96, 'sea_prod_1_prod_name', 'Organic Cotton Button-Up'),
(614, 96, '_sea_prod_1_prod_name', 'field_66f6ef8b82d5d'),
(615, 96, 'sea_prod_1_prod_image', '89'),
(616, 96, '_sea_prod_1_prod_image', 'field_66f6ef8b82d5e'),
(617, 96, 'sea_prod_1_prod_link', ''),
(618, 96, '_sea_prod_1_prod_link', 'field_66f6ef8b82d5f'),
(619, 96, 'sea_prod_1_prod_price', '$49.99'),
(620, 96, '_sea_prod_1_prod_price', 'field_66f6efca82d60'),
(621, 96, 'sea_prod_1_prod_button_link', ''),
(622, 96, '_sea_prod_1_prod_button_link', 'field_66f6f07082d61'),
(623, 96, 'sea_prod_2_prod_name', 'Sustainable Classic'),
(624, 96, '_sea_prod_2_prod_name', 'field_66f6ef8b82d5d'),
(625, 96, 'sea_prod_2_prod_image', '91'),
(626, 96, '_sea_prod_2_prod_image', 'field_66f6ef8b82d5e'),
(627, 96, 'sea_prod_2_prod_link', ''),
(628, 96, '_sea_prod_2_prod_link', 'field_66f6ef8b82d5f'),
(629, 96, 'sea_prod_2_prod_price', '$49.99'),
(630, 96, '_sea_prod_2_prod_price', 'field_66f6efca82d60'),
(631, 96, 'sea_prod_2_prod_button_link', ''),
(632, 96, '_sea_prod_2_prod_button_link', 'field_66f6f07082d61'),
(633, 96, 'discount_prod_0_disc_prod_image', '92'),
(634, 96, '_discount_prod_0_disc_prod_image', 'field_66f6f130f781e'),
(635, 96, 'discount_prod_0_disc_percentage', '15%'),
(636, 96, '_discount_prod_0_disc_percentage', 'field_66f6f130f781f'),
(637, 96, 'discount_prod_0_disc_prod_name', 'Herbal Series Linen Shirt'),
(638, 96, '_discount_prod_0_disc_prod_name', 'field_66f6f130f781d'),
(639, 96, 'discount_prod_0_disc_prod_price', '$49.99'),
(640, 96, '_discount_prod_0_disc_prod_price', 'field_66f6f130f7820'),
(641, 96, 'discount_prod_0_prod_button_link', ''),
(642, 96, '_discount_prod_0_prod_button_link', 'field_66f6f130f7821'),
(643, 96, 'discount_prod_1_disc_prod_image', '93'),
(644, 96, '_discount_prod_1_disc_prod_image', 'field_66f6f130f781e'),
(645, 96, 'discount_prod_1_disc_percentage', '30%'),
(646, 96, '_discount_prod_1_disc_percentage', 'field_66f6f130f781f'),
(647, 96, 'discount_prod_1_disc_prod_name', 'Herbal Series Linen Shirt'),
(648, 96, '_discount_prod_1_disc_prod_name', 'field_66f6f130f781d'),
(649, 96, 'discount_prod_1_disc_prod_price', '$49.99'),
(650, 96, '_discount_prod_1_disc_prod_price', 'field_66f6f130f7820'),
(651, 96, 'discount_prod_1_prod_button_link', ''),
(652, 96, '_discount_prod_1_prod_button_link', 'field_66f6f130f7821'),
(653, 96, 'customers_quotes_0_cust_image', '94'),
(654, 96, '_customers_quotes_0_cust_image', 'field_66f6fcb5242e3'),
(655, 96, 'customers_quotes_0_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(656, 96, '_customers_quotes_0_cust_content', 'field_66f6fcb5242e4'),
(657, 96, 'customers_quotes_0_cust_name', 'Deepson'),
(658, 96, '_customers_quotes_0_cust_name', 'field_66f6fcb5242e5'),
(659, 96, 'customers_quotes_0_cust_rating', '95'),
(660, 96, '_customers_quotes_0_cust_rating', 'field_66f6fcb5242e6'),
(661, 96, 'customers_quotes_1_cust_image', '94'),
(662, 96, '_customers_quotes_1_cust_image', 'field_66f6fcb5242e3'),
(663, 96, 'customers_quotes_1_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(664, 96, '_customers_quotes_1_cust_content', 'field_66f6fcb5242e4'),
(665, 96, 'customers_quotes_1_cust_name', 'Deepson'),
(666, 96, '_customers_quotes_1_cust_name', 'field_66f6fcb5242e5'),
(667, 96, 'customers_quotes_1_cust_rating', '95'),
(668, 96, '_customers_quotes_1_cust_rating', 'field_66f6fcb5242e6'),
(669, 96, 'customers_quotes_2_cust_image', '94'),
(670, 96, '_customers_quotes_2_cust_image', 'field_66f6fcb5242e3'),
(671, 96, 'customers_quotes_2_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(672, 96, '_customers_quotes_2_cust_content', 'field_66f6fcb5242e4'),
(673, 96, 'customers_quotes_2_cust_name', 'Deepson'),
(674, 96, '_customers_quotes_2_cust_name', 'field_66f6fcb5242e5'),
(675, 96, 'customers_quotes_2_cust_rating', '95'),
(676, 96, '_customers_quotes_2_cust_rating', 'field_66f6fcb5242e6'),
(677, 96, 'product_slider_0_slider_prod_image', '97'),
(678, 96, '_product_slider_0_slider_prod_image', 'field_66f6fd852dbaf'),
(679, 96, 'product_slider_0_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(680, 96, '_product_slider_0_slider_prod_name', 'field_66f6fd852dbb1'),
(681, 96, 'product_slider_0_slider_prod_price', '$49.99'),
(682, 96, '_product_slider_0_slider_prod_price', 'field_66f6fd852dbb2'),
(683, 96, 'product_slider_0_slider_detail_link', ''),
(684, 96, '_product_slider_0_slider_detail_link', 'field_66f6fd852dbb3'),
(685, 96, 'product_slider_0_slider_buy_link', ''),
(686, 96, '_product_slider_0_slider_buy_link', 'field_66f6fdf12dbb4'),
(687, 96, 'product_slider_1_slider_prod_image', '98'),
(688, 96, '_product_slider_1_slider_prod_image', 'field_66f6fd852dbaf'),
(689, 96, 'product_slider_1_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(690, 96, '_product_slider_1_slider_prod_name', 'field_66f6fd852dbb1'),
(691, 96, 'product_slider_1_slider_prod_price', '$49.99'),
(692, 96, '_product_slider_1_slider_prod_price', 'field_66f6fd852dbb2'),
(693, 96, 'product_slider_1_slider_detail_link', ''),
(694, 96, '_product_slider_1_slider_detail_link', 'field_66f6fd852dbb3'),
(695, 96, 'product_slider_1_slider_buy_link', ''),
(696, 96, '_product_slider_1_slider_buy_link', 'field_66f6fdf12dbb4'),
(697, 96, 'product_slider_2_slider_prod_image', '99'),
(698, 96, '_product_slider_2_slider_prod_image', 'field_66f6fd852dbaf'),
(699, 96, 'product_slider_2_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(700, 96, '_product_slider_2_slider_prod_name', 'field_66f6fd852dbb1'),
(701, 96, 'product_slider_2_slider_prod_price', '$49.99'),
(702, 96, '_product_slider_2_slider_prod_price', 'field_66f6fd852dbb2'),
(703, 96, 'product_slider_2_slider_detail_link', ''),
(704, 96, '_product_slider_2_slider_detail_link', 'field_66f6fd852dbb3'),
(705, 96, 'product_slider_2_slider_buy_link', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(706, 96, '_product_slider_2_slider_buy_link', 'field_66f6fdf12dbb4'),
(707, 96, 'product_slider_3_slider_prod_image', '100'),
(708, 96, '_product_slider_3_slider_prod_image', 'field_66f6fd852dbaf'),
(709, 96, 'product_slider_3_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(710, 96, '_product_slider_3_slider_prod_name', 'field_66f6fd852dbb1'),
(711, 96, 'product_slider_3_slider_prod_price', '$49.99'),
(712, 96, '_product_slider_3_slider_prod_price', 'field_66f6fd852dbb2'),
(713, 96, 'product_slider_3_slider_detail_link', ''),
(714, 96, '_product_slider_3_slider_detail_link', 'field_66f6fd852dbb3'),
(715, 96, 'product_slider_3_slider_buy_link', ''),
(716, 96, '_product_slider_3_slider_buy_link', 'field_66f6fdf12dbb4'),
(717, 101, 'banner_heading', 'Wear your values.'),
(718, 101, '_banner_heading', 'field_66f6eaf08a8c6'),
(719, 101, 'banner_content', 'Choose Crossthreads for ethically crafted, sustainable fashion.'),
(720, 101, '_banner_content', 'field_66f6eb3c8a8c7'),
(721, 101, 'categ_title', 'From earth to your wardrobe'),
(722, 101, '_categ_title', 'field_66f6eb7a03748'),
(723, 101, 'prod_categories_0_categ_name', 'MEN'),
(724, 101, '_prod_categories_0_categ_name', 'field_66f6ebe60374a'),
(725, 101, 'prod_categories_0_categ_image', ''),
(726, 101, '_prod_categories_0_categ_image', 'field_66f6ec080374b'),
(727, 101, 'prod_categories_0_categ_link', ''),
(728, 101, '_prod_categories_0_categ_link', 'field_66f6ec470374c'),
(729, 101, 'prod_categories_1_categ_name', 'WOMEN'),
(730, 101, '_prod_categories_1_categ_name', 'field_66f6ebe60374a'),
(731, 101, 'prod_categories_1_categ_image', ''),
(732, 101, '_prod_categories_1_categ_image', 'field_66f6ec080374b'),
(733, 101, 'prod_categories_1_categ_link', ''),
(734, 101, '_prod_categories_1_categ_link', 'field_66f6ec470374c'),
(735, 101, 'prod_categories_2_categ_name', 'Kids'),
(736, 101, '_prod_categories_2_categ_name', 'field_66f6ebe60374a'),
(737, 101, 'prod_categories_2_categ_image', ''),
(738, 101, '_prod_categories_2_categ_image', 'field_66f6ec080374b'),
(739, 101, 'prod_categories_2_categ_link', ''),
(740, 101, '_prod_categories_2_categ_link', 'field_66f6ec470374c'),
(741, 101, 'prod_categories_3_categ_name', 'Wellness Cloths'),
(742, 101, '_prod_categories_3_categ_name', 'field_66f6ebe60374a'),
(743, 101, 'prod_categories_3_categ_image', ''),
(744, 101, '_prod_categories_3_categ_image', 'field_66f6ec080374b'),
(745, 101, 'prod_categories_3_categ_link', ''),
(746, 101, '_prod_categories_3_categ_link', 'field_66f6ec470374c'),
(747, 101, 'prod_categories', '4'),
(748, 101, '_prod_categories', 'field_66f6ebc803749'),
(749, 101, 'categ_button_text', 'See All'),
(750, 101, '_categ_button_text', 'field_66f6ec6d591d0'),
(751, 101, 'categ_button_link', ''),
(752, 101, '_categ_button_link', 'field_66f6ec81591d1'),
(753, 101, 'icon_title', 'Finest ethical and sustainable products'),
(754, 101, '_icon_title', 'field_66f6ed3bace0c'),
(755, 101, 'icon_details', '4'),
(756, 101, '_icon_details', 'field_66f6ed42ace0d'),
(757, 101, 'ab_background_image', '88'),
(758, 101, '_ab_background_image', 'field_66f6edf727793'),
(759, 101, 'ab_heading', 'About Crosstherads'),
(760, 101, '_ab_heading', 'field_66f6ee4c27797'),
(761, 101, 'ab_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(762, 101, '_ab_content', 'field_66f6ee5027798'),
(763, 101, 'ab_button_text', 'Learn More'),
(764, 101, '_ab_button_text', 'field_66f6ee3b27795'),
(765, 101, 'ab_button_link', 'a:3:{s:5:"title";s:8:"About Us";s:3:"url";s:44:"http://localhost/crossthreads/site/about-us/";s:6:"target";s:0:"";}'),
(766, 101, '_ab_button_link', 'field_66f6ee4127796'),
(767, 101, 'season_title', 'Seasonal Products'),
(768, 101, '_season_title', 'field_66f6ef5882d5b'),
(769, 101, 'sea_prod', '3'),
(770, 101, '_sea_prod', 'field_66f6ef8b82d5c'),
(771, 101, 'coll_button_text', 'See All Collections'),
(772, 101, '_coll_button_text', 'field_66f6f0a26790d'),
(773, 101, 'coll_button_link', ''),
(774, 101, '_coll_button_link', 'field_66f6f0a66790e'),
(775, 101, 'discount_prod', '2'),
(776, 101, '_discount_prod', 'field_66f6f130f781c'),
(777, 101, 'cust_title', 'Happy Customers'),
(778, 101, '_cust_title', 'field_66f6fca3242e1'),
(779, 101, 'customers_quotes', '3'),
(780, 101, '_customers_quotes', 'field_66f6fcb5242e2'),
(781, 101, 'product_slider', '4'),
(782, 101, '_product_slider', 'field_66f6fd852dbae'),
(783, 101, 'icon_details_0_icon_image', '84'),
(784, 101, '_icon_details_0_icon_image', 'field_66f6ed42ace0f'),
(785, 101, 'icon_details_0_icon_name', 'Sustainable Materials'),
(786, 101, '_icon_details_0_icon_name', 'field_66f6ed42ace0e'),
(787, 101, 'icon_details_1_icon_image', '87'),
(788, 101, '_icon_details_1_icon_image', 'field_66f6ed42ace0f'),
(789, 101, 'icon_details_1_icon_name', 'Garment Care'),
(790, 101, '_icon_details_1_icon_name', 'field_66f6ed42ace0e'),
(791, 101, 'icon_details_2_icon_image', '86'),
(792, 101, '_icon_details_2_icon_image', 'field_66f6ed42ace0f'),
(793, 101, 'icon_details_2_icon_name', 'Recycled/ Upcycled'),
(794, 101, '_icon_details_2_icon_name', 'field_66f6ed42ace0e'),
(795, 101, 'icon_details_3_icon_image', '85'),
(796, 101, '_icon_details_3_icon_image', 'field_66f6ed42ace0f'),
(797, 101, 'icon_details_3_icon_name', 'Made in INDIA'),
(798, 101, '_icon_details_3_icon_name', 'field_66f6ed42ace0e'),
(799, 101, 'sea_prod_0_prod_name', 'Organic Linen Shirt'),
(800, 101, '_sea_prod_0_prod_name', 'field_66f6ef8b82d5d'),
(801, 101, 'sea_prod_0_prod_image', '90'),
(802, 101, '_sea_prod_0_prod_image', 'field_66f6ef8b82d5e'),
(803, 101, 'sea_prod_0_prod_link', ''),
(804, 101, '_sea_prod_0_prod_link', 'field_66f6ef8b82d5f'),
(805, 101, 'sea_prod_0_prod_price', '$49.99') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(806, 101, '_sea_prod_0_prod_price', 'field_66f6efca82d60'),
(807, 101, 'sea_prod_0_prod_button_link', ''),
(808, 101, '_sea_prod_0_prod_button_link', 'field_66f6f07082d61'),
(809, 101, 'sea_prod_1_prod_name', 'Organic Cotton Button-Up'),
(810, 101, '_sea_prod_1_prod_name', 'field_66f6ef8b82d5d'),
(811, 101, 'sea_prod_1_prod_image', '89'),
(812, 101, '_sea_prod_1_prod_image', 'field_66f6ef8b82d5e'),
(813, 101, 'sea_prod_1_prod_link', ''),
(814, 101, '_sea_prod_1_prod_link', 'field_66f6ef8b82d5f'),
(815, 101, 'sea_prod_1_prod_price', '$49.99'),
(816, 101, '_sea_prod_1_prod_price', 'field_66f6efca82d60'),
(817, 101, 'sea_prod_1_prod_button_link', ''),
(818, 101, '_sea_prod_1_prod_button_link', 'field_66f6f07082d61'),
(819, 101, 'sea_prod_2_prod_name', 'Sustainable Classic'),
(820, 101, '_sea_prod_2_prod_name', 'field_66f6ef8b82d5d'),
(821, 101, 'sea_prod_2_prod_image', '91'),
(822, 101, '_sea_prod_2_prod_image', 'field_66f6ef8b82d5e'),
(823, 101, 'sea_prod_2_prod_link', ''),
(824, 101, '_sea_prod_2_prod_link', 'field_66f6ef8b82d5f'),
(825, 101, 'sea_prod_2_prod_price', '$49.99'),
(826, 101, '_sea_prod_2_prod_price', 'field_66f6efca82d60'),
(827, 101, 'sea_prod_2_prod_button_link', ''),
(828, 101, '_sea_prod_2_prod_button_link', 'field_66f6f07082d61'),
(829, 101, 'discount_prod_0_disc_prod_image', '92'),
(830, 101, '_discount_prod_0_disc_prod_image', 'field_66f6f130f781e'),
(831, 101, 'discount_prod_0_disc_percentage', '15%'),
(832, 101, '_discount_prod_0_disc_percentage', 'field_66f6f130f781f'),
(833, 101, 'discount_prod_0_disc_prod_name', 'Herbal Series Linen Shirt'),
(834, 101, '_discount_prod_0_disc_prod_name', 'field_66f6f130f781d'),
(835, 101, 'discount_prod_0_disc_prod_price', '$49.99'),
(836, 101, '_discount_prod_0_disc_prod_price', 'field_66f6f130f7820'),
(837, 101, 'discount_prod_0_prod_button_link', ''),
(838, 101, '_discount_prod_0_prod_button_link', 'field_66f6f130f7821'),
(839, 101, 'discount_prod_1_disc_prod_image', '93'),
(840, 101, '_discount_prod_1_disc_prod_image', 'field_66f6f130f781e'),
(841, 101, 'discount_prod_1_disc_percentage', '30%'),
(842, 101, '_discount_prod_1_disc_percentage', 'field_66f6f130f781f'),
(843, 101, 'discount_prod_1_disc_prod_name', 'Herbal Series Linen Shirt'),
(844, 101, '_discount_prod_1_disc_prod_name', 'field_66f6f130f781d'),
(845, 101, 'discount_prod_1_disc_prod_price', '$49.99'),
(846, 101, '_discount_prod_1_disc_prod_price', 'field_66f6f130f7820'),
(847, 101, 'discount_prod_1_prod_button_link', ''),
(848, 101, '_discount_prod_1_prod_button_link', 'field_66f6f130f7821'),
(849, 101, 'customers_quotes_0_cust_image', '94'),
(850, 101, '_customers_quotes_0_cust_image', 'field_66f6fcb5242e3'),
(851, 101, 'customers_quotes_0_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(852, 101, '_customers_quotes_0_cust_content', 'field_66f6fcb5242e4'),
(853, 101, 'customers_quotes_0_cust_name', 'Deepson'),
(854, 101, '_customers_quotes_0_cust_name', 'field_66f6fcb5242e5'),
(855, 101, 'customers_quotes_0_cust_rating', '95'),
(856, 101, '_customers_quotes_0_cust_rating', 'field_66f6fcb5242e6'),
(857, 101, 'customers_quotes_1_cust_image', '94'),
(858, 101, '_customers_quotes_1_cust_image', 'field_66f6fcb5242e3'),
(859, 101, 'customers_quotes_1_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(860, 101, '_customers_quotes_1_cust_content', 'field_66f6fcb5242e4'),
(861, 101, 'customers_quotes_1_cust_name', 'Deepson'),
(862, 101, '_customers_quotes_1_cust_name', 'field_66f6fcb5242e5'),
(863, 101, 'customers_quotes_1_cust_rating', '95'),
(864, 101, '_customers_quotes_1_cust_rating', 'field_66f6fcb5242e6'),
(865, 101, 'customers_quotes_2_cust_image', '94'),
(866, 101, '_customers_quotes_2_cust_image', 'field_66f6fcb5242e3'),
(867, 101, 'customers_quotes_2_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(868, 101, '_customers_quotes_2_cust_content', 'field_66f6fcb5242e4'),
(869, 101, 'customers_quotes_2_cust_name', 'Deepson'),
(870, 101, '_customers_quotes_2_cust_name', 'field_66f6fcb5242e5'),
(871, 101, 'customers_quotes_2_cust_rating', '95'),
(872, 101, '_customers_quotes_2_cust_rating', 'field_66f6fcb5242e6'),
(873, 101, 'product_slider_0_slider_prod_image', '97'),
(874, 101, '_product_slider_0_slider_prod_image', 'field_66f6fd852dbaf'),
(875, 101, 'product_slider_0_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(876, 101, '_product_slider_0_slider_prod_name', 'field_66f6fd852dbb1'),
(877, 101, 'product_slider_0_slider_prod_price', '$49.99'),
(878, 101, '_product_slider_0_slider_prod_price', 'field_66f6fd852dbb2'),
(879, 101, 'product_slider_0_slider_detail_link', ''),
(880, 101, '_product_slider_0_slider_detail_link', 'field_66f6fd852dbb3'),
(881, 101, 'product_slider_0_slider_buy_link', ''),
(882, 101, '_product_slider_0_slider_buy_link', 'field_66f6fdf12dbb4'),
(883, 101, 'product_slider_1_slider_prod_image', '98'),
(884, 101, '_product_slider_1_slider_prod_image', 'field_66f6fd852dbaf'),
(885, 101, 'product_slider_1_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(886, 101, '_product_slider_1_slider_prod_name', 'field_66f6fd852dbb1'),
(887, 101, 'product_slider_1_slider_prod_price', '$49.99'),
(888, 101, '_product_slider_1_slider_prod_price', 'field_66f6fd852dbb2'),
(889, 101, 'product_slider_1_slider_detail_link', ''),
(890, 101, '_product_slider_1_slider_detail_link', 'field_66f6fd852dbb3'),
(891, 101, 'product_slider_1_slider_buy_link', ''),
(892, 101, '_product_slider_1_slider_buy_link', 'field_66f6fdf12dbb4'),
(893, 101, 'product_slider_2_slider_prod_image', '99'),
(894, 101, '_product_slider_2_slider_prod_image', 'field_66f6fd852dbaf'),
(895, 101, 'product_slider_2_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(896, 101, '_product_slider_2_slider_prod_name', 'field_66f6fd852dbb1'),
(897, 101, 'product_slider_2_slider_prod_price', '$49.99'),
(898, 101, '_product_slider_2_slider_prod_price', 'field_66f6fd852dbb2'),
(899, 101, 'product_slider_2_slider_detail_link', ''),
(900, 101, '_product_slider_2_slider_detail_link', 'field_66f6fd852dbb3'),
(901, 101, 'product_slider_2_slider_buy_link', ''),
(902, 101, '_product_slider_2_slider_buy_link', 'field_66f6fdf12dbb4'),
(903, 101, 'product_slider_3_slider_prod_image', '100'),
(904, 101, '_product_slider_3_slider_prod_image', 'field_66f6fd852dbaf'),
(905, 101, 'product_slider_3_slider_prod_name', 'Suspender Skirt With Shirt Set') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(906, 101, '_product_slider_3_slider_prod_name', 'field_66f6fd852dbb1'),
(907, 101, 'product_slider_3_slider_prod_price', '$49.99'),
(908, 101, '_product_slider_3_slider_prod_price', 'field_66f6fd852dbb2'),
(909, 101, 'product_slider_3_slider_detail_link', ''),
(910, 101, '_product_slider_3_slider_detail_link', 'field_66f6fd852dbb3'),
(911, 101, 'product_slider_3_slider_buy_link', ''),
(912, 101, '_product_slider_3_slider_buy_link', 'field_66f6fdf12dbb4'),
(913, 104, '_wp_attached_file', '2024/09/img-one.webp'),
(914, 104, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:439;s:6:"height";i:526;s:4:"file";s:20:"2024/09/img-one.webp";s:8:"filesize";i:14260;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:20:"img-one-250x300.webp";s:5:"width";i:250;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:5418;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"img-one-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:2218;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(915, 105, '_wp_attached_file', '2024/09/img-two.webp'),
(916, 105, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:439;s:6:"height";i:526;s:4:"file";s:20:"2024/09/img-two.webp";s:8:"filesize";i:16988;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:20:"img-two-250x300.webp";s:5:"width";i:250;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7768;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"img-two-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:3700;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(917, 106, '_wp_attached_file', '2024/09/img-three.webp'),
(918, 106, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:439;s:6:"height";i:526;s:4:"file";s:22:"2024/09/img-three.webp";s:8:"filesize";i:18712;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:22:"img-three-250x300.webp";s:5:"width";i:250;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8078;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"img-three-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:3768;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(919, 107, '_wp_attached_file', '2024/09/img-four.webp'),
(920, 107, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:439;s:6:"height";i:526;s:4:"file";s:21:"2024/09/img-four.webp";s:8:"filesize";i:22144;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:21:"img-four-250x300.webp";s:5:"width";i:250;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8020;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"img-four-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:3198;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(921, 102, 'banner_heading', 'Wear your values.'),
(922, 102, '_banner_heading', 'field_66f6eaf08a8c6'),
(923, 102, 'banner_content', 'Choose Crossthreads for ethically crafted, sustainable fashion.'),
(924, 102, '_banner_content', 'field_66f6eb3c8a8c7'),
(925, 102, 'categ_title', 'From earth to your wardrobe'),
(926, 102, '_categ_title', 'field_66f6eb7a03748'),
(927, 102, 'prod_categories_0_categ_name', 'MEN'),
(928, 102, '_prod_categories_0_categ_name', 'field_66f6ebe60374a'),
(929, 102, 'prod_categories_0_categ_image', '104'),
(930, 102, '_prod_categories_0_categ_image', 'field_66f6ec080374b'),
(931, 102, 'prod_categories_0_categ_link', ''),
(932, 102, '_prod_categories_0_categ_link', 'field_66f6ec470374c'),
(933, 102, 'prod_categories_1_categ_name', 'WOMEN'),
(934, 102, '_prod_categories_1_categ_name', 'field_66f6ebe60374a'),
(935, 102, 'prod_categories_1_categ_image', '105'),
(936, 102, '_prod_categories_1_categ_image', 'field_66f6ec080374b'),
(937, 102, 'prod_categories_1_categ_link', ''),
(938, 102, '_prod_categories_1_categ_link', 'field_66f6ec470374c'),
(939, 102, 'prod_categories_2_categ_name', 'Kids'),
(940, 102, '_prod_categories_2_categ_name', 'field_66f6ebe60374a'),
(941, 102, 'prod_categories_2_categ_image', '106'),
(942, 102, '_prod_categories_2_categ_image', 'field_66f6ec080374b'),
(943, 102, 'prod_categories_2_categ_link', ''),
(944, 102, '_prod_categories_2_categ_link', 'field_66f6ec470374c'),
(945, 102, 'prod_categories_3_categ_name', 'Wellness Cloths'),
(946, 102, '_prod_categories_3_categ_name', 'field_66f6ebe60374a'),
(947, 102, 'prod_categories_3_categ_image', '107'),
(948, 102, '_prod_categories_3_categ_image', 'field_66f6ec080374b'),
(949, 102, 'prod_categories_3_categ_link', ''),
(950, 102, '_prod_categories_3_categ_link', 'field_66f6ec470374c'),
(951, 102, 'prod_categories', '4'),
(952, 102, '_prod_categories', 'field_66f6ebc803749'),
(953, 102, 'categ_button_text', 'See All'),
(954, 102, '_categ_button_text', 'field_66f6ec6d591d0'),
(955, 102, 'categ_button_link', ''),
(956, 102, '_categ_button_link', 'field_66f6ec81591d1'),
(957, 102, 'icon_title', 'Finest ethical and sustainable products'),
(958, 102, '_icon_title', 'field_66f6ed3bace0c'),
(959, 102, 'icon_details', '4'),
(960, 102, '_icon_details', 'field_66f6ed42ace0d'),
(961, 102, 'ab_background_image', '88'),
(962, 102, '_ab_background_image', 'field_66f6edf727793'),
(963, 102, 'ab_heading', 'About Crosstherads'),
(964, 102, '_ab_heading', 'field_66f6ee4c27797'),
(965, 102, 'ab_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(966, 102, '_ab_content', 'field_66f6ee5027798'),
(967, 102, 'ab_button_text', 'Learn More'),
(968, 102, '_ab_button_text', 'field_66f6ee3b27795'),
(969, 102, 'ab_button_link', 'a:3:{s:5:"title";s:8:"About Us";s:3:"url";s:44:"http://localhost/crossthreads/site/about-us/";s:6:"target";s:0:"";}'),
(970, 102, '_ab_button_link', 'field_66f6ee4127796'),
(971, 102, 'season_title', 'Seasonal Products'),
(972, 102, '_season_title', 'field_66f6ef5882d5b'),
(973, 102, 'sea_prod', '3'),
(974, 102, '_sea_prod', 'field_66f6ef8b82d5c'),
(975, 102, 'coll_button_text', 'See All Collections'),
(976, 102, '_coll_button_text', 'field_66f6f0a26790d'),
(977, 102, 'coll_button_link', ''),
(978, 102, '_coll_button_link', 'field_66f6f0a66790e'),
(979, 102, 'discount_prod', '2'),
(980, 102, '_discount_prod', 'field_66f6f130f781c'),
(981, 102, 'cust_title', 'Happy Customers'),
(982, 102, '_cust_title', 'field_66f6fca3242e1'),
(983, 102, 'customers_quotes', '3'),
(984, 102, '_customers_quotes', 'field_66f6fcb5242e2'),
(985, 102, 'product_slider', '4'),
(986, 102, '_product_slider', 'field_66f6fd852dbae'),
(987, 102, 'icon_details_0_icon_image', '84'),
(988, 102, '_icon_details_0_icon_image', 'field_66f6ed42ace0f'),
(989, 102, 'icon_details_0_icon_name', 'Sustainable Materials'),
(990, 102, '_icon_details_0_icon_name', 'field_66f6ed42ace0e'),
(991, 102, 'icon_details_1_icon_image', '87'),
(992, 102, '_icon_details_1_icon_image', 'field_66f6ed42ace0f'),
(993, 102, 'icon_details_1_icon_name', 'Garment Care'),
(994, 102, '_icon_details_1_icon_name', 'field_66f6ed42ace0e'),
(995, 102, 'icon_details_2_icon_image', '86'),
(996, 102, '_icon_details_2_icon_image', 'field_66f6ed42ace0f'),
(997, 102, 'icon_details_2_icon_name', 'Recycled/ Upcycled'),
(998, 102, '_icon_details_2_icon_name', 'field_66f6ed42ace0e'),
(999, 102, 'icon_details_3_icon_image', '85'),
(1000, 102, '_icon_details_3_icon_image', 'field_66f6ed42ace0f'),
(1001, 102, 'icon_details_3_icon_name', 'Made in INDIA'),
(1002, 102, '_icon_details_3_icon_name', 'field_66f6ed42ace0e'),
(1003, 102, 'sea_prod_0_prod_name', 'Organic Linen Shirt'),
(1004, 102, '_sea_prod_0_prod_name', 'field_66f6ef8b82d5d'),
(1005, 102, 'sea_prod_0_prod_image', '90') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1006, 102, '_sea_prod_0_prod_image', 'field_66f6ef8b82d5e'),
(1007, 102, 'sea_prod_0_prod_link', ''),
(1008, 102, '_sea_prod_0_prod_link', 'field_66f6ef8b82d5f'),
(1009, 102, 'sea_prod_0_prod_price', '$49.99'),
(1010, 102, '_sea_prod_0_prod_price', 'field_66f6efca82d60'),
(1011, 102, 'sea_prod_0_prod_button_link', ''),
(1012, 102, '_sea_prod_0_prod_button_link', 'field_66f6f07082d61'),
(1013, 102, 'sea_prod_1_prod_name', 'Organic Cotton Button-Up'),
(1014, 102, '_sea_prod_1_prod_name', 'field_66f6ef8b82d5d'),
(1015, 102, 'sea_prod_1_prod_image', '89'),
(1016, 102, '_sea_prod_1_prod_image', 'field_66f6ef8b82d5e'),
(1017, 102, 'sea_prod_1_prod_link', ''),
(1018, 102, '_sea_prod_1_prod_link', 'field_66f6ef8b82d5f'),
(1019, 102, 'sea_prod_1_prod_price', '$49.99'),
(1020, 102, '_sea_prod_1_prod_price', 'field_66f6efca82d60'),
(1021, 102, 'sea_prod_1_prod_button_link', ''),
(1022, 102, '_sea_prod_1_prod_button_link', 'field_66f6f07082d61'),
(1023, 102, 'sea_prod_2_prod_name', 'Sustainable Classic'),
(1024, 102, '_sea_prod_2_prod_name', 'field_66f6ef8b82d5d'),
(1025, 102, 'sea_prod_2_prod_image', '91'),
(1026, 102, '_sea_prod_2_prod_image', 'field_66f6ef8b82d5e'),
(1027, 102, 'sea_prod_2_prod_link', ''),
(1028, 102, '_sea_prod_2_prod_link', 'field_66f6ef8b82d5f'),
(1029, 102, 'sea_prod_2_prod_price', '$49.99'),
(1030, 102, '_sea_prod_2_prod_price', 'field_66f6efca82d60'),
(1031, 102, 'sea_prod_2_prod_button_link', ''),
(1032, 102, '_sea_prod_2_prod_button_link', 'field_66f6f07082d61'),
(1033, 102, 'discount_prod_0_disc_prod_image', '92'),
(1034, 102, '_discount_prod_0_disc_prod_image', 'field_66f6f130f781e'),
(1035, 102, 'discount_prod_0_disc_percentage', '15%'),
(1036, 102, '_discount_prod_0_disc_percentage', 'field_66f6f130f781f'),
(1037, 102, 'discount_prod_0_disc_prod_name', 'Herbal Series Linen Shirt'),
(1038, 102, '_discount_prod_0_disc_prod_name', 'field_66f6f130f781d'),
(1039, 102, 'discount_prod_0_disc_prod_price', '$49.99'),
(1040, 102, '_discount_prod_0_disc_prod_price', 'field_66f6f130f7820'),
(1041, 102, 'discount_prod_0_prod_button_link', ''),
(1042, 102, '_discount_prod_0_prod_button_link', 'field_66f6f130f7821'),
(1043, 102, 'discount_prod_1_disc_prod_image', '93'),
(1044, 102, '_discount_prod_1_disc_prod_image', 'field_66f6f130f781e'),
(1045, 102, 'discount_prod_1_disc_percentage', '30%'),
(1046, 102, '_discount_prod_1_disc_percentage', 'field_66f6f130f781f'),
(1047, 102, 'discount_prod_1_disc_prod_name', 'Herbal Series Linen Shirt'),
(1048, 102, '_discount_prod_1_disc_prod_name', 'field_66f6f130f781d'),
(1049, 102, 'discount_prod_1_disc_prod_price', '$49.99'),
(1050, 102, '_discount_prod_1_disc_prod_price', 'field_66f6f130f7820'),
(1051, 102, 'discount_prod_1_prod_button_link', ''),
(1052, 102, '_discount_prod_1_prod_button_link', 'field_66f6f130f7821'),
(1053, 102, 'customers_quotes_0_cust_image', '94'),
(1054, 102, '_customers_quotes_0_cust_image', 'field_66f6fcb5242e3'),
(1055, 102, 'customers_quotes_0_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(1056, 102, '_customers_quotes_0_cust_content', 'field_66f6fcb5242e4'),
(1057, 102, 'customers_quotes_0_cust_name', 'Deepson'),
(1058, 102, '_customers_quotes_0_cust_name', 'field_66f6fcb5242e5'),
(1059, 102, 'customers_quotes_0_cust_rating', '95'),
(1060, 102, '_customers_quotes_0_cust_rating', 'field_66f6fcb5242e6'),
(1061, 102, 'customers_quotes_1_cust_image', '94'),
(1062, 102, '_customers_quotes_1_cust_image', 'field_66f6fcb5242e3'),
(1063, 102, 'customers_quotes_1_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(1064, 102, '_customers_quotes_1_cust_content', 'field_66f6fcb5242e4'),
(1065, 102, 'customers_quotes_1_cust_name', 'Deepson'),
(1066, 102, '_customers_quotes_1_cust_name', 'field_66f6fcb5242e5'),
(1067, 102, 'customers_quotes_1_cust_rating', '95'),
(1068, 102, '_customers_quotes_1_cust_rating', 'field_66f6fcb5242e6'),
(1069, 102, 'customers_quotes_2_cust_image', '94'),
(1070, 102, '_customers_quotes_2_cust_image', 'field_66f6fcb5242e3'),
(1071, 102, 'customers_quotes_2_cust_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus efficitur libero eget arcu gravida, at tempus nisl scelerisque.'),
(1072, 102, '_customers_quotes_2_cust_content', 'field_66f6fcb5242e4'),
(1073, 102, 'customers_quotes_2_cust_name', 'Deepson'),
(1074, 102, '_customers_quotes_2_cust_name', 'field_66f6fcb5242e5'),
(1075, 102, 'customers_quotes_2_cust_rating', '95'),
(1076, 102, '_customers_quotes_2_cust_rating', 'field_66f6fcb5242e6'),
(1077, 102, 'product_slider_0_slider_prod_image', '97'),
(1078, 102, '_product_slider_0_slider_prod_image', 'field_66f6fd852dbaf'),
(1079, 102, 'product_slider_0_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(1080, 102, '_product_slider_0_slider_prod_name', 'field_66f6fd852dbb1'),
(1081, 102, 'product_slider_0_slider_prod_price', '$49.99'),
(1082, 102, '_product_slider_0_slider_prod_price', 'field_66f6fd852dbb2'),
(1083, 102, 'product_slider_0_slider_detail_link', ''),
(1084, 102, '_product_slider_0_slider_detail_link', 'field_66f6fd852dbb3'),
(1085, 102, 'product_slider_0_slider_buy_link', ''),
(1086, 102, '_product_slider_0_slider_buy_link', 'field_66f6fdf12dbb4'),
(1087, 102, 'product_slider_1_slider_prod_image', '98'),
(1088, 102, '_product_slider_1_slider_prod_image', 'field_66f6fd852dbaf'),
(1089, 102, 'product_slider_1_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(1090, 102, '_product_slider_1_slider_prod_name', 'field_66f6fd852dbb1'),
(1091, 102, 'product_slider_1_slider_prod_price', '$49.99'),
(1092, 102, '_product_slider_1_slider_prod_price', 'field_66f6fd852dbb2'),
(1093, 102, 'product_slider_1_slider_detail_link', ''),
(1094, 102, '_product_slider_1_slider_detail_link', 'field_66f6fd852dbb3'),
(1095, 102, 'product_slider_1_slider_buy_link', ''),
(1096, 102, '_product_slider_1_slider_buy_link', 'field_66f6fdf12dbb4'),
(1097, 102, 'product_slider_2_slider_prod_image', '99'),
(1098, 102, '_product_slider_2_slider_prod_image', 'field_66f6fd852dbaf'),
(1099, 102, 'product_slider_2_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(1100, 102, '_product_slider_2_slider_prod_name', 'field_66f6fd852dbb1'),
(1101, 102, 'product_slider_2_slider_prod_price', '$49.99'),
(1102, 102, '_product_slider_2_slider_prod_price', 'field_66f6fd852dbb2'),
(1103, 102, 'product_slider_2_slider_detail_link', ''),
(1104, 102, '_product_slider_2_slider_detail_link', 'field_66f6fd852dbb3'),
(1105, 102, 'product_slider_2_slider_buy_link', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1106, 102, '_product_slider_2_slider_buy_link', 'field_66f6fdf12dbb4'),
(1107, 102, 'product_slider_3_slider_prod_image', '100'),
(1108, 102, '_product_slider_3_slider_prod_image', 'field_66f6fd852dbaf'),
(1109, 102, 'product_slider_3_slider_prod_name', 'Suspender Skirt With Shirt Set'),
(1110, 102, '_product_slider_3_slider_prod_name', 'field_66f6fd852dbb1'),
(1111, 102, 'product_slider_3_slider_prod_price', '$49.99'),
(1112, 102, '_product_slider_3_slider_prod_price', 'field_66f6fd852dbb2'),
(1113, 102, 'product_slider_3_slider_detail_link', ''),
(1114, 102, '_product_slider_3_slider_detail_link', 'field_66f6fd852dbb3'),
(1115, 102, 'product_slider_3_slider_buy_link', ''),
(1116, 102, '_product_slider_3_slider_buy_link', 'field_66f6fdf12dbb4'),
(1117, 81, '_thumbnail_id', '88'),
(1118, 109, '_edit_lock', '1727624361:1'),
(1119, 109, '_edit_last', '1'),
(1120, 81, 'banner_heading', 'About Crosstherads'),
(1121, 81, '_banner_heading', 'field_66f90eb93642d'),
(1122, 81, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1123, 81, '_banner_content', 'field_66f90eb936816'),
(1124, 81, 'categ_title', ''),
(1125, 81, '_categ_title', 'field_66f90eb936fe6'),
(1126, 81, 'prod_categories', ''),
(1127, 81, '_prod_categories', 'field_66f90eb9373ce'),
(1128, 81, 'categ_button_text', ''),
(1129, 81, '_categ_button_text', 'field_66f90eb9377b7'),
(1130, 81, 'categ_button_link', ''),
(1131, 81, '_categ_button_link', 'field_66f90eb937ba0'),
(1132, 81, 'icon_title', ''),
(1133, 81, '_icon_title', 'field_66f90eb938382'),
(1134, 81, 'icon_details', ''),
(1135, 81, '_icon_details', 'field_66f90eb938778'),
(1136, 81, 'ab_background_image', ''),
(1137, 81, '_ab_background_image', 'field_66f90eb938f2b'),
(1138, 81, 'ab_heading', ''),
(1139, 81, '_ab_heading', 'field_66f90eb93932b'),
(1140, 81, 'ab_content', '<p data-aos="fade-in" data-aos-delay="100">We believe that every thread tells a story. From the sourcing of our eco-friendly materials to the ethical craftsmanship that brings each piece to life, our clothing is designed to respect the environment and honor the people who make it. Our collections are a testament to the beauty of simplicity and the power of conscious choices.</p>\r\n<p data-aos="fade-in" data-aos-delay="200">At Crossthreads, we don’t just create clothes; we create connections. Connections between style and sustainability, between tradition and innovation, and between you and a more sustainable future. Join us in weaving a better world, one thread at a time.</p>'),
(1141, 81, '_ab_content', 'field_66f90eb9377b7'),
(1142, 81, 'ab_button_text', ''),
(1143, 81, '_ab_button_text', 'field_66f90eb939afa'),
(1144, 81, 'ab_button_link', ''),
(1145, 81, '_ab_button_link', 'field_66f90eb939ee0'),
(1146, 81, 'season_title', 'Our mission'),
(1147, 81, '_season_title', 'field_66f90eb93a6be'),
(1148, 81, 'sea_prod', ''),
(1149, 81, '_sea_prod', 'field_66f90eb93aa9c'),
(1150, 81, 'coll_button_text', ''),
(1151, 81, '_coll_button_text', 'field_66f90eb93ae88'),
(1152, 81, 'coll_button_link', ''),
(1153, 81, '_coll_button_link', 'field_66f90eb93b25c'),
(1154, 81, 'discount_prod', ''),
(1155, 81, '_discount_prod', 'field_66f90eb93ba2a'),
(1156, 81, 'cust_title', ''),
(1157, 81, '_cust_title', 'field_66f90eb93c20a'),
(1158, 81, 'customers_quotes', ''),
(1159, 81, '_customers_quotes', 'field_66f90eb93c5e6'),
(1160, 81, 'product_slider', ''),
(1161, 81, '_product_slider', 'field_66f90eb93cdb8'),
(1162, 82, 'banner_heading', 'About Crosstherads'),
(1163, 82, '_banner_heading', 'field_66f90eb93642d'),
(1164, 82, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1165, 82, '_banner_content', 'field_66f90eb936816'),
(1166, 82, 'categ_title', ''),
(1167, 82, '_categ_title', 'field_66f90eb936fe6'),
(1168, 82, 'prod_categories', ''),
(1169, 82, '_prod_categories', 'field_66f90eb9373ce'),
(1170, 82, 'categ_button_text', ''),
(1171, 82, '_categ_button_text', 'field_66f90eb9377b7'),
(1172, 82, 'categ_button_link', ''),
(1173, 82, '_categ_button_link', 'field_66f90eb937ba0'),
(1174, 82, 'icon_title', ''),
(1175, 82, '_icon_title', 'field_66f90eb938382'),
(1176, 82, 'icon_details', ''),
(1177, 82, '_icon_details', 'field_66f90eb938778'),
(1178, 82, 'ab_background_image', ''),
(1179, 82, '_ab_background_image', 'field_66f90eb938f2b'),
(1180, 82, 'ab_heading', ''),
(1181, 82, '_ab_heading', 'field_66f90eb93932b'),
(1182, 82, 'ab_content', ''),
(1183, 82, '_ab_content', 'field_66f90eb93970b'),
(1184, 82, 'ab_button_text', ''),
(1185, 82, '_ab_button_text', 'field_66f90eb939afa'),
(1186, 82, 'ab_button_link', ''),
(1187, 82, '_ab_button_link', 'field_66f90eb939ee0'),
(1188, 82, 'season_title', ''),
(1189, 82, '_season_title', 'field_66f90eb93a6be'),
(1190, 82, 'sea_prod', ''),
(1191, 82, '_sea_prod', 'field_66f90eb93aa9c'),
(1192, 82, 'coll_button_text', ''),
(1193, 82, '_coll_button_text', 'field_66f90eb93ae88'),
(1194, 82, 'coll_button_link', ''),
(1195, 82, '_coll_button_link', 'field_66f90eb93b25c'),
(1196, 82, 'discount_prod', ''),
(1197, 82, '_discount_prod', 'field_66f90eb93ba2a'),
(1198, 82, 'cust_title', ''),
(1199, 82, '_cust_title', 'field_66f90eb93c20a'),
(1200, 82, 'customers_quotes', ''),
(1201, 82, '_customers_quotes', 'field_66f90eb93c5e6'),
(1202, 82, 'product_slider', ''),
(1203, 82, '_product_slider', 'field_66f90eb93cdb8'),
(1204, 81, 'b_button_text', 'Learn More'),
(1205, 81, '_b_button_text', 'field_66f9101fc3f27') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1206, 81, 'b_button_link', '#'),
(1207, 81, '_b_button_link', 'field_66f91024c3f28'),
(1208, 217, 'banner_heading', 'About Crosstherads'),
(1209, 217, '_banner_heading', 'field_66f90eb93642d'),
(1210, 217, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1211, 217, '_banner_content', 'field_66f90eb936816'),
(1212, 217, 'categ_title', ''),
(1213, 217, '_categ_title', 'field_66f90eb936fe6'),
(1214, 217, 'prod_categories', ''),
(1215, 217, '_prod_categories', 'field_66f90eb9373ce'),
(1216, 217, 'categ_button_text', ''),
(1217, 217, '_categ_button_text', 'field_66f90eb9377b7'),
(1218, 217, 'categ_button_link', ''),
(1219, 217, '_categ_button_link', 'field_66f90eb937ba0'),
(1220, 217, 'icon_title', ''),
(1221, 217, '_icon_title', 'field_66f90eb938382'),
(1222, 217, 'icon_details', ''),
(1223, 217, '_icon_details', 'field_66f90eb938778'),
(1224, 217, 'ab_background_image', ''),
(1225, 217, '_ab_background_image', 'field_66f90eb938f2b'),
(1226, 217, 'ab_heading', ''),
(1227, 217, '_ab_heading', 'field_66f90eb93932b'),
(1228, 217, 'ab_content', ''),
(1229, 217, '_ab_content', 'field_66f90eb93970b'),
(1230, 217, 'ab_button_text', ''),
(1231, 217, '_ab_button_text', 'field_66f90eb939afa'),
(1232, 217, 'ab_button_link', ''),
(1233, 217, '_ab_button_link', 'field_66f90eb939ee0'),
(1234, 217, 'season_title', ''),
(1235, 217, '_season_title', 'field_66f90eb93a6be'),
(1236, 217, 'sea_prod', ''),
(1237, 217, '_sea_prod', 'field_66f90eb93aa9c'),
(1238, 217, 'coll_button_text', ''),
(1239, 217, '_coll_button_text', 'field_66f90eb93ae88'),
(1240, 217, 'coll_button_link', ''),
(1241, 217, '_coll_button_link', 'field_66f90eb93b25c'),
(1242, 217, 'discount_prod', ''),
(1243, 217, '_discount_prod', 'field_66f90eb93ba2a'),
(1244, 217, 'cust_title', ''),
(1245, 217, '_cust_title', 'field_66f90eb93c20a'),
(1246, 217, 'customers_quotes', ''),
(1247, 217, '_customers_quotes', 'field_66f90eb93c5e6'),
(1248, 217, 'product_slider', ''),
(1249, 217, '_product_slider', 'field_66f90eb93cdb8'),
(1250, 217, 'b_button_text', 'Learn More'),
(1251, 217, '_b_button_text', 'field_66f9101fc3f27'),
(1252, 217, 'b_button_link', '#'),
(1253, 217, '_b_button_link', 'field_66f91024c3f28'),
(1254, 81, 'ab_title', 'At Crossthreads, sustainability is woven into the very fabric of our identity. Born from a desire to create clothing that cares for both people and the planet, we are committed to crafting garments that leave a lighter footprint on the Earth. Our journey began with a simple idea: to offer fashion that is as responsible as it is stylish.\r\n'),
(1255, 81, '_ab_title', 'field_66f90eb936fe6'),
(1256, 81, 'mission_image', '232'),
(1257, 81, '_mission_image', 'field_66f90eb93aa9c'),
(1258, 81, 'ab_left_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1259, 81, '_ab_left_content', 'field_66f90eb93ae88'),
(1260, 81, 'sust_heading', 'Sustainability'),
(1261, 81, '_sust_heading', 'field_66f90eb93ba2a'),
(1262, 220, 'banner_heading', 'About Crosstherads'),
(1263, 220, '_banner_heading', 'field_66f90eb93642d'),
(1264, 220, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1265, 220, '_banner_content', 'field_66f90eb936816'),
(1266, 220, 'categ_title', ''),
(1267, 220, '_categ_title', 'field_66f90eb936fe6'),
(1268, 220, 'prod_categories', ''),
(1269, 220, '_prod_categories', 'field_66f90eb9373ce'),
(1270, 220, 'categ_button_text', ''),
(1271, 220, '_categ_button_text', 'field_66f90eb9377b7'),
(1272, 220, 'categ_button_link', ''),
(1273, 220, '_categ_button_link', 'field_66f90eb937ba0'),
(1274, 220, 'icon_title', ''),
(1275, 220, '_icon_title', 'field_66f90eb938382'),
(1276, 220, 'icon_details', ''),
(1277, 220, '_icon_details', 'field_66f90eb938778'),
(1278, 220, 'ab_background_image', ''),
(1279, 220, '_ab_background_image', 'field_66f90eb938f2b'),
(1280, 220, 'ab_heading', ''),
(1281, 220, '_ab_heading', 'field_66f90eb93932b'),
(1282, 220, 'ab_content', ''),
(1283, 220, '_ab_content', 'field_66f90eb93970b'),
(1284, 220, 'ab_button_text', ''),
(1285, 220, '_ab_button_text', 'field_66f90eb939afa'),
(1286, 220, 'ab_button_link', ''),
(1287, 220, '_ab_button_link', 'field_66f90eb939ee0'),
(1288, 220, 'season_title', ''),
(1289, 220, '_season_title', 'field_66f90eb93a6be'),
(1290, 220, 'sea_prod', ''),
(1291, 220, '_sea_prod', 'field_66f90eb93aa9c'),
(1292, 220, 'coll_button_text', ''),
(1293, 220, '_coll_button_text', 'field_66f90eb93ae88'),
(1294, 220, 'coll_button_link', ''),
(1295, 220, '_coll_button_link', 'field_66f90eb93b25c'),
(1296, 220, 'discount_prod', ''),
(1297, 220, '_discount_prod', 'field_66f90eb93ba2a'),
(1298, 220, 'cust_title', ''),
(1299, 220, '_cust_title', 'field_66f90eb93c20a'),
(1300, 220, 'customers_quotes', ''),
(1301, 220, '_customers_quotes', 'field_66f90eb93c5e6'),
(1302, 220, 'product_slider', ''),
(1303, 220, '_product_slider', 'field_66f90eb93cdb8'),
(1304, 220, 'b_button_text', 'Learn More'),
(1305, 220, '_b_button_text', 'field_66f9101fc3f27') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1306, 220, 'b_button_link', '#'),
(1307, 220, '_b_button_link', 'field_66f91024c3f28'),
(1308, 220, 'ab_title', 'At Crossthreads, sustainability is woven into the very fabric of our identity. Born from a desire to create clothing that cares for both people and the planet, we are committed to crafting garments that leave a lighter footprint on the Earth. Our journey began with a simple idea: to offer fashion that is as responsible as it is stylish.\r\n'),
(1309, 220, '_ab_title', 'field_66f90eb936fe6'),
(1310, 220, 'mission_image', ''),
(1311, 220, '_mission_image', 'field_66f90eb93aa9c'),
(1312, 220, 'ab_left_content', ''),
(1313, 220, '_ab_left_content', 'field_66f90eb93ae88'),
(1314, 220, 'sust_heading', ''),
(1315, 220, '_sust_heading', 'field_66f90eb93ba2a'),
(1316, 81, 'sust_content', 'We are committed to minimizing our environmental footprint through responsible sourcing, ethical production, and thoughtful design. Every piece of clothing we create is a step toward a greener future.'),
(1317, 81, '_sust_content', 'field_66f96daf0462b'),
(1318, 81, 'sust_image', '88'),
(1319, 81, '_sust_image', 'field_66f96e4104631'),
(1320, 81, 'img_title', 'Quality'),
(1321, 81, '_img_title', 'field_66f96f68e5375'),
(1322, 81, 'ab_right_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1323, 81, '_ab_right_content', 'field_66f96f6de5376'),
(1324, 81, 'ab_image_right', '232'),
(1325, 81, '_ab_image_right', 'field_66f96f64e5374'),
(1326, 81, 'sign_title', 'Ethical Practices'),
(1327, 81, '_sign_title', 'field_66f970b4e5378'),
(1328, 81, 'sign_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(1329, 81, '_sign_content', 'field_66f970cce5379'),
(1330, 81, 'sign_image', '237'),
(1331, 81, '_sign_image', 'field_66f970f3e537a'),
(1332, 220, 'sust_content', ''),
(1333, 220, '_sust_content', 'field_66f96daf0462b'),
(1334, 220, 'sust_image', ''),
(1335, 220, '_sust_image', 'field_66f96e4104631'),
(1336, 220, 'img_title', ''),
(1337, 220, '_img_title', 'field_66f96f68e5375'),
(1338, 220, 'ab_right_content', ''),
(1339, 220, '_ab_right_content', 'field_66f96f6de5376'),
(1340, 220, 'ab_image_right', ''),
(1341, 220, '_ab_image_right', 'field_66f96f64e5374'),
(1342, 220, 'sign_title', ''),
(1343, 220, '_sign_title', 'field_66f970b4e5378'),
(1344, 220, 'sign_content', ''),
(1345, 220, '_sign_content', 'field_66f970cce5379'),
(1346, 220, 'sign_image', ''),
(1347, 220, '_sign_image', 'field_66f970f3e537a'),
(1348, 231, 'banner_heading', 'About Crosstherads'),
(1349, 231, '_banner_heading', 'field_66f90eb93642d'),
(1350, 231, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1351, 231, '_banner_content', 'field_66f90eb936816'),
(1352, 231, 'categ_title', ''),
(1353, 231, '_categ_title', 'field_66f90eb936fe6'),
(1354, 231, 'prod_categories', ''),
(1355, 231, '_prod_categories', 'field_66f90eb9373ce'),
(1356, 231, 'categ_button_text', ''),
(1357, 231, '_categ_button_text', 'field_66f90eb9377b7'),
(1358, 231, 'categ_button_link', ''),
(1359, 231, '_categ_button_link', 'field_66f90eb937ba0'),
(1360, 231, 'icon_title', ''),
(1361, 231, '_icon_title', 'field_66f90eb938382'),
(1362, 231, 'icon_details', ''),
(1363, 231, '_icon_details', 'field_66f90eb938778'),
(1364, 231, 'ab_background_image', ''),
(1365, 231, '_ab_background_image', 'field_66f90eb938f2b'),
(1366, 231, 'ab_heading', ''),
(1367, 231, '_ab_heading', 'field_66f90eb93932b'),
(1368, 231, 'ab_content', ''),
(1369, 231, '_ab_content', 'field_66f90eb9377b7'),
(1370, 231, 'ab_button_text', ''),
(1371, 231, '_ab_button_text', 'field_66f90eb939afa'),
(1372, 231, 'ab_button_link', ''),
(1373, 231, '_ab_button_link', 'field_66f90eb939ee0'),
(1374, 231, 'season_title', 'Our mission'),
(1375, 231, '_season_title', 'field_66f90eb93a6be'),
(1376, 231, 'sea_prod', ''),
(1377, 231, '_sea_prod', 'field_66f90eb93aa9c'),
(1378, 231, 'coll_button_text', ''),
(1379, 231, '_coll_button_text', 'field_66f90eb93ae88'),
(1380, 231, 'coll_button_link', ''),
(1381, 231, '_coll_button_link', 'field_66f90eb93b25c'),
(1382, 231, 'discount_prod', ''),
(1383, 231, '_discount_prod', 'field_66f90eb93ba2a'),
(1384, 231, 'cust_title', ''),
(1385, 231, '_cust_title', 'field_66f90eb93c20a'),
(1386, 231, 'customers_quotes', ''),
(1387, 231, '_customers_quotes', 'field_66f90eb93c5e6'),
(1388, 231, 'product_slider', ''),
(1389, 231, '_product_slider', 'field_66f90eb93cdb8'),
(1390, 231, 'b_button_text', 'Learn More'),
(1391, 231, '_b_button_text', 'field_66f9101fc3f27'),
(1392, 231, 'b_button_link', '#'),
(1393, 231, '_b_button_link', 'field_66f91024c3f28'),
(1394, 231, 'ab_title', 'At Crossthreads, sustainability is woven into the very fabric of our identity. Born from a desire to create clothing that cares for both people and the planet, we are committed to crafting garments that leave a lighter footprint on the Earth. Our journey began with a simple idea: to offer fashion that is as responsible as it is stylish.\r\n'),
(1395, 231, '_ab_title', 'field_66f90eb936fe6'),
(1396, 231, 'mission_image', '232'),
(1397, 231, '_mission_image', 'field_66f90eb93aa9c'),
(1398, 231, 'ab_left_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1399, 231, '_ab_left_content', 'field_66f90eb93ae88'),
(1400, 231, 'sust_heading', 'a:1:{s:13:"66f972b6b0e17";a:5:{s:19:"field_66f90ec081c55";s:0:"";s:19:"field_66f90ec082035";s:0:"";s:19:"field_66f90ec082426";s:0:"";s:19:"field_66f90ec082876";s:0:"";s:19:"field_66f90ec082c5f";s:0:"";}}'),
(1401, 231, '_sust_heading', 'field_66f90eb93ba2a'),
(1402, 231, 'sust_content', ''),
(1403, 231, '_sust_content', 'field_66f96daf0462b'),
(1404, 231, 'sust_image', ''),
(1405, 231, '_sust_image', 'field_66f96e4104631') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1406, 231, 'img_title', ''),
(1407, 231, '_img_title', 'field_66f96f68e5375'),
(1408, 231, 'ab_right_content', ''),
(1409, 231, '_ab_right_content', 'field_66f96f6de5376'),
(1410, 231, 'ab_image_right', '233'),
(1411, 231, '_ab_image_right', 'field_66f96f64e5374'),
(1412, 231, 'sign_title', ''),
(1413, 231, '_sign_title', 'field_66f970b4e5378'),
(1414, 231, 'sign_content', ''),
(1415, 231, '_sign_content', 'field_66f970cce5379'),
(1416, 231, 'sign_image', ''),
(1417, 231, '_sign_image', 'field_66f970f3e537a'),
(1418, 232, '_wp_attached_file', '2024/09/left-img.jpg'),
(1419, 232, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:907;s:4:"file";s:20:"2024/09/left-img.jpg";s:8:"filesize";i:1219749;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:20:"left-img-300x283.jpg";s:5:"width";i:300;s:6:"height";i:283;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:30434;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"left-img-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9039;}s:12:"medium_large";a:5:{s:4:"file";s:20:"left-img-768x726.jpg";s:5:"width";i:768;s:6:"height";i:726;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:164422;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1420, 233, '_wp_attached_file', '2024/09/quality.png'),
(1421, 233, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:452;s:6:"height";i:426;s:4:"file";s:19:"2024/09/quality.png";s:8:"filesize";i:169481;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:19:"quality-300x283.png";s:5:"width";i:300;s:6:"height";i:283;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:82262;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"quality-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28924;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1424, 234, 'banner_heading', 'About Crosstherads'),
(1425, 234, '_banner_heading', 'field_66f90eb93642d'),
(1426, 234, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1427, 234, '_banner_content', 'field_66f90eb936816'),
(1428, 234, 'categ_title', ''),
(1429, 234, '_categ_title', 'field_66f90eb936fe6'),
(1430, 234, 'prod_categories', ''),
(1431, 234, '_prod_categories', 'field_66f90eb9373ce'),
(1432, 234, 'categ_button_text', ''),
(1433, 234, '_categ_button_text', 'field_66f90eb9377b7'),
(1434, 234, 'categ_button_link', ''),
(1435, 234, '_categ_button_link', 'field_66f90eb937ba0'),
(1436, 234, 'icon_title', ''),
(1437, 234, '_icon_title', 'field_66f90eb938382'),
(1438, 234, 'icon_details', ''),
(1439, 234, '_icon_details', 'field_66f90eb938778'),
(1440, 234, 'ab_background_image', ''),
(1441, 234, '_ab_background_image', 'field_66f90eb938f2b'),
(1442, 234, 'ab_heading', ''),
(1443, 234, '_ab_heading', 'field_66f90eb93932b'),
(1444, 234, 'ab_content', ''),
(1445, 234, '_ab_content', 'field_66f90eb9377b7'),
(1446, 234, 'ab_button_text', ''),
(1447, 234, '_ab_button_text', 'field_66f90eb939afa'),
(1448, 234, 'ab_button_link', ''),
(1449, 234, '_ab_button_link', 'field_66f90eb939ee0'),
(1450, 234, 'season_title', 'Our mission'),
(1451, 234, '_season_title', 'field_66f90eb93a6be'),
(1452, 234, 'sea_prod', ''),
(1453, 234, '_sea_prod', 'field_66f90eb93aa9c'),
(1454, 234, 'coll_button_text', ''),
(1455, 234, '_coll_button_text', 'field_66f90eb93ae88'),
(1456, 234, 'coll_button_link', ''),
(1457, 234, '_coll_button_link', 'field_66f90eb93b25c'),
(1458, 234, 'discount_prod', ''),
(1459, 234, '_discount_prod', 'field_66f90eb93ba2a'),
(1460, 234, 'cust_title', ''),
(1461, 234, '_cust_title', 'field_66f90eb93c20a'),
(1462, 234, 'customers_quotes', ''),
(1463, 234, '_customers_quotes', 'field_66f90eb93c5e6'),
(1464, 234, 'product_slider', ''),
(1465, 234, '_product_slider', 'field_66f90eb93cdb8'),
(1466, 234, 'b_button_text', 'Learn More'),
(1467, 234, '_b_button_text', 'field_66f9101fc3f27'),
(1468, 234, 'b_button_link', '#'),
(1469, 234, '_b_button_link', 'field_66f91024c3f28'),
(1470, 234, 'ab_title', 'At Crossthreads, sustainability is woven into the very fabric of our identity. Born from a desire to create clothing that cares for both people and the planet, we are committed to crafting garments that leave a lighter footprint on the Earth. Our journey began with a simple idea: to offer fashion that is as responsible as it is stylish.\r\n'),
(1471, 234, '_ab_title', 'field_66f90eb936fe6'),
(1472, 234, 'mission_image', '232'),
(1473, 234, '_mission_image', 'field_66f90eb93aa9c'),
(1474, 234, 'ab_left_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1475, 234, '_ab_left_content', 'field_66f90eb93ae88'),
(1476, 234, 'sust_heading', 'Sustainability'),
(1477, 234, '_sust_heading', 'field_66f90eb93ba2a'),
(1478, 234, 'sust_content', 'We are committed to minimizing our environmental footprint through responsible sourcing, ethical production, and thoughtful design. Every piece of clothing we create is a step toward a greener future.'),
(1479, 234, '_sust_content', 'field_66f96daf0462b'),
(1480, 234, 'sust_image', '88'),
(1481, 234, '_sust_image', 'field_66f96e4104631'),
(1482, 234, 'img_title', 'Quality'),
(1483, 234, '_img_title', 'field_66f96f68e5375'),
(1484, 234, 'ab_right_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1485, 234, '_ab_right_content', 'field_66f96f6de5376'),
(1486, 234, 'ab_image_right', '233'),
(1487, 234, '_ab_image_right', 'field_66f96f64e5374'),
(1488, 234, 'sign_title', 'Ethical Practices'),
(1489, 234, '_sign_title', 'field_66f970b4e5378'),
(1490, 234, 'sign_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(1491, 234, '_sign_content', 'field_66f970cce5379'),
(1492, 234, 'sign_image', ''),
(1493, 234, '_sign_image', 'field_66f970f3e537a'),
(1494, 237, '_wp_attached_file', '2024/09/signature.png'),
(1495, 237, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:336;s:6:"height";i:94;s:4:"file";s:21:"2024/09/signature.png";s:8:"filesize";i:14660;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:20:"signature-300x84.png";s:5:"width";i:300;s:6:"height";i:84;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12857;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"signature-150x94.png";s:5:"width";i:150;s:6:"height";i:94;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8045;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1496, 236, 'banner_heading', 'About Crosstherads'),
(1497, 236, '_banner_heading', 'field_66f90eb93642d'),
(1498, 236, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1499, 236, '_banner_content', 'field_66f90eb936816'),
(1500, 236, 'categ_title', ''),
(1501, 236, '_categ_title', 'field_66f90eb936fe6'),
(1502, 236, 'prod_categories', ''),
(1503, 236, '_prod_categories', 'field_66f90eb9373ce'),
(1504, 236, 'categ_button_text', ''),
(1505, 236, '_categ_button_text', 'field_66f90eb9377b7'),
(1506, 236, 'categ_button_link', ''),
(1507, 236, '_categ_button_link', 'field_66f90eb937ba0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1508, 236, 'icon_title', ''),
(1509, 236, '_icon_title', 'field_66f90eb938382'),
(1510, 236, 'icon_details', ''),
(1511, 236, '_icon_details', 'field_66f90eb938778'),
(1512, 236, 'ab_background_image', ''),
(1513, 236, '_ab_background_image', 'field_66f90eb938f2b'),
(1514, 236, 'ab_heading', ''),
(1515, 236, '_ab_heading', 'field_66f90eb93932b'),
(1516, 236, 'ab_content', ''),
(1517, 236, '_ab_content', 'field_66f90eb9377b7'),
(1518, 236, 'ab_button_text', ''),
(1519, 236, '_ab_button_text', 'field_66f90eb939afa'),
(1520, 236, 'ab_button_link', ''),
(1521, 236, '_ab_button_link', 'field_66f90eb939ee0'),
(1522, 236, 'season_title', 'Our mission'),
(1523, 236, '_season_title', 'field_66f90eb93a6be'),
(1524, 236, 'sea_prod', ''),
(1525, 236, '_sea_prod', 'field_66f90eb93aa9c'),
(1526, 236, 'coll_button_text', ''),
(1527, 236, '_coll_button_text', 'field_66f90eb93ae88'),
(1528, 236, 'coll_button_link', ''),
(1529, 236, '_coll_button_link', 'field_66f90eb93b25c'),
(1530, 236, 'discount_prod', ''),
(1531, 236, '_discount_prod', 'field_66f90eb93ba2a'),
(1532, 236, 'cust_title', ''),
(1533, 236, '_cust_title', 'field_66f90eb93c20a'),
(1534, 236, 'customers_quotes', ''),
(1535, 236, '_customers_quotes', 'field_66f90eb93c5e6'),
(1536, 236, 'product_slider', ''),
(1537, 236, '_product_slider', 'field_66f90eb93cdb8'),
(1538, 236, 'b_button_text', 'Learn More'),
(1539, 236, '_b_button_text', 'field_66f9101fc3f27'),
(1540, 236, 'b_button_link', '#'),
(1541, 236, '_b_button_link', 'field_66f91024c3f28'),
(1542, 236, 'ab_title', 'At Crossthreads, sustainability is woven into the very fabric of our identity. Born from a desire to create clothing that cares for both people and the planet, we are committed to crafting garments that leave a lighter footprint on the Earth. Our journey began with a simple idea: to offer fashion that is as responsible as it is stylish.\r\n'),
(1543, 236, '_ab_title', 'field_66f90eb936fe6'),
(1544, 236, 'mission_image', '232'),
(1545, 236, '_mission_image', 'field_66f90eb93aa9c'),
(1546, 236, 'ab_left_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1547, 236, '_ab_left_content', 'field_66f90eb93ae88'),
(1548, 236, 'sust_heading', 'Sustainability'),
(1549, 236, '_sust_heading', 'field_66f90eb93ba2a'),
(1550, 236, 'sust_content', 'We are committed to minimizing our environmental footprint through responsible sourcing, ethical production, and thoughtful design. Every piece of clothing we create is a step toward a greener future.'),
(1551, 236, '_sust_content', 'field_66f96daf0462b'),
(1552, 236, 'sust_image', '88'),
(1553, 236, '_sust_image', 'field_66f96e4104631'),
(1554, 236, 'img_title', 'Quality'),
(1555, 236, '_img_title', 'field_66f96f68e5375'),
(1556, 236, 'ab_right_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1557, 236, '_ab_right_content', 'field_66f96f6de5376'),
(1558, 236, 'ab_image_right', '233'),
(1559, 236, '_ab_image_right', 'field_66f96f64e5374'),
(1560, 236, 'sign_title', 'Ethical Practices'),
(1561, 236, '_sign_title', 'field_66f970b4e5378'),
(1562, 236, 'sign_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(1563, 236, '_sign_content', 'field_66f970cce5379'),
(1564, 236, 'sign_image', '237'),
(1565, 236, '_sign_image', 'field_66f970f3e537a'),
(1566, 238, 'banner_heading', 'About Crosstherads'),
(1567, 238, '_banner_heading', 'field_66f90eb93642d'),
(1568, 238, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1569, 238, '_banner_content', 'field_66f90eb936816'),
(1570, 238, 'categ_title', ''),
(1571, 238, '_categ_title', 'field_66f90eb936fe6'),
(1572, 238, 'prod_categories', ''),
(1573, 238, '_prod_categories', 'field_66f90eb9373ce'),
(1574, 238, 'categ_button_text', ''),
(1575, 238, '_categ_button_text', 'field_66f90eb9377b7'),
(1576, 238, 'categ_button_link', ''),
(1577, 238, '_categ_button_link', 'field_66f90eb937ba0'),
(1578, 238, 'icon_title', ''),
(1579, 238, '_icon_title', 'field_66f90eb938382'),
(1580, 238, 'icon_details', ''),
(1581, 238, '_icon_details', 'field_66f90eb938778'),
(1582, 238, 'ab_background_image', ''),
(1583, 238, '_ab_background_image', 'field_66f90eb938f2b'),
(1584, 238, 'ab_heading', ''),
(1585, 238, '_ab_heading', 'field_66f90eb93932b'),
(1586, 238, 'ab_content', '<p data-aos="fade-in" data-aos-delay="100">We believe that every thread tells a story. From the sourcing of our eco-friendly materials to the ethical craftsmanship that brings each piece to life, our clothing is designed to respect the environment and honor the people who make it. Our collections are a testament to the beauty of simplicity and the power of conscious choices.</p>\r\n<p data-aos="fade-in" data-aos-delay="200">At Crossthreads, we don’t just create clothes; we create connections. Connections between style and sustainability, between tradition and innovation, and between you and a more sustainable future. Join us in weaving a better world, one thread at a time.</p>'),
(1587, 238, '_ab_content', 'field_66f90eb9377b7'),
(1588, 238, 'ab_button_text', ''),
(1589, 238, '_ab_button_text', 'field_66f90eb939afa'),
(1590, 238, 'ab_button_link', ''),
(1591, 238, '_ab_button_link', 'field_66f90eb939ee0'),
(1592, 238, 'season_title', 'Our mission'),
(1593, 238, '_season_title', 'field_66f90eb93a6be'),
(1594, 238, 'sea_prod', ''),
(1595, 238, '_sea_prod', 'field_66f90eb93aa9c'),
(1596, 238, 'coll_button_text', ''),
(1597, 238, '_coll_button_text', 'field_66f90eb93ae88'),
(1598, 238, 'coll_button_link', ''),
(1599, 238, '_coll_button_link', 'field_66f90eb93b25c'),
(1600, 238, 'discount_prod', ''),
(1601, 238, '_discount_prod', 'field_66f90eb93ba2a'),
(1602, 238, 'cust_title', ''),
(1603, 238, '_cust_title', 'field_66f90eb93c20a'),
(1604, 238, 'customers_quotes', ''),
(1605, 238, '_customers_quotes', 'field_66f90eb93c5e6'),
(1606, 238, 'product_slider', ''),
(1607, 238, '_product_slider', 'field_66f90eb93cdb8') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1608, 238, 'b_button_text', 'Learn More'),
(1609, 238, '_b_button_text', 'field_66f9101fc3f27'),
(1610, 238, 'b_button_link', '#'),
(1611, 238, '_b_button_link', 'field_66f91024c3f28'),
(1612, 238, 'ab_title', 'At Crossthreads, sustainability is woven into the very fabric of our identity. Born from a desire to create clothing that cares for both people and the planet, we are committed to crafting garments that leave a lighter footprint on the Earth. Our journey began with a simple idea: to offer fashion that is as responsible as it is stylish.\r\n'),
(1613, 238, '_ab_title', 'field_66f90eb936fe6'),
(1614, 238, 'mission_image', '232'),
(1615, 238, '_mission_image', 'field_66f90eb93aa9c'),
(1616, 238, 'ab_left_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1617, 238, '_ab_left_content', 'field_66f90eb93ae88'),
(1618, 238, 'sust_heading', 'Sustainability'),
(1619, 238, '_sust_heading', 'field_66f90eb93ba2a'),
(1620, 238, 'sust_content', 'We are committed to minimizing our environmental footprint through responsible sourcing, ethical production, and thoughtful design. Every piece of clothing we create is a step toward a greener future.'),
(1621, 238, '_sust_content', 'field_66f96daf0462b'),
(1622, 238, 'sust_image', '88'),
(1623, 238, '_sust_image', 'field_66f96e4104631'),
(1624, 238, 'img_title', 'Quality'),
(1625, 238, '_img_title', 'field_66f96f68e5375'),
(1626, 238, 'ab_right_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1627, 238, '_ab_right_content', 'field_66f96f6de5376'),
(1628, 238, 'ab_image_right', '233'),
(1629, 238, '_ab_image_right', 'field_66f96f64e5374'),
(1630, 238, 'sign_title', 'Ethical Practices'),
(1631, 238, '_sign_title', 'field_66f970b4e5378'),
(1632, 238, 'sign_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(1633, 238, '_sign_content', 'field_66f970cce5379'),
(1634, 238, 'sign_image', '237'),
(1635, 238, '_sign_image', 'field_66f970f3e537a'),
(1636, 1, '_wp_trash_meta_status', 'publish'),
(1637, 1, '_wp_trash_meta_time', '1727687702'),
(1638, 1, '_wp_desired_post_slug', 'hello-world'),
(1639, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(1640, 239, 'banner_heading', 'About Crosstherads'),
(1641, 239, '_banner_heading', 'field_66f90eb93642d'),
(1642, 239, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1643, 239, '_banner_content', 'field_66f90eb936816'),
(1644, 239, 'categ_title', ''),
(1645, 239, '_categ_title', 'field_66f90eb936fe6'),
(1646, 239, 'prod_categories', ''),
(1647, 239, '_prod_categories', 'field_66f90eb9373ce'),
(1648, 239, 'categ_button_text', ''),
(1649, 239, '_categ_button_text', 'field_66f90eb9377b7'),
(1650, 239, 'categ_button_link', ''),
(1651, 239, '_categ_button_link', 'field_66f90eb937ba0'),
(1652, 239, 'icon_title', ''),
(1653, 239, '_icon_title', 'field_66f90eb938382'),
(1654, 239, 'icon_details', ''),
(1655, 239, '_icon_details', 'field_66f90eb938778'),
(1656, 239, 'ab_background_image', ''),
(1657, 239, '_ab_background_image', 'field_66f90eb938f2b'),
(1658, 239, 'ab_heading', ''),
(1659, 239, '_ab_heading', 'field_66f90eb93932b'),
(1660, 239, 'ab_content', '<p data-aos="fade-in" data-aos-delay="100">We believe that every thread tells a story. From the sourcing of our eco-friendly materials to the ethical craftsmanship that brings each piece to life, our clothing is designed to respect the environment and honor the people who make it. Our collections are a testament to the beauty of simplicity and the power of conscious choices.</p>\r\n<p data-aos="fade-in" data-aos-delay="200">At Crossthreads, we don’t just create clothes; we create connections. Connections between style and sustainability, between tradition and innovation, and between you and a more sustainable future. Join us in weaving a better world, one thread at a time.</p>'),
(1661, 239, '_ab_content', 'field_66f90eb9377b7'),
(1662, 239, 'ab_button_text', ''),
(1663, 239, '_ab_button_text', 'field_66f90eb939afa'),
(1664, 239, 'ab_button_link', ''),
(1665, 239, '_ab_button_link', 'field_66f90eb939ee0'),
(1666, 239, 'season_title', 'Our mission'),
(1667, 239, '_season_title', 'field_66f90eb93a6be'),
(1668, 239, 'sea_prod', ''),
(1669, 239, '_sea_prod', 'field_66f90eb93aa9c'),
(1670, 239, 'coll_button_text', ''),
(1671, 239, '_coll_button_text', 'field_66f90eb93ae88'),
(1672, 239, 'coll_button_link', ''),
(1673, 239, '_coll_button_link', 'field_66f90eb93b25c'),
(1674, 239, 'discount_prod', ''),
(1675, 239, '_discount_prod', 'field_66f90eb93ba2a'),
(1676, 239, 'cust_title', ''),
(1677, 239, '_cust_title', 'field_66f90eb93c20a'),
(1678, 239, 'customers_quotes', ''),
(1679, 239, '_customers_quotes', 'field_66f90eb93c5e6'),
(1680, 239, 'product_slider', ''),
(1681, 239, '_product_slider', 'field_66f90eb93cdb8'),
(1682, 239, 'b_button_text', 'Learn More'),
(1683, 239, '_b_button_text', 'field_66f9101fc3f27'),
(1684, 239, 'b_button_link', '#'),
(1685, 239, '_b_button_link', 'field_66f91024c3f28'),
(1686, 239, 'ab_title', 'At Crossthreads, sustainability is woven into the very fabric of our identity. Born from a desire to create clothing that cares for both people and the planet, we are committed to crafting garments that leave a lighter footprint on the Earth. Our journey began with a simple idea: to offer fashion that is as responsible as it is stylish.\r\n'),
(1687, 239, '_ab_title', 'field_66f90eb936fe6'),
(1688, 239, 'mission_image', '232'),
(1689, 239, '_mission_image', 'field_66f90eb93aa9c'),
(1690, 239, 'ab_left_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1691, 239, '_ab_left_content', 'field_66f90eb93ae88'),
(1692, 239, 'sust_heading', 'Sustainability'),
(1693, 239, '_sust_heading', 'field_66f90eb93ba2a'),
(1694, 239, 'sust_content', 'We are committed to minimizing our environmental footprint through responsible sourcing, ethical production, and thoughtful design. Every piece of clothing we create is a step toward a greener future.'),
(1695, 239, '_sust_content', 'field_66f96daf0462b'),
(1696, 239, 'sust_image', '88'),
(1697, 239, '_sust_image', 'field_66f96e4104631'),
(1698, 239, 'img_title', 'Quality'),
(1699, 239, '_img_title', 'field_66f96f68e5375'),
(1700, 239, 'ab_right_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1701, 239, '_ab_right_content', 'field_66f96f6de5376'),
(1702, 239, 'ab_image_right', '232'),
(1703, 239, '_ab_image_right', 'field_66f96f64e5374'),
(1704, 239, 'sign_title', 'Ethical Practices'),
(1705, 239, '_sign_title', 'field_66f970b4e5378'),
(1706, 239, 'sign_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(1707, 239, '_sign_content', 'field_66f970cce5379') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1708, 239, 'sign_image', '237'),
(1709, 239, '_sign_image', 'field_66f970f3e537a'),
(1710, 242, '_edit_last', '1'),
(1711, 242, '_edit_lock', '1727694451:1'),
(1712, 243, '_wp_attached_file', '2024/09/fashion-banner.jpg'),
(1713, 243, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:760;s:4:"file";s:26:"2024/09/fashion-banner.jpg";s:8:"filesize";i:1754723;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:26:"fashion-banner-300x119.jpg";s:5:"width";i:300;s:6:"height";i:119;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9806;}s:5:"large";a:5:{s:4:"file";s:27:"fashion-banner-1024x405.jpg";s:5:"width";i:1024;s:6:"height";i:405;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:99574;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"fashion-banner-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6802;}s:12:"medium_large";a:5:{s:4:"file";s:26:"fashion-banner-768x304.jpg";s:5:"width";i:768;s:6:"height";i:304;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:58251;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"fashion-banner-1536x608.jpg";s:5:"width";i:1536;s:6:"height";i:608;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:206009;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1714, 242, '_thumbnail_id', '243'),
(1715, 242, '_wp_page_template', 'template-sustainability.php'),
(1716, 242, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(1717, 163, '_edit_lock', '1727694447:1'),
(1718, 163, '_edit_last', '1'),
(1719, 242, 'banner_heading', 'Fashioning A Better Future'),
(1720, 242, '_banner_heading', 'field_66f90ed23b08f'),
(1721, 242, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1722, 242, '_banner_content', 'field_66f90ed23b477'),
(1723, 242, 'categ_title', ''),
(1724, 242, '_categ_title', 'field_66f90ed23bc44'),
(1725, 242, 'prod_categories', ''),
(1726, 242, '_prod_categories', 'field_66f90ed23c054'),
(1727, 242, 'categ_button_text', ''),
(1728, 242, '_categ_button_text', 'field_66f90ed23c417'),
(1729, 242, 'categ_button_link', ''),
(1730, 242, '_categ_button_link', 'field_66f90ed23c7fe'),
(1731, 242, 'icon_title', ''),
(1732, 242, '_icon_title', 'field_66f90ed23cfd1'),
(1733, 242, 'icon_details', ''),
(1734, 242, '_icon_details', 'field_66f90ed23d3b1'),
(1735, 242, 'ab_background_image', ''),
(1736, 242, '_ab_background_image', 'field_66f90ed23db88'),
(1737, 242, 'ab_heading', ''),
(1738, 242, '_ab_heading', 'field_66f90ed23df6c'),
(1739, 242, 'ab_content', ''),
(1740, 242, '_ab_content', 'field_66f90ed23e3ad'),
(1741, 242, 'ab_button_text', ''),
(1742, 242, '_ab_button_text', 'field_66f90ed23e73d'),
(1743, 242, 'ab_button_link', ''),
(1744, 242, '_ab_button_link', 'field_66f90ed23eb26'),
(1745, 242, 'season_title', ''),
(1746, 242, '_season_title', 'field_66f90ed23f2fe'),
(1747, 242, 'sea_prod', ''),
(1748, 242, '_sea_prod', 'field_66f90ed23f720'),
(1749, 242, 'coll_button_text', ''),
(1750, 242, '_coll_button_text', 'field_66f90ed23fad4'),
(1751, 242, 'coll_button_link', ''),
(1752, 242, '_coll_button_link', 'field_66f90ed23feb1'),
(1753, 242, 'discount_prod', ''),
(1754, 242, '_discount_prod', 'field_66f90ed2406d8'),
(1755, 242, 'cust_title', ''),
(1756, 242, '_cust_title', 'field_66f90ed240e9c'),
(1757, 242, 'customers_quotes', ''),
(1758, 242, '_customers_quotes', 'field_66f90ed241248'),
(1759, 242, 'product_slider', ''),
(1760, 242, '_product_slider', 'field_66f90ed241a2d'),
(1761, 244, 'banner_heading', 'Fashioning A Better Future'),
(1762, 244, '_banner_heading', 'field_66f90ed23b08f'),
(1763, 244, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1764, 244, '_banner_content', 'field_66f90ed23b477'),
(1765, 244, 'categ_title', ''),
(1766, 244, '_categ_title', 'field_66f90ed23bc44'),
(1767, 244, 'prod_categories', ''),
(1768, 244, '_prod_categories', 'field_66f90ed23c054'),
(1769, 244, 'categ_button_text', ''),
(1770, 244, '_categ_button_text', 'field_66f90ed23c417'),
(1771, 244, 'categ_button_link', ''),
(1772, 244, '_categ_button_link', 'field_66f90ed23c7fe'),
(1773, 244, 'icon_title', ''),
(1774, 244, '_icon_title', 'field_66f90ed23cfd1'),
(1775, 244, 'icon_details', ''),
(1776, 244, '_icon_details', 'field_66f90ed23d3b1'),
(1777, 244, 'ab_background_image', ''),
(1778, 244, '_ab_background_image', 'field_66f90ed23db88'),
(1779, 244, 'ab_heading', ''),
(1780, 244, '_ab_heading', 'field_66f90ed23df6c'),
(1781, 244, 'ab_content', ''),
(1782, 244, '_ab_content', 'field_66f90ed23e3ad'),
(1783, 244, 'ab_button_text', ''),
(1784, 244, '_ab_button_text', 'field_66f90ed23e73d'),
(1785, 244, 'ab_button_link', ''),
(1786, 244, '_ab_button_link', 'field_66f90ed23eb26'),
(1787, 244, 'season_title', ''),
(1788, 244, '_season_title', 'field_66f90ed23f2fe'),
(1789, 244, 'sea_prod', ''),
(1790, 244, '_sea_prod', 'field_66f90ed23f720'),
(1791, 244, 'coll_button_text', ''),
(1792, 244, '_coll_button_text', 'field_66f90ed23fad4'),
(1793, 244, 'coll_button_link', ''),
(1794, 244, '_coll_button_link', 'field_66f90ed23feb1'),
(1795, 244, 'discount_prod', ''),
(1796, 244, '_discount_prod', 'field_66f90ed2406d8'),
(1797, 244, 'cust_title', ''),
(1798, 244, '_cust_title', 'field_66f90ed240e9c'),
(1799, 244, 'customers_quotes', ''),
(1800, 244, '_customers_quotes', 'field_66f90ed241248'),
(1801, 244, 'product_slider', ''),
(1802, 244, '_product_slider', 'field_66f90ed241a2d'),
(1803, 242, 'sust_title', 'Sustainability Pillar'),
(1804, 242, '_sust_title', 'field_66f90ed23bc44'),
(1805, 242, 'sust_imagecontent', '2'),
(1806, 242, '_sust_imagecontent', 'field_66f90ed23c054'),
(1807, 242, 'video_title', 'Making a Difference') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1808, 242, '_video_title', 'field_66f90ed23cfd1'),
(1809, 242, 'video_image', '255'),
(1810, 242, '_video_image', 'field_66f90ed23d3b1'),
(1811, 242, 'bt_background_image', '256'),
(1812, 242, '_bt_background_image', 'field_66f90ed23db88'),
(1813, 242, 'bt_heading', 'OUR PURPOSE'),
(1814, 242, '_bt_heading', 'field_66f90ed23df6c'),
(1815, 242, 'bt_content', 'Empower people to live their best lives with the least impact on the planet.'),
(1816, 242, '_bt_content', 'field_66f90ed23e3ad'),
(1817, 242, 'bt_button_text', 'PRODUCTS'),
(1818, 242, '_bt_button_text', 'field_66f90ed23e73d'),
(1819, 242, 'bt_button_link', ''),
(1820, 242, '_bt_button_link', 'field_66f90ed23eb26'),
(1821, 245, 'banner_heading', 'Fashioning A Better Future'),
(1822, 245, '_banner_heading', 'field_66f90ed23b08f'),
(1823, 245, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1824, 245, '_banner_content', 'field_66f90ed23b477'),
(1825, 245, 'categ_title', ''),
(1826, 245, '_categ_title', 'field_66f90ed23bc44'),
(1827, 245, 'prod_categories', ''),
(1828, 245, '_prod_categories', 'field_66f90ed23c054'),
(1829, 245, 'categ_button_text', ''),
(1830, 245, '_categ_button_text', 'field_66f90ed23c417'),
(1831, 245, 'categ_button_link', ''),
(1832, 245, '_categ_button_link', 'field_66f90ed23c7fe'),
(1833, 245, 'icon_title', ''),
(1834, 245, '_icon_title', 'field_66f90ed23cfd1'),
(1835, 245, 'icon_details', ''),
(1836, 245, '_icon_details', 'field_66f90ed23d3b1'),
(1837, 245, 'ab_background_image', ''),
(1838, 245, '_ab_background_image', 'field_66f90ed23db88'),
(1839, 245, 'ab_heading', ''),
(1840, 245, '_ab_heading', 'field_66f90ed23df6c'),
(1841, 245, 'ab_content', ''),
(1842, 245, '_ab_content', 'field_66f90ed23e3ad'),
(1843, 245, 'ab_button_text', ''),
(1844, 245, '_ab_button_text', 'field_66f90ed23e73d'),
(1845, 245, 'ab_button_link', ''),
(1846, 245, '_ab_button_link', 'field_66f90ed23eb26'),
(1847, 245, 'season_title', ''),
(1848, 245, '_season_title', 'field_66f90ed23f2fe'),
(1849, 245, 'sea_prod', ''),
(1850, 245, '_sea_prod', 'field_66f90ed23f720'),
(1851, 245, 'coll_button_text', ''),
(1852, 245, '_coll_button_text', 'field_66f90ed23fad4'),
(1853, 245, 'coll_button_link', ''),
(1854, 245, '_coll_button_link', 'field_66f90ed23feb1'),
(1855, 245, 'discount_prod', ''),
(1856, 245, '_discount_prod', 'field_66f90ed2406d8'),
(1857, 245, 'cust_title', ''),
(1858, 245, '_cust_title', 'field_66f90ed240e9c'),
(1859, 245, 'customers_quotes', ''),
(1860, 245, '_customers_quotes', 'field_66f90ed241248'),
(1861, 245, 'product_slider', ''),
(1862, 245, '_product_slider', 'field_66f90ed241a2d'),
(1863, 245, 'sust_title', 'Sustainability Pillar'),
(1864, 245, '_sust_title', 'field_66f90ed23bc44'),
(1865, 245, 'sust_imagecontent', '2'),
(1866, 245, '_sust_imagecontent', 'field_66f90ed23c054'),
(1867, 245, 'video_title', 'Making a Difference'),
(1868, 245, '_video_title', 'field_66f90ed23cfd1'),
(1869, 245, 'video_image', '255'),
(1870, 245, '_video_image', 'field_66f90ed23d3b1'),
(1871, 245, 'bt_background_image', '256'),
(1872, 245, '_bt_background_image', 'field_66f90ed23db88'),
(1873, 245, 'bt_heading', 'OUR PURPOSE'),
(1874, 245, '_bt_heading', 'field_66f90ed23df6c'),
(1875, 245, 'bt_content', 'Empower people to live their best lives with the least impact on the planet.'),
(1876, 245, '_bt_content', 'field_66f90ed23e3ad'),
(1877, 245, 'bt_button_text', 'PRODUCTS'),
(1878, 245, '_bt_button_text', 'field_66f90ed23e73d'),
(1879, 245, 'bt_button_link', ''),
(1880, 245, '_bt_button_link', 'field_66f90ed23eb26'),
(1881, 242, 'sust_content', 'We\'re all about putting our principles into practice, making fashion more responsible, and weaving a more sustainable future—for your wardrobe and the planet.'),
(1882, 242, '_sust_content', 'field_66fa74c25288a'),
(1883, 242, 'video_content', 'We’re staying true to our radically transparent roots and breaking down the efforts behind.'),
(1884, 242, '_video_content', 'field_66fa7755f843e'),
(1885, 245, 'sust_content', 'We\'re all about putting our principles into practice, making fashion more responsible, and weaving a more sustainable future—for your wardrobe and the planet.'),
(1886, 245, '_sust_content', 'field_66fa74c25288a'),
(1887, 245, 'video_content', 'We’re staying true to our radically transparent roots and breaking down the efforts behind.'),
(1888, 245, '_video_content', 'field_66fa7755f843e'),
(1889, 253, '_wp_attached_file', '2024/09/earth.jpg'),
(1890, 253, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:836;s:6:"height";i:509;s:4:"file";s:17:"2024/09/earth.jpg";s:8:"filesize";i:517990;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:17:"earth-300x183.jpg";s:5:"width";i:300;s:6:"height";i:183;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14743;}s:9:"thumbnail";a:5:{s:4:"file";s:17:"earth-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7327;}s:12:"medium_large";a:5:{s:4:"file";s:17:"earth-768x468.jpg";s:5:"width";i:768;s:6:"height";i:468;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:72932;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1891, 254, '_wp_attached_file', '2024/09/people.jpg'),
(1892, 254, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:836;s:6:"height";i:509;s:4:"file";s:18:"2024/09/people.jpg";s:8:"filesize";i:363051;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:18:"people-300x183.jpg";s:5:"width";i:300;s:6:"height";i:183;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12238;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"people-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6503;}s:12:"medium_large";a:5:{s:4:"file";s:18:"people-768x468.jpg";s:5:"width";i:768;s:6:"height";i:468;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:58605;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1893, 255, '_wp_attached_file', '2024/09/video-banner.jpg'),
(1894, 255, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1733;s:6:"height";i:677;s:4:"file";s:24:"2024/09/video-banner.jpg";s:8:"filesize";i:949426;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:24:"video-banner-300x117.jpg";s:5:"width";i:300;s:6:"height";i:117;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10598;}s:5:"large";a:5:{s:4:"file";s:25:"video-banner-1024x400.jpg";s:5:"width";i:1024;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:69366;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"video-banner-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7781;}s:12:"medium_large";a:5:{s:4:"file";s:24:"video-banner-768x300.jpg";s:5:"width";i:768;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:43905;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"video-banner-1536x600.jpg";s:5:"width";i:1536;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:137252;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1895, 256, '_wp_attached_file', '2024/09/purpose-banner.jpg'),
(1896, 256, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1398;s:4:"file";s:26:"2024/09/purpose-banner.jpg";s:8:"filesize";i:1851053;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:26:"purpose-banner-300x218.jpg";s:5:"width";i:300;s:6:"height";i:218;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11999;}s:5:"large";a:5:{s:4:"file";s:27:"purpose-banner-1024x746.jpg";s:5:"width";i:1024;s:6:"height";i:746;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:105132;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"purpose-banner-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4913;}s:12:"medium_large";a:5:{s:4:"file";s:26:"purpose-banner-768x559.jpg";s:5:"width";i:768;s:6:"height";i:559;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:63066;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"purpose-banner-1536x1118.jpg";s:5:"width";i:1536;s:6:"height";i:1118;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:211617;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1897, 242, 'sust_imagecontent_0_sust_image', '253'),
(1898, 242, '_sust_imagecontent_0_sust_image', 'field_66f90ed37ae47'),
(1899, 242, 'sust_imagecontent_0_sust_name', 'Keep Earth Clean'),
(1900, 242, '_sust_imagecontent_0_sust_name', 'field_66f90ed37a940'),
(1901, 242, 'sust_imagecontent_0_sust_content', 'We’re focused on fewer inputs and cleaner outputs—reducing natural resource consumption, minimizing waste and pollution\r\n'),
(1902, 242, '_sust_imagecontent_0_sust_content', 'field_66f90ed37b134'),
(1903, 242, 'sust_imagecontent_1_sust_image', '254'),
(1904, 242, '_sust_imagecontent_1_sust_image', 'field_66f90ed37ae47'),
(1905, 242, 'sust_imagecontent_1_sust_name', 'Do Right By People'),
(1906, 242, '_sust_imagecontent_1_sust_name', 'field_66f90ed37a940'),
(1907, 242, 'sust_imagecontent_1_sust_content', 'We’re working to enhance worker livelihood, achieve gender equality, and promote fair living wages.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1908, 242, '_sust_imagecontent_1_sust_content', 'field_66f90ed37b134'),
(1909, 242, 'video_src', ''),
(1910, 242, '_video_src', 'field_66fa80e2efeee'),
(1911, 242, 'signature_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(1912, 242, '_signature_content', 'field_66fa84cf39722'),
(1913, 242, 'upload_sign', '237'),
(1914, 242, '_upload_sign', 'field_66fa84f839723'),
(1915, 245, 'sust_imagecontent_0_sust_image', '253'),
(1916, 245, '_sust_imagecontent_0_sust_image', 'field_66f90ed37ae47'),
(1917, 245, 'sust_imagecontent_0_sust_name', 'Keep Earth Clean'),
(1918, 245, '_sust_imagecontent_0_sust_name', 'field_66f90ed37a940'),
(1919, 245, 'sust_imagecontent_0_sust_content', 'We’re focused on fewer inputs and cleaner outputs—reducing natural resource consumption, minimizing waste and pollution\r\n'),
(1920, 245, '_sust_imagecontent_0_sust_content', 'field_66f90ed37b134'),
(1921, 245, 'sust_imagecontent_1_sust_image', '254'),
(1922, 245, '_sust_imagecontent_1_sust_image', 'field_66f90ed37ae47'),
(1923, 245, 'sust_imagecontent_1_sust_name', 'Do Right By People'),
(1924, 245, '_sust_imagecontent_1_sust_name', 'field_66f90ed37a940'),
(1925, 245, 'sust_imagecontent_1_sust_content', 'We’re working to enhance worker livelihood, achieve gender equality, and promote fair living wages.'),
(1926, 245, '_sust_imagecontent_1_sust_content', 'field_66f90ed37b134'),
(1927, 245, 'video_src', ''),
(1928, 245, '_video_src', 'field_66fa80e2efeee'),
(1929, 245, 'signature_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(1930, 245, '_signature_content', 'field_66fa84cf39722'),
(1931, 245, 'upload_sign', '237'),
(1932, 245, '_upload_sign', 'field_66fa84f839723'),
(1933, 258, '_wp_page_template', 'template-contact.php'),
(1934, 258, '_edit_last', '1'),
(1935, 258, '_wp_page_template', 'template-contact.php'),
(1936, 258, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(1937, 258, '_edit_lock', '1727694633:1'),
(1938, 258, '_thumbnail_id', '88'),
(1939, 258, 'banner_heading', 'About Crosstherads'),
(1940, 258, '_banner_heading', 'field_66f90eb93642d'),
(1941, 258, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(1942, 258, '_banner_content', 'field_66f90eb936816'),
(1943, 258, 'categ_title', ''),
(1944, 258, '_categ_title', 'field_66f90eb936fe6'),
(1945, 258, 'prod_categories', ''),
(1946, 258, '_prod_categories', 'field_66f90eb9373ce'),
(1947, 258, 'categ_button_text', ''),
(1948, 258, '_categ_button_text', 'field_66f90eb9377b7'),
(1949, 258, 'categ_button_link', ''),
(1950, 258, '_categ_button_link', 'field_66f90eb937ba0'),
(1951, 258, 'icon_title', ''),
(1952, 258, '_icon_title', 'field_66f90eb938382'),
(1953, 258, 'icon_details', ''),
(1954, 258, '_icon_details', 'field_66f90eb938778'),
(1955, 258, 'ab_background_image', ''),
(1956, 258, '_ab_background_image', 'field_66f90eb938f2b'),
(1957, 258, 'ab_heading', ''),
(1958, 258, '_ab_heading', 'field_66f90eb93932b'),
(1959, 258, 'ab_content', '<p data-aos="fade-in" data-aos-delay="100">We believe that every thread tells a story. From the sourcing of our eco-friendly materials to the ethical craftsmanship that brings each piece to life, our clothing is designed to respect the environment and honor the people who make it. Our collections are a testament to the beauty of simplicity and the power of conscious choices.</p>\r\n<p data-aos="fade-in" data-aos-delay="200">At Crossthreads, we don’t just create clothes; we create connections. Connections between style and sustainability, between tradition and innovation, and between you and a more sustainable future. Join us in weaving a better world, one thread at a time.</p>'),
(1960, 258, '_ab_content', 'field_66f90eb9377b7'),
(1961, 258, 'ab_button_text', ''),
(1962, 258, '_ab_button_text', 'field_66f90eb939afa'),
(1963, 258, 'ab_button_link', ''),
(1964, 258, '_ab_button_link', 'field_66f90eb939ee0'),
(1965, 258, 'season_title', 'Our mission'),
(1966, 258, '_season_title', 'field_66f90eb93a6be'),
(1967, 258, 'sea_prod', ''),
(1968, 258, '_sea_prod', 'field_66f90eb93aa9c'),
(1969, 258, 'coll_button_text', ''),
(1970, 258, '_coll_button_text', 'field_66f90eb93ae88'),
(1971, 258, 'coll_button_link', ''),
(1972, 258, '_coll_button_link', 'field_66f90eb93b25c'),
(1973, 258, 'discount_prod', ''),
(1974, 258, '_discount_prod', 'field_66f90eb93ba2a'),
(1975, 258, 'cust_title', ''),
(1976, 258, '_cust_title', 'field_66f90eb93c20a'),
(1977, 258, 'customers_quotes', ''),
(1978, 258, '_customers_quotes', 'field_66f90eb93c5e6'),
(1979, 258, 'product_slider', ''),
(1980, 258, '_product_slider', 'field_66f90eb93cdb8'),
(1981, 258, 'b_button_text', 'Learn More'),
(1982, 258, '_b_button_text', 'field_66f9101fc3f27'),
(1983, 258, 'b_button_link', '#'),
(1984, 258, '_b_button_link', 'field_66f91024c3f28'),
(1985, 258, 'ab_title', 'At Crossthreads, sustainability is woven into the very fabric of our identity. Born from a desire to create clothing that cares for both people and the planet, we are committed to crafting garments that leave a lighter footprint on the Earth. Our journey began with a simple idea: to offer fashion that is as responsible as it is stylish.\r\n'),
(1986, 258, '_ab_title', 'field_66f90eb936fe6'),
(1987, 258, 'mission_image', '232'),
(1988, 258, '_mission_image', 'field_66f90eb93aa9c'),
(1989, 258, 'ab_left_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(1990, 258, '_ab_left_content', 'field_66f90eb93ae88'),
(1991, 258, 'sust_heading', 'Sustainability'),
(1992, 258, '_sust_heading', 'field_66f90eb93ba2a'),
(1993, 258, 'sust_content', 'We are committed to minimizing our environmental footprint through responsible sourcing, ethical production, and thoughtful design. Every piece of clothing we create is a step toward a greener future.'),
(1994, 258, '_sust_content', 'field_66f96daf0462b'),
(1995, 258, 'sust_image', '88'),
(1996, 258, '_sust_image', 'field_66f96e4104631'),
(1997, 258, 'img_title', 'Quality'),
(1998, 258, '_img_title', 'field_66f96f68e5375'),
(1999, 258, 'ab_right_content', 'At Crossthreads, our mission is to redefine fashion with purpose. We aim to create clothing that embodies style, comfort, and sustainability, empowering our customers to make choices that positively impact the environment and society. Through innovation and a deep respect for our planet, we strive to lead the way in sustainable fashion, inspiring a more conscious and connected world.'),
(2000, 258, '_ab_right_content', 'field_66f96f6de5376'),
(2001, 258, 'ab_image_right', '232'),
(2002, 258, '_ab_image_right', 'field_66f96f64e5374'),
(2003, 258, 'sign_title', 'Ethical Practices'),
(2004, 258, '_sign_title', 'field_66f970b4e5378'),
(2005, 258, 'sign_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(2006, 258, '_sign_content', 'field_66f970cce5379'),
(2007, 258, 'sign_image', '237') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2008, 258, '_sign_image', 'field_66f970f3e537a'),
(2009, 260, '_menu_item_type', 'post_type'),
(2010, 260, '_menu_item_menu_item_parent', '0'),
(2011, 260, '_menu_item_object_id', '5'),
(2012, 260, '_menu_item_object', 'page'),
(2013, 260, '_menu_item_target', ''),
(2014, 260, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2015, 260, '_menu_item_xfn', ''),
(2016, 260, '_menu_item_url', ''),
(2018, 261, '_menu_item_type', 'post_type'),
(2019, 261, '_menu_item_menu_item_parent', '0'),
(2020, 261, '_menu_item_object_id', '81'),
(2021, 261, '_menu_item_object', 'page'),
(2022, 261, '_menu_item_target', ''),
(2023, 261, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2024, 261, '_menu_item_xfn', ''),
(2025, 261, '_menu_item_url', ''),
(2027, 262, '_menu_item_type', 'post_type'),
(2028, 262, '_menu_item_menu_item_parent', '0'),
(2029, 262, '_menu_item_object_id', '258'),
(2030, 262, '_menu_item_object', 'page'),
(2031, 262, '_menu_item_target', ''),
(2032, 262, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2033, 262, '_menu_item_xfn', ''),
(2034, 262, '_menu_item_url', ''),
(2036, 263, '_menu_item_type', 'post_type'),
(2037, 263, '_menu_item_menu_item_parent', '0'),
(2038, 263, '_menu_item_object_id', '242'),
(2039, 263, '_menu_item_object', 'page'),
(2040, 263, '_menu_item_target', ''),
(2041, 263, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2042, 263, '_menu_item_xfn', ''),
(2043, 263, '_menu_item_url', ''),
(2045, 264, '_wp_page_template', 'template-sustainability.php'),
(2046, 264, '_edit_last', '1'),
(2047, 264, '_edit_lock', '1727765515:1'),
(2048, 264, '_thumbnail_id', '243'),
(2049, 264, '_wp_page_template', 'template-sustainability.php'),
(2050, 264, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(2051, 264, 'banner_heading', 'Fashioning A Better Future'),
(2052, 264, '_banner_heading', 'field_66f90ed23b08f'),
(2053, 264, 'banner_content', 'Wear your impact with pride. Crossthreads— where every thread tells a story of sustainability'),
(2054, 264, '_banner_content', 'field_66f90ed23b477'),
(2055, 264, 'categ_title', ''),
(2056, 264, '_categ_title', 'field_66f90ed23bc44'),
(2057, 264, 'prod_categories', ''),
(2058, 264, '_prod_categories', 'field_66f90ed23c054'),
(2059, 264, 'categ_button_text', ''),
(2060, 264, '_categ_button_text', 'field_66f90ed23c417'),
(2061, 264, 'categ_button_link', ''),
(2062, 264, '_categ_button_link', 'field_66f90ed23c7fe'),
(2063, 264, 'icon_title', ''),
(2064, 264, '_icon_title', 'field_66f90ed23cfd1'),
(2065, 264, 'icon_details', ''),
(2066, 264, '_icon_details', 'field_66f90ed23d3b1'),
(2067, 264, 'ab_background_image', ''),
(2068, 264, '_ab_background_image', 'field_66f90ed23db88'),
(2069, 264, 'ab_heading', ''),
(2070, 264, '_ab_heading', 'field_66f90ed23df6c'),
(2071, 264, 'ab_content', ''),
(2072, 264, '_ab_content', 'field_66f90ed23e3ad'),
(2073, 264, 'ab_button_text', ''),
(2074, 264, '_ab_button_text', 'field_66f90ed23e73d'),
(2075, 264, 'ab_button_link', ''),
(2076, 264, '_ab_button_link', 'field_66f90ed23eb26'),
(2077, 264, 'season_title', ''),
(2078, 264, '_season_title', 'field_66f90ed23f2fe'),
(2079, 264, 'sea_prod', ''),
(2080, 264, '_sea_prod', 'field_66f90ed23f720'),
(2081, 264, 'coll_button_text', ''),
(2082, 264, '_coll_button_text', 'field_66f90ed23fad4'),
(2083, 264, 'coll_button_link', ''),
(2084, 264, '_coll_button_link', 'field_66f90ed23feb1'),
(2085, 264, 'discount_prod', ''),
(2086, 264, '_discount_prod', 'field_66f90ed2406d8'),
(2087, 264, 'cust_title', ''),
(2088, 264, '_cust_title', 'field_66f90ed240e9c'),
(2089, 264, 'customers_quotes', ''),
(2090, 264, '_customers_quotes', 'field_66f90ed241248'),
(2091, 264, 'product_slider', ''),
(2092, 264, '_product_slider', 'field_66f90ed241a2d'),
(2093, 264, 'sust_title', 'Sustainability Pillar'),
(2094, 264, '_sust_title', 'field_66f90ed23bc44'),
(2095, 264, 'sust_imagecontent', '2'),
(2096, 264, '_sust_imagecontent', 'field_66f90ed23c054'),
(2097, 264, 'video_title', 'Making a Difference'),
(2098, 264, '_video_title', 'field_66f90ed23cfd1'),
(2099, 264, 'video_image', '255'),
(2100, 264, '_video_image', 'field_66f90ed23d3b1'),
(2101, 264, 'bt_background_image', '256'),
(2102, 264, '_bt_background_image', 'field_66f90ed23db88'),
(2103, 264, 'bt_heading', 'OUR PURPOSE'),
(2104, 264, '_bt_heading', 'field_66f90ed23df6c'),
(2105, 264, 'bt_content', 'Empower people to live their best lives with the least impact on the planet.'),
(2106, 264, '_bt_content', 'field_66f90ed23e3ad'),
(2107, 264, 'bt_button_text', 'PRODUCTS'),
(2108, 264, '_bt_button_text', 'field_66f90ed23e73d'),
(2109, 264, 'bt_button_link', ''),
(2110, 264, '_bt_button_link', 'field_66f90ed23eb26'),
(2111, 264, 'sust_content', 'We\'re all about putting our principles into practice, making fashion more responsible, and weaving a more sustainable future—for your wardrobe and the planet.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2112, 264, '_sust_content', 'field_66fa74c25288a'),
(2113, 264, 'video_content', 'We’re staying true to our radically transparent roots and breaking down the efforts behind.'),
(2114, 264, '_video_content', 'field_66fa7755f843e'),
(2115, 264, 'sust_imagecontent_0_sust_image', '253'),
(2116, 264, '_sust_imagecontent_0_sust_image', 'field_66f90ed37ae47'),
(2117, 264, 'sust_imagecontent_0_sust_name', 'Keep Earth Clean'),
(2118, 264, '_sust_imagecontent_0_sust_name', 'field_66f90ed37a940'),
(2119, 264, 'sust_imagecontent_0_sust_content', 'We’re focused on fewer inputs and cleaner outputs—reducing natural resource consumption, minimizing waste and pollution\r\n'),
(2120, 264, '_sust_imagecontent_0_sust_content', 'field_66f90ed37b134'),
(2121, 264, 'sust_imagecontent_1_sust_image', '254'),
(2122, 264, '_sust_imagecontent_1_sust_image', 'field_66f90ed37ae47'),
(2123, 264, 'sust_imagecontent_1_sust_name', 'Do Right By People'),
(2124, 264, '_sust_imagecontent_1_sust_name', 'field_66f90ed37a940'),
(2125, 264, 'sust_imagecontent_1_sust_content', 'We’re working to enhance worker livelihood, achieve gender equality, and promote fair living wages.'),
(2126, 264, '_sust_imagecontent_1_sust_content', 'field_66f90ed37b134'),
(2127, 264, 'video_src', ''),
(2128, 264, '_video_src', 'field_66fa80e2efeee'),
(2129, 264, 'signature_content', 'We uphold the highest standards of fairness and integrity in our relationships with our workers, suppliers, and customers. Our clothing is made by skilled artisans who are paid fairly and work in safe, dignified conditions.'),
(2130, 264, '_signature_content', 'field_66fa84cf39722'),
(2131, 264, 'upload_sign', '237'),
(2132, 264, '_upload_sign', 'field_66fa84f839723'),
(2133, 266, '_edit_last', '1'),
(2134, 266, '_edit_lock', '1727767618:1'),
(2135, 266, '_wp_page_template', 'template-terms.php'),
(2136, 266, '_yoast_wpseo_estimated-reading-time-minutes', '4'),
(2137, 266, '_yoast_wpseo_content_score', '30'),
(2138, 280, '_wp_attached_file', 'woocommerce-placeholder.png'),
(2139, 280, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:27:"woocommerce-placeholder.png";s:8:"filesize";i:48149;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:35:"woocommerce-placeholder-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12321;}s:5:"large";a:5:{s:4:"file";s:37:"woocommerce-placeholder-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:90808;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4209;}s:12:"medium_large";a:5:{s:4:"file";s:35:"woocommerce-placeholder-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:56643;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(2140, 287, '_edit_last', '1'),
(2141, 287, '_edit_lock', '1727775554:1'),
(2142, 288, '_wp_attached_file', '2024/10/img-five.jpg'),
(2143, 288, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:568;s:6:"height";i:669;s:4:"file";s:20:"2024/10/img-five.jpg";s:8:"filesize";i:163862;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:20:"img-five-255x300.jpg";s:5:"width";i:255;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9511;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"img-five-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4073;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:20:"img-five-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10692;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:20:"img-five-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2530;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(2144, 287, '_thumbnail_id', '288'),
(2145, 287, '_regular_price', '49.99'),
(2146, 287, 'total_sales', '0'),
(2147, 287, '_tax_status', 'taxable'),
(2148, 287, '_tax_class', ''),
(2149, 287, '_manage_stock', 'no'),
(2150, 287, '_backorders', 'no'),
(2151, 287, '_sold_individually', 'no'),
(2152, 287, '_virtual', 'no'),
(2153, 287, '_downloadable', 'no'),
(2154, 287, '_download_limit', '-1'),
(2155, 287, '_download_expiry', '-1'),
(2156, 287, '_stock', NULL),
(2157, 287, '_stock_status', 'instock'),
(2158, 287, '_wc_average_rating', '0'),
(2159, 287, '_wc_review_count', '0'),
(2160, 287, '_product_version', '9.3.3'),
(2161, 287, '_price', '49.99'),
(2162, 287, '_yoast_wpseo_primary_product_cat', '18'),
(2163, 287, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(2164, 287, '_product_image_gallery', '288'),
(2165, 287, '_yoast_wpseo_content_score', '60'),
(2166, 295, '_wp_attached_file', '2024/10/icon-five.svg'),
(2167, 295, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:3962;}'),
(2168, 296, '_wp_attached_file', '2024/10/icon-seven.svg'),
(2169, 296, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:3850;}'),
(2170, 297, '_wp_attached_file', '2024/10/icon-six.svg'),
(2171, 297, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:6954;}'),
(2172, 307, '_wp_attached_file', '2024/10/insta.svg'),
(2173, 307, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:948;}'),
(2174, 308, '_wp_attached_file', '2024/10/fb.svg'),
(2175, 308, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:447;}'),
(2176, 285, '_edit_lock', '1727779398:1'),
(2177, 285, '_edit_last', '1'),
(2178, 285, '_wp_page_template', 'default'),
(2179, 285, '_yoast_wpseo_content_score', '60'),
(2180, 285, '_yoast_wpseo_estimated-reading-time-minutes', '3'),
(2181, 3, '_edit_lock', '1727782259:1'),
(2182, 3, '_edit_last', '1'),
(2183, 3, '_yoast_wpseo_content_score', '30'),
(2184, 3, '_yoast_wpseo_estimated-reading-time-minutes', '3'),
(2185, 284, '_edit_lock', '1727782382:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=313 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-09-13 15:51:53', '2024-09-13 15:51:53', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2024-09-30 09:15:02', '2024-09-30 09:15:02', '', 0, 'http://localhost/crossthreads/site/?p=1', 0, 'post', '', 1),
(2, 1, '2024-09-13 15:51:53', '2024-09-13 15:51:53', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost/crossthreads/site/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2024-09-13 15:51:53', '2024-09-13 15:51:53', '', 0, 'http://localhost/crossthreads/site/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-09-13 15:51:53', '2024-09-13 15:51:53', '<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Who we are</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost/crossthreads/site.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Comments</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Media</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Cookies</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Who we share your data with</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">How long we retain your data</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">What rights you have over your data</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Where your data is sent</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\r\n<!-- /wp:paragraph -->\r\n', 'Privacy Policy', '', 'publish', 'closed', 'open', '', 'privacy-policy', '', '', '2024-10-01 10:45:57', '2024-10-01 10:45:57', '', 0, 'http://localhost/crossthreads/site/?page_id=3', 0, 'page', '', 0),
(5, 1, '2024-09-19 09:36:56', '2024-09-19 09:36:56', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2024-09-29 08:13:24', '2024-09-29 08:13:24', '', 0, 'http://localhost/crossthreads/site/?page_id=5', 0, 'page', '', 0),
(6, 1, '2024-09-19 09:36:56', '2024-09-19 09:36:56', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2024-09-19 09:36:56', '2024-09-19 09:36:56', '', 5, 'http://localhost/crossthreads/site/?p=6', 0, 'revision', '', 0),
(7, 1, '2024-09-19 09:37:56', '2024-09-19 09:37:56', '', 'banner', '', 'inherit', 'open', 'closed', '', 'banner', '', '', '2024-09-19 09:37:56', '2024-09-19 09:37:56', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner.webp', 0, 'attachment', 'image/webp', 0),
(8, 1, '2024-09-19 09:45:04', '2024-09-19 09:45:04', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:22:"theme-general-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Theme General Settings', 'theme-general-settings', 'publish', 'closed', 'closed', '', 'group_66ebf2454b6f3', '', '', '2024-10-01 10:39:17', '2024-10-01 10:39:17', '', 0, 'http://localhost/crossthreads/site/?post_type=acf-field-group&#038;p=8', 0, 'acf-field-group', '', 0),
(9, 1, '2024-09-19 09:45:04', '2024-09-19 09:45:04', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Logo', 'logo', 'publish', 'closed', 'closed', '', 'field_66ebf261f88d8', '', '', '2024-09-19 09:45:04', '2024-09-19 09:45:04', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=9', 0, 'acf-field', '', 0),
(10, 1, '2024-09-19 09:45:04', '2024-09-19 09:45:04', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Header Logo', 'header_logo', 'publish', 'closed', 'closed', '', 'field_66ebf270f88d9', '', '', '2024-09-19 09:45:04', '2024-09-19 09:45:04', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=10', 1, 'acf-field', '', 0),
(11, 1, '2024-09-19 09:45:04', '2024-09-19 09:45:04', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Footer Logo', 'footer_logo', 'publish', 'closed', 'closed', '', 'field_66ebf284f88da', '', '', '2024-09-19 09:45:04', '2024-09-19 09:45:04', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=11', 2, 'acf-field', '', 0),
(12, 1, '2024-09-19 09:48:17', '2024-09-19 09:48:17', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2024-09-19 09:48:17', '2024-09-19 09:48:17', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(13, 1, '2024-09-19 09:48:28', '2024-09-19 09:48:28', '', 'cross-ft-logo', '', 'inherit', 'open', 'closed', '', 'cross-ft-logo', '', '', '2024-09-19 09:48:28', '2024-09-19 09:48:28', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/cross-ft-logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(14, 1, '2024-09-19 09:53:28', '2024-09-19 09:53:28', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header Icons', 'header_icons', 'publish', 'closed', 'closed', '', 'field_66ebf406adf37', '', '', '2024-09-19 09:53:28', '2024-09-19 09:53:28', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=14', 3, 'acf-field', '', 0),
(15, 1, '2024-09-19 09:53:29', '2024-09-19 09:53:29', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";i:2;s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Icons', 'header_icons', 'publish', 'closed', 'closed', '', 'field_66ebf427adf38', '', '', '2024-09-19 09:54:45', '2024-09-19 09:54:45', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=15', 4, 'acf-field', '', 0),
(16, 1, '2024-09-19 09:53:29', '2024-09-19 09:53:29', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Icons', 'h_icons', 'publish', 'closed', 'closed', '', 'field_66ebf447adf39', '', '', '2024-09-19 09:53:29', '2024-09-19 09:53:29', '', 15, 'http://localhost/crossthreads/site/?post_type=acf-field&p=16', 0, 'acf-field', '', 0),
(17, 1, '2024-09-19 09:53:29', '2024-09-19 09:53:29', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link', 'h_link', 'publish', 'closed', 'closed', '', 'field_66ebf46eadf3a', '', '', '2024-09-19 09:53:29', '2024-09-19 09:53:29', '', 15, 'http://localhost/crossthreads/site/?post_type=acf-field&p=17', 1, 'acf-field', '', 0),
(18, 1, '2024-09-19 09:53:57', '2024-09-19 09:53:57', '', 'account', '', 'inherit', 'open', 'closed', '', 'account', '', '', '2024-09-19 09:53:57', '2024-09-19 09:53:57', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/account.svg', 0, 'attachment', 'image/svg+xml', 0),
(19, 1, '2024-09-19 09:53:58', '2024-09-19 09:53:58', '', 'cart', '', 'inherit', 'open', 'closed', '', 'cart', '', '', '2024-09-19 09:53:58', '2024-09-19 09:53:58', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/cart.svg', 0, 'attachment', 'image/svg+xml', 0),
(21, 1, '2024-09-27 15:56:24', '2024-09-27 15:55:34', '', 'Men', '', 'publish', 'closed', 'closed', '', 'men', '', '', '2024-09-27 15:56:24', '2024-09-27 15:56:24', '', 0, 'http://localhost/crossthreads/site/?p=21', 1, 'nav_menu_item', '', 0),
(22, 1, '2024-09-27 15:56:24', '2024-09-27 15:55:35', '', 'Women', '', 'publish', 'closed', 'closed', '', 'women', '', '', '2024-09-27 15:56:24', '2024-09-27 15:56:24', '', 0, 'http://localhost/crossthreads/site/?p=22', 2, 'nav_menu_item', '', 0),
(23, 1, '2024-09-27 15:56:24', '2024-09-27 15:55:35', '', 'Kids', '', 'publish', 'closed', 'closed', '', 'kids', '', '', '2024-09-27 15:56:24', '2024-09-27 15:56:24', '', 0, 'http://localhost/crossthreads/site/?p=23', 3, 'nav_menu_item', '', 0),
(24, 1, '2024-09-27 15:56:25', '2024-09-27 15:56:25', '', 'Wellness', '', 'publish', 'closed', 'closed', '', 'wellness', '', '', '2024-09-27 15:56:25', '2024-09-27 15:56:25', '', 0, 'http://localhost/crossthreads/site/?p=24', 4, 'nav_menu_item', '', 0),
(25, 1, '2024-09-27 15:56:25', '2024-09-27 15:56:25', '', 'Cloths', '', 'publish', 'closed', 'closed', '', 'cloths', '', '', '2024-09-27 15:56:25', '2024-09-27 15:56:25', '', 0, 'http://localhost/crossthreads/site/?p=25', 5, 'nav_menu_item', '', 0),
(26, 1, '2024-09-27 17:28:51', '2024-09-27 17:28:51', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"template-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Home Page Settings', 'home-page-settings', 'publish', 'closed', 'closed', '', 'group_66f6eab8e1dc0', '', '', '2024-09-29 05:33:05', '2024-09-29 05:33:05', '', 0, 'http://localhost/crossthreads/site/?post_type=acf-field-group&#038;p=26', 0, 'acf-field-group', '', 0),
(27, 1, '2024-09-27 17:28:51', '2024-09-27 17:28:51', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Banner Section', 'banner_section', 'publish', 'closed', 'closed', '', 'field_66f6ead98a8c5', '', '', '2024-09-27 17:28:51', '2024-09-27 17:28:51', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&p=27', 0, 'acf-field', '', 0),
(28, 1, '2024-09-27 17:28:52', '2024-09-27 17:28:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'banner_heading', 'publish', 'closed', 'closed', '', 'field_66f6eaf08a8c6', '', '', '2024-09-27 17:28:52', '2024-09-27 17:28:52', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&p=28', 1, 'acf-field', '', 0),
(29, 1, '2024-09-27 17:28:52', '2024-09-27 17:28:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Content', 'banner_content', 'publish', 'closed', 'closed', '', 'field_66f6eb3c8a8c7', '', '', '2024-09-27 17:44:21', '2024-09-27 17:44:21', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=29', 2, 'acf-field', '', 0),
(30, 1, '2024-09-27 17:33:24', '2024-09-27 17:33:24', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Product Category Section', 'product_category_section', 'publish', 'closed', 'closed', '', 'field_66f6eb5f03747', '', '', '2024-09-27 17:44:22', '2024-09-27 17:44:22', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=30', 3, 'acf-field', '', 0),
(31, 1, '2024-09-27 17:33:24', '2024-09-27 17:33:24', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'categ_title', 'publish', 'closed', 'closed', '', 'field_66f6eb7a03748', '', '', '2024-09-27 17:44:22', '2024-09-27 17:44:22', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=31', 4, 'acf-field', '', 0),
(32, 1, '2024-09-27 17:33:25', '2024-09-27 17:33:25', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Categories', 'prod_categories', 'publish', 'closed', 'closed', '', 'field_66f6ebc803749', '', '', '2024-09-27 17:44:22', '2024-09-27 17:44:22', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=32', 5, 'acf-field', '', 0),
(33, 1, '2024-09-27 17:33:25', '2024-09-27 17:33:25', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'categ_name', 'publish', 'closed', 'closed', '', 'field_66f6ebe60374a', '', '', '2024-09-27 17:33:25', '2024-09-27 17:33:25', '', 32, 'http://localhost/crossthreads/site/?post_type=acf-field&p=33', 0, 'acf-field', '', 0),
(34, 1, '2024-09-27 17:33:25', '2024-09-27 17:33:25', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'categ_image', 'publish', 'closed', 'closed', '', 'field_66f6ec080374b', '', '', '2024-09-27 17:33:25', '2024-09-27 17:33:25', '', 32, 'http://localhost/crossthreads/site/?post_type=acf-field&p=34', 1, 'acf-field', '', 0),
(35, 1, '2024-09-27 17:33:25', '2024-09-27 17:33:25', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link', 'categ_link', 'publish', 'closed', 'closed', '', 'field_66f6ec470374c', '', '', '2024-09-27 17:33:25', '2024-09-27 17:33:25', '', 32, 'http://localhost/crossthreads/site/?post_type=acf-field&p=35', 2, 'acf-field', '', 0),
(36, 1, '2024-09-27 17:34:22', '2024-09-27 17:34:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'categ_button_text', 'publish', 'closed', 'closed', '', 'field_66f6ec6d591d0', '', '', '2024-09-27 17:51:14', '2024-09-27 17:51:14', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=36', 6, 'acf-field', '', 0),
(37, 1, '2024-09-27 17:34:23', '2024-09-27 17:34:23', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Button Link', 'categ_button_link', 'publish', 'closed', 'closed', '', 'field_66f6ec81591d1', '', '', '2024-09-27 17:51:14', '2024-09-27 17:51:14', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=37', 7, 'acf-field', '', 0),
(38, 1, '2024-09-27 17:39:22', '2024-09-27 17:39:22', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Icon section', 'icon_section', 'publish', 'closed', 'closed', '', 'field_66f6ed09ace0b', '', '', '2024-09-27 17:51:14', '2024-09-27 17:51:14', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=38', 8, 'acf-field', '', 0),
(39, 1, '2024-09-27 17:39:22', '2024-09-27 17:39:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'icon_title', 'publish', 'closed', 'closed', '', 'field_66f6ed3bace0c', '', '', '2024-09-27 17:51:14', '2024-09-27 17:51:14', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=39', 9, 'acf-field', '', 0),
(40, 1, '2024-09-27 17:39:22', '2024-09-27 17:39:22', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Icons', 'icon_details', 'publish', 'closed', 'closed', '', 'field_66f6ed42ace0d', '', '', '2024-09-27 17:51:14', '2024-09-27 17:51:14', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=40', 10, 'acf-field', '', 0),
(41, 1, '2024-09-27 17:39:23', '2024-09-27 17:39:23', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Icon Image', 'icon_image', 'publish', 'closed', 'closed', '', 'field_66f6ed42ace0f', '', '', '2024-09-27 17:39:23', '2024-09-27 17:39:23', '', 40, 'http://localhost/crossthreads/site/?post_type=acf-field&p=41', 0, 'acf-field', '', 0),
(42, 1, '2024-09-27 17:39:23', '2024-09-27 17:39:23', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Content', 'icon_name', 'publish', 'closed', 'closed', '', 'field_66f6ed42ace0e', '', '', '2024-09-27 17:39:23', '2024-09-27 17:39:23', '', 40, 'http://localhost/crossthreads/site/?post_type=acf-field&p=42', 1, 'acf-field', '', 0),
(43, 1, '2024-09-27 17:44:22', '2024-09-27 17:44:22', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'About Section', 'about_section', 'publish', 'closed', 'closed', '', 'field_66f6eddf27792', '', '', '2024-09-27 17:51:14', '2024-09-27 17:51:14', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=43', 11, 'acf-field', '', 0),
(44, 1, '2024-09-27 17:44:23', '2024-09-27 17:44:23', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Background Image', 'ab_background_image', 'publish', 'closed', 'closed', '', 'field_66f6edf727793', '', '', '2024-09-27 17:51:14', '2024-09-27 17:51:14', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=44', 12, 'acf-field', '', 0),
(45, 1, '2024-09-27 17:44:23', '2024-09-27 17:44:23', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'ab_heading', 'publish', 'closed', 'closed', '', 'field_66f6ee4c27797', '', '', '2024-09-27 17:51:15', '2024-09-27 17:51:15', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=45', 13, 'acf-field', '', 0),
(46, 1, '2024-09-27 17:44:23', '2024-09-27 17:44:23', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Content', 'ab_content', 'publish', 'closed', 'closed', '', 'field_66f6ee5027798', '', '', '2024-09-27 17:51:15', '2024-09-27 17:51:15', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=46', 14, 'acf-field', '', 0),
(47, 1, '2024-09-27 17:44:24', '2024-09-27 17:44:24', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'ab_button_text', 'publish', 'closed', 'closed', '', 'field_66f6ee3b27795', '', '', '2024-09-27 17:51:15', '2024-09-27 17:51:15', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=47', 15, 'acf-field', '', 0),
(48, 1, '2024-09-27 17:44:24', '2024-09-27 17:44:24', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Button Link', 'ab_button_link', 'publish', 'closed', 'closed', '', 'field_66f6ee4127796', '', '', '2024-09-27 17:52:34', '2024-09-27 17:52:34', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=48', 16, 'acf-field', '', 0),
(49, 1, '2024-09-27 17:51:15', '2024-09-27 17:51:15', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Seasonal Products Section', 'seasonal_products_section', 'publish', 'closed', 'closed', '', 'field_66f6ef3e82d5a', '', '', '2024-09-27 17:52:35', '2024-09-27 17:52:35', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=49', 17, 'acf-field', '', 0),
(50, 1, '2024-09-27 17:51:16', '2024-09-27 17:51:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'season_title', 'publish', 'closed', 'closed', '', 'field_66f6ef5882d5b', '', '', '2024-09-27 17:52:35', '2024-09-27 17:52:35', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=50', 18, 'acf-field', '', 0),
(51, 1, '2024-09-27 17:51:16', '2024-09-27 17:51:16', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Products', 'sea_prod', 'publish', 'closed', 'closed', '', 'field_66f6ef8b82d5c', '', '', '2024-09-27 17:52:35', '2024-09-27 17:52:35', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=51', 19, 'acf-field', '', 0),
(52, 1, '2024-09-27 17:51:16', '2024-09-27 17:51:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'prod_name', 'publish', 'closed', 'closed', '', 'field_66f6ef8b82d5d', '', '', '2024-09-27 17:51:16', '2024-09-27 17:51:16', '', 51, 'http://localhost/crossthreads/site/?post_type=acf-field&p=52', 0, 'acf-field', '', 0),
(53, 1, '2024-09-27 17:51:17', '2024-09-27 17:51:17', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'prod_image', 'publish', 'closed', 'closed', '', 'field_66f6ef8b82d5e', '', '', '2024-09-27 17:51:17', '2024-09-27 17:51:17', '', 51, 'http://localhost/crossthreads/site/?post_type=acf-field&p=53', 1, 'acf-field', '', 0),
(54, 1, '2024-09-27 17:51:17', '2024-09-27 17:51:17', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Product Link', 'prod_link', 'publish', 'closed', 'closed', '', 'field_66f6ef8b82d5f', '', '', '2024-09-27 17:51:17', '2024-09-27 17:51:17', '', 51, 'http://localhost/crossthreads/site/?post_type=acf-field&p=54', 2, 'acf-field', '', 0),
(55, 1, '2024-09-27 17:51:17', '2024-09-27 17:51:17', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Price', 'prod_price', 'publish', 'closed', 'closed', '', 'field_66f6efca82d60', '', '', '2024-09-27 17:51:17', '2024-09-27 17:51:17', '', 51, 'http://localhost/crossthreads/site/?post_type=acf-field&p=55', 3, 'acf-field', '', 0),
(56, 1, '2024-09-27 17:51:17', '2024-09-27 17:51:17', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Link', 'prod_button_link', 'publish', 'closed', 'closed', '', 'field_66f6f07082d61', '', '', '2024-09-27 17:51:17', '2024-09-27 17:51:17', '', 51, 'http://localhost/crossthreads/site/?post_type=acf-field&p=56', 4, 'acf-field', '', 0),
(57, 1, '2024-09-27 17:52:35', '2024-09-27 17:52:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'coll_button_text', 'publish', 'closed', 'closed', '', 'field_66f6f0a26790d', '', '', '2024-09-27 18:01:21', '2024-09-27 18:01:21', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=57', 20, 'acf-field', '', 0),
(58, 1, '2024-09-27 17:52:35', '2024-09-27 17:52:35', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Button Link', 'coll_button_link', 'publish', 'closed', 'closed', '', 'field_66f6f0a66790e', '', '', '2024-09-27 18:01:22', '2024-09-27 18:01:22', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=58', 21, 'acf-field', '', 0),
(59, 1, '2024-09-27 18:01:22', '2024-09-27 18:01:22', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Image Box Section', 'image_box_section', 'publish', 'closed', 'closed', '', 'field_66f6f0fef781b', '', '', '2024-09-27 18:01:22', '2024-09-27 18:01:22', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&p=59', 22, 'acf-field', '', 0),
(60, 1, '2024-09-27 18:01:22', '2024-09-27 18:01:22', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Products', 'discount_prod', 'publish', 'closed', 'closed', '', 'field_66f6f130f781c', '', '', '2024-09-27 18:01:22', '2024-09-27 18:01:22', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&p=60', 23, 'acf-field', '', 0),
(61, 1, '2024-09-27 18:01:23', '2024-09-27 18:01:23', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'disc_prod_image', 'publish', 'closed', 'closed', '', 'field_66f6f130f781e', '', '', '2024-09-27 18:01:23', '2024-09-27 18:01:23', '', 60, 'http://localhost/crossthreads/site/?post_type=acf-field&p=61', 0, 'acf-field', '', 0),
(62, 1, '2024-09-27 18:01:23', '2024-09-27 18:01:23', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Percentage', 'disc_percentage', 'publish', 'closed', 'closed', '', 'field_66f6f130f781f', '', '', '2024-09-27 18:01:23', '2024-09-27 18:01:23', '', 60, 'http://localhost/crossthreads/site/?post_type=acf-field&p=62', 1, 'acf-field', '', 0),
(63, 1, '2024-09-27 18:01:23', '2024-09-27 18:01:23', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'disc_prod_name', 'publish', 'closed', 'closed', '', 'field_66f6f130f781d', '', '', '2024-09-27 18:01:23', '2024-09-27 18:01:23', '', 60, 'http://localhost/crossthreads/site/?post_type=acf-field&p=63', 2, 'acf-field', '', 0),
(64, 1, '2024-09-27 18:01:24', '2024-09-27 18:01:24', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Price', 'disc_prod_price', 'publish', 'closed', 'closed', '', 'field_66f6f130f7820', '', '', '2024-09-27 18:01:24', '2024-09-27 18:01:24', '', 60, 'http://localhost/crossthreads/site/?post_type=acf-field&p=64', 3, 'acf-field', '', 0),
(65, 1, '2024-09-27 18:01:25', '2024-09-27 18:01:25', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Link', 'prod_button_link', 'publish', 'closed', 'closed', '', 'field_66f6f130f7821', '', '', '2024-09-27 18:01:25', '2024-09-27 18:01:25', '', 60, 'http://localhost/crossthreads/site/?post_type=acf-field&p=65', 4, 'acf-field', '', 0),
(66, 1, '2024-09-27 18:45:25', '2024-09-27 18:45:25', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Customers Section', 'customers_section', 'publish', 'closed', 'closed', '', 'field_66f6fc7c242e0', '', '', '2024-09-27 18:49:20', '2024-09-27 18:49:20', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=66', 24, 'acf-field', '', 0),
(67, 1, '2024-09-27 18:45:25', '2024-09-27 18:45:25', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'cust_title', 'publish', 'closed', 'closed', '', 'field_66f6fca3242e1', '', '', '2024-09-27 18:49:21', '2024-09-27 18:49:21', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=67', 25, 'acf-field', '', 0),
(68, 1, '2024-09-27 18:45:26', '2024-09-27 18:45:26', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Customers Quotes', 'customers_quotes', 'publish', 'closed', 'closed', '', 'field_66f6fcb5242e2', '', '', '2024-09-27 18:49:21', '2024-09-27 18:49:21', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=68', 26, 'acf-field', '', 0),
(69, 1, '2024-09-27 18:45:26', '2024-09-27 18:45:26', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'cust_image', 'publish', 'closed', 'closed', '', 'field_66f6fcb5242e3', '', '', '2024-09-27 18:45:26', '2024-09-27 18:45:26', '', 68, 'http://localhost/crossthreads/site/?post_type=acf-field&p=69', 0, 'acf-field', '', 0),
(70, 1, '2024-09-27 18:45:26', '2024-09-27 18:45:26', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'cust_content', 'publish', 'closed', 'closed', '', 'field_66f6fcb5242e4', '', '', '2024-09-27 18:45:26', '2024-09-27 18:45:26', '', 68, 'http://localhost/crossthreads/site/?post_type=acf-field&p=70', 1, 'acf-field', '', 0),
(71, 1, '2024-09-27 18:45:27', '2024-09-27 18:45:27', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'cust_name', 'publish', 'closed', 'closed', '', 'field_66f6fcb5242e5', '', '', '2024-09-27 18:45:27', '2024-09-27 18:45:27', '', 68, 'http://localhost/crossthreads/site/?post_type=acf-field&p=71', 2, 'acf-field', '', 0),
(72, 1, '2024-09-27 18:45:27', '2024-09-27 18:45:27', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Rating', 'cust_rating', 'publish', 'closed', 'closed', '', 'field_66f6fcb5242e6', '', '', '2024-09-27 18:45:27', '2024-09-27 18:45:27', '', 68, 'http://localhost/crossthreads/site/?post_type=acf-field&p=72', 3, 'acf-field', '', 0),
(74, 1, '2024-09-27 18:49:21', '2024-09-27 18:49:21', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Image Slider Section', 'image_slider_section', 'publish', 'closed', 'closed', '', 'field_66f6fd612dbad', '', '', '2024-09-27 18:49:21', '2024-09-27 18:49:21', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&p=74', 27, 'acf-field', '', 0),
(75, 1, '2024-09-27 18:49:21', '2024-09-27 18:49:21', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Product Slider', 'product_slider', 'publish', 'closed', 'closed', '', 'field_66f6fd852dbae', '', '', '2024-09-27 18:49:21', '2024-09-27 18:49:21', '', 26, 'http://localhost/crossthreads/site/?post_type=acf-field&p=75', 28, 'acf-field', '', 0),
(76, 1, '2024-09-27 18:49:21', '2024-09-27 18:49:21', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'slider_prod_image', 'publish', 'closed', 'closed', '', 'field_66f6fd852dbaf', '', '', '2024-09-27 18:49:21', '2024-09-27 18:49:21', '', 75, 'http://localhost/crossthreads/site/?post_type=acf-field&p=76', 0, 'acf-field', '', 0),
(77, 1, '2024-09-27 18:49:21', '2024-09-27 18:49:21', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'slider_prod_name', 'publish', 'closed', 'closed', '', 'field_66f6fd852dbb1', '', '', '2024-09-27 18:49:21', '2024-09-27 18:49:21', '', 75, 'http://localhost/crossthreads/site/?post_type=acf-field&p=77', 1, 'acf-field', '', 0),
(78, 1, '2024-09-27 18:49:22', '2024-09-27 18:49:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Price', 'slider_prod_price', 'publish', 'closed', 'closed', '', 'field_66f6fd852dbb2', '', '', '2024-09-27 18:49:22', '2024-09-27 18:49:22', '', 75, 'http://localhost/crossthreads/site/?post_type=acf-field&p=78', 2, 'acf-field', '', 0),
(79, 1, '2024-09-27 18:49:22', '2024-09-27 18:49:22', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Detail Link', 'slider_detail_link', 'publish', 'closed', 'closed', '', 'field_66f6fd852dbb3', '', '', '2024-09-27 18:49:22', '2024-09-27 18:49:22', '', 75, 'http://localhost/crossthreads/site/?post_type=acf-field&p=79', 3, 'acf-field', '', 0),
(80, 1, '2024-09-27 18:49:22', '2024-09-27 18:49:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Buy Link', 'slider_buy_link', 'publish', 'closed', 'closed', '', 'field_66f6fdf12dbb4', '', '', '2024-09-27 18:49:22', '2024-09-27 18:49:22', '', 75, 'http://localhost/crossthreads/site/?post_type=acf-field&p=80', 4, 'acf-field', '', 0),
(81, 1, '2024-09-27 18:57:01', '2024-09-27 18:57:01', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2024-09-30 09:41:25', '2024-09-30 09:41:25', '', 0, 'http://localhost/crossthreads/site/?page_id=81', 0, 'page', '', 0),
(82, 1, '2024-09-27 18:57:01', '2024-09-27 18:57:01', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-27 18:57:01', '2024-09-27 18:57:01', '', 81, 'http://localhost/crossthreads/site/?p=82', 0, 'revision', '', 0),
(83, 1, '2024-09-27 19:51:03', '2024-09-27 19:51:03', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2024-09-27 19:51:03', '2024-09-27 19:51:03', '', 5, 'http://localhost/crossthreads/site/?p=83', 0, 'revision', '', 0),
(84, 1, '2024-09-29 05:23:28', '2024-09-29 05:23:28', '', 'icon-one', '', 'inherit', 'open', 'closed', '', 'icon-one', '', '', '2024-09-29 05:23:28', '2024-09-29 05:23:28', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/icon-one.svg', 0, 'attachment', 'image/svg+xml', 0),
(85, 1, '2024-09-29 05:24:03', '2024-09-29 05:24:03', '', 'icon-four', '', 'inherit', 'open', 'closed', '', 'icon-four', '', '', '2024-09-29 05:24:03', '2024-09-29 05:24:03', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/icon-four.svg', 0, 'attachment', 'image/svg+xml', 0),
(86, 1, '2024-09-29 05:24:08', '2024-09-29 05:24:08', '', 'icon-three', '', 'inherit', 'open', 'closed', '', 'icon-three', '', '', '2024-09-29 05:24:08', '2024-09-29 05:24:08', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/icon-three.svg', 0, 'attachment', 'image/svg+xml', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(87, 1, '2024-09-29 05:24:10', '2024-09-29 05:24:10', '', 'icon-two', '', 'inherit', 'open', 'closed', '', 'icon-two', '', '', '2024-09-29 05:24:10', '2024-09-29 05:24:10', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/icon-two.svg', 0, 'attachment', 'image/svg+xml', 0),
(88, 1, '2024-09-29 05:26:49', '2024-09-29 05:26:49', '', 'banner-two', '', 'inherit', 'open', 'closed', '', 'banner-two', '', '', '2024-09-29 05:26:49', '2024-09-29 05:26:49', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-two.jpg', 0, 'attachment', 'image/jpeg', 0),
(89, 1, '2024-09-29 05:28:17', '2024-09-29 05:28:17', '', 'img-eight', '', 'inherit', 'open', 'closed', '', 'img-eight', '', '', '2024-09-29 05:28:17', '2024-09-29 05:28:17', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/img-eight.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2024-09-29 05:28:19', '2024-09-29 05:28:19', '', 'img-seven', '', 'inherit', 'open', 'closed', '', 'img-seven', '', '', '2024-09-29 05:28:19', '2024-09-29 05:28:19', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/img-seven.jpg', 0, 'attachment', 'image/jpeg', 0),
(91, 1, '2024-09-29 05:29:13', '2024-09-29 05:29:13', '', 'img-nine', '', 'inherit', 'open', 'closed', '', 'img-nine', '', '', '2024-09-29 05:29:13', '2024-09-29 05:29:13', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/img-nine.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2024-09-29 05:30:31', '2024-09-29 05:30:31', '', 'discount-img', '', 'inherit', 'open', 'closed', '', 'discount-img', '', '', '2024-09-29 05:30:31', '2024-09-29 05:30:31', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/discount-img.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 1, '2024-09-29 05:30:44', '2024-09-29 05:30:44', '', 'img-eleven', '', 'inherit', 'open', 'closed', '', 'img-eleven', '', '', '2024-09-29 05:30:44', '2024-09-29 05:30:44', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/img-eleven.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2024-09-29 05:32:12', '2024-09-29 05:32:12', '', 'profile-pic', '', 'inherit', 'open', 'closed', '', 'profile-pic', '', '', '2024-09-29 05:32:12', '2024-09-29 05:32:12', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/profile-pic.jpg', 0, 'attachment', 'image/jpeg', 0),
(95, 1, '2024-09-29 05:32:23', '2024-09-29 05:32:23', '', 'star', '', 'inherit', 'open', 'closed', '', 'star', '', '', '2024-09-29 05:32:23', '2024-09-29 05:32:23', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/star.png', 0, 'attachment', 'image/png', 0),
(96, 1, '2024-09-29 05:33:58', '2024-09-29 05:33:58', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2024-09-29 05:33:58', '2024-09-29 05:33:58', '', 5, 'http://localhost/crossthreads/site/?p=96', 0, 'revision', '', 0),
(97, 1, '2024-09-29 05:35:08', '2024-09-29 05:35:08', '', 'banner-inner-one', '', 'inherit', 'open', 'closed', '', 'banner-inner-one', '', '', '2024-09-29 05:35:08', '2024-09-29 05:35:08', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-inner-one.jpg', 0, 'attachment', 'image/jpeg', 0),
(98, 1, '2024-09-29 05:35:34', '2024-09-29 05:35:34', '', 'banner-thre', '', 'inherit', 'open', 'closed', '', 'banner-thre', '', '', '2024-09-29 05:35:34', '2024-09-29 05:35:34', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-thre.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2024-09-29 05:36:50', '2024-09-29 05:36:50', '', 'banner-four', '', 'inherit', 'open', 'closed', '', 'banner-four', '', '', '2024-09-29 05:36:50', '2024-09-29 05:36:50', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-four.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2024-09-29 05:37:21', '2024-09-29 05:37:21', '', 'banner-five', '', 'inherit', 'open', 'closed', '', 'banner-five', '', '', '2024-09-29 05:37:21', '2024-09-29 05:37:21', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-five.jpg', 0, 'attachment', 'image/jpeg', 0),
(101, 1, '2024-09-29 05:37:43', '2024-09-29 05:37:43', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2024-09-29 05:37:43', '2024-09-29 05:37:43', '', 5, 'http://localhost/crossthreads/site/?p=101', 0, 'revision', '', 0),
(102, 1, '2024-09-29 05:40:51', '2024-09-29 05:40:51', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2024-09-29 05:40:51', '2024-09-29 05:40:51', '', 5, 'http://localhost/crossthreads/site/?p=102', 0, 'revision', '', 0),
(104, 1, '2024-09-29 08:12:12', '2024-09-29 08:12:12', '', 'img-one', '', 'inherit', 'open', 'closed', '', 'img-one', '', '', '2024-09-29 08:12:12', '2024-09-29 08:12:12', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/img-one.webp', 0, 'attachment', 'image/webp', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(105, 1, '2024-09-29 08:12:46', '2024-09-29 08:12:46', '', 'img-two', '', 'inherit', 'open', 'closed', '', 'img-two', '', '', '2024-09-29 08:12:46', '2024-09-29 08:12:46', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/img-two.webp', 0, 'attachment', 'image/webp', 0),
(106, 1, '2024-09-29 08:12:58', '2024-09-29 08:12:58', '', 'img-three', '', 'inherit', 'open', 'closed', '', 'img-three', '', '', '2024-09-29 08:12:58', '2024-09-29 08:12:58', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/img-three.webp', 0, 'attachment', 'image/webp', 0),
(107, 1, '2024-09-29 08:13:15', '2024-09-29 08:13:15', '', 'img-four', '', 'inherit', 'open', 'closed', '', 'img-four', '', '', '2024-09-29 08:13:15', '2024-09-29 08:13:15', '', 5, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/img-four.webp', 0, 'attachment', 'image/webp', 0),
(108, 1, '2024-09-29 08:13:24', '2024-09-29 08:13:24', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2024-09-29 08:13:24', '2024-09-29 08:13:24', '', 5, 'http://localhost/crossthreads/site/?p=108', 0, 'revision', '', 0),
(109, 1, '2024-09-29 08:24:36', '2024-09-29 08:24:36', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:18:"template-about.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'About Page Settings', 'about-page-settings', 'publish', 'closed', 'closed', '', 'group_66f90eb83c79d', '', '', '2024-09-29 15:39:19', '2024-09-29 15:39:19', '', 0, 'http://localhost/crossthreads/site/?p=109', 0, 'acf-field-group', '', 0),
(110, 1, '2024-09-29 08:24:25', '2024-09-29 08:24:25', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Banner Section', '', 'publish', 'closed', 'closed', '', 'field_66f90eb936064', '', '', '2024-09-29 08:24:25', '2024-09-29 08:24:25', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&p=110', 0, 'acf-field', '', 0),
(111, 1, '2024-09-29 08:24:25', '2024-09-29 08:24:25', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'banner_heading', 'publish', 'closed', 'closed', '', 'field_66f90eb93642d', '', '', '2024-09-29 08:24:25', '2024-09-29 08:24:25', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&p=111', 1, 'acf-field', '', 0),
(112, 1, '2024-09-29 08:24:25', '2024-09-29 08:24:25', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Content', 'banner_content', 'publish', 'closed', 'closed', '', 'field_66f90eb936816', '', '', '2024-09-29 08:24:25', '2024-09-29 08:24:25', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&p=112', 2, 'acf-field', '', 0),
(113, 1, '2024-09-29 08:24:26', '2024-09-29 08:24:26', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Content Section', 'content_section', 'publish', 'closed', 'closed', '', 'field_66f90eb936bfd', '', '', '2024-09-29 15:13:31', '2024-09-29 15:13:31', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=113', 5, 'acf-field', '', 0),
(114, 1, '2024-09-29 08:24:26', '2024-09-29 08:24:26', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Heading', 'ab_title', 'publish', 'closed', 'closed', '', 'field_66f90eb936fe6', '', '', '2024-09-29 15:39:19', '2024-09-29 15:39:19', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=114', 6, 'acf-field', '', 0),
(119, 1, '2024-09-29 08:24:28', '2024-09-29 08:24:28', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Content', 'ab_content', 'publish', 'closed', 'closed', '', 'field_66f90eb9377b7', '', '', '2024-09-29 15:39:19', '2024-09-29 15:39:19', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=119', 7, 'acf-field', '', 0),
(132, 1, '2024-09-29 08:24:30', '2024-09-29 08:24:30', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Image(Left) with Content Section', 'imageleft_with_content_section', 'publish', 'closed', 'closed', '', 'field_66f90eb93a2c4', '', '', '2024-09-29 15:29:10', '2024-09-29 15:29:10', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=132', 8, 'acf-field', '', 0),
(133, 1, '2024-09-29 08:24:30', '2024-09-29 08:24:30', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'season_title', 'publish', 'closed', 'closed', '', 'field_66f90eb93a6be', '', '', '2024-09-29 15:29:10', '2024-09-29 15:29:10', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=133', 10, 'acf-field', '', 0),
(134, 1, '2024-09-29 08:24:30', '2024-09-29 08:24:30', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'mission_image', 'publish', 'closed', 'closed', '', 'field_66f90eb93aa9c', '', '', '2024-09-29 15:29:10', '2024-09-29 15:29:10', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=134', 9, 'acf-field', '', 0),
(135, 1, '2024-09-29 08:24:30', '2024-09-29 08:24:30', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'prod_name', 'publish', 'closed', 'closed', '', 'field_66f90ebedb123', '', '', '2024-09-29 08:24:30', '2024-09-29 08:24:30', '', 134, 'http://localhost/crossthreads/site/?post_type=acf-field&p=135', 0, 'acf-field', '', 0),
(136, 1, '2024-09-29 08:24:31', '2024-09-29 08:24:31', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'prod_image', 'publish', 'closed', 'closed', '', 'field_66f90ebedb50a', '', '', '2024-09-29 08:24:31', '2024-09-29 08:24:31', '', 134, 'http://localhost/crossthreads/site/?post_type=acf-field&p=136', 1, 'acf-field', '', 0),
(137, 1, '2024-09-29 08:24:31', '2024-09-29 08:24:31', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Product Link', 'prod_link', 'publish', 'closed', 'closed', '', 'field_66f90ebedb8f0', '', '', '2024-09-29 08:24:31', '2024-09-29 08:24:31', '', 134, 'http://localhost/crossthreads/site/?post_type=acf-field&p=137', 2, 'acf-field', '', 0),
(138, 1, '2024-09-29 08:24:31', '2024-09-29 08:24:31', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Price', 'prod_price', 'publish', 'closed', 'closed', '', 'field_66f90ebedbcdc', '', '', '2024-09-29 08:24:31', '2024-09-29 08:24:31', '', 134, 'http://localhost/crossthreads/site/?post_type=acf-field&p=138', 3, 'acf-field', '', 0),
(139, 1, '2024-09-29 08:24:31', '2024-09-29 08:24:31', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Link', 'prod_button_link', 'publish', 'closed', 'closed', '', 'field_66f90ebedc0c7', '', '', '2024-09-29 08:24:31', '2024-09-29 08:24:31', '', 134, 'http://localhost/crossthreads/site/?post_type=acf-field&p=139', 4, 'acf-field', '', 0),
(140, 1, '2024-09-29 08:24:31', '2024-09-29 08:24:31', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Content', 'ab_left_content', 'publish', 'closed', 'closed', '', 'field_66f90eb93ae88', '', '', '2024-09-29 15:29:10', '2024-09-29 15:29:10', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=140', 11, 'acf-field', '', 0),
(142, 1, '2024-09-29 08:24:32', '2024-09-29 08:24:32', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Sustainabilty Section', 'sustainabilty_section', 'publish', 'closed', 'closed', '', 'field_66f90eb93b643', '', '', '2024-09-29 15:29:10', '2024-09-29 15:29:10', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=142', 12, 'acf-field', '', 0),
(143, 1, '2024-09-29 08:24:32', '2024-09-29 08:24:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'sust_heading', 'publish', 'closed', 'closed', '', 'field_66f90eb93ba2a', '', '', '2024-09-29 15:31:38', '2024-09-29 15:31:38', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=143', 13, 'acf-field', '', 0),
(144, 1, '2024-09-29 08:24:32', '2024-09-29 08:24:32', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'disc_prod_image', 'publish', 'closed', 'closed', '', 'field_66f90ec081c55', '', '', '2024-09-29 08:24:32', '2024-09-29 08:24:32', '', 143, 'http://localhost/crossthreads/site/?post_type=acf-field&p=144', 0, 'acf-field', '', 0),
(145, 1, '2024-09-29 08:24:32', '2024-09-29 08:24:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Percentage', 'disc_percentage', 'publish', 'closed', 'closed', '', 'field_66f90ec082035', '', '', '2024-09-29 08:24:32', '2024-09-29 08:24:32', '', 143, 'http://localhost/crossthreads/site/?post_type=acf-field&p=145', 1, 'acf-field', '', 0),
(146, 1, '2024-09-29 08:24:32', '2024-09-29 08:24:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'disc_prod_name', 'publish', 'closed', 'closed', '', 'field_66f90ec082426', '', '', '2024-09-29 08:24:32', '2024-09-29 08:24:32', '', 143, 'http://localhost/crossthreads/site/?post_type=acf-field&p=146', 2, 'acf-field', '', 0),
(147, 1, '2024-09-29 08:24:32', '2024-09-29 08:24:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Price', 'disc_prod_price', 'publish', 'closed', 'closed', '', 'field_66f90ec082876', '', '', '2024-09-29 08:24:32', '2024-09-29 08:24:32', '', 143, 'http://localhost/crossthreads/site/?post_type=acf-field&p=147', 3, 'acf-field', '', 0),
(148, 1, '2024-09-29 08:24:33', '2024-09-29 08:24:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Link', 'prod_button_link', 'publish', 'closed', 'closed', '', 'field_66f90ec082c5f', '', '', '2024-09-29 08:24:33', '2024-09-29 08:24:33', '', 143, 'http://localhost/crossthreads/site/?post_type=acf-field&p=148', 4, 'acf-field', '', 0),
(163, 1, '2024-09-29 08:25:03', '2024-09-29 08:25:03', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:27:"template-sustainability.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Sustainability Page Settings', 'sustainability-page-settings', 'publish', 'closed', 'closed', '', 'group_66f90ed16a123', '', '', '2024-09-30 11:01:38', '2024-09-30 11:01:38', '', 0, 'http://localhost/crossthreads/site/?p=163', 0, 'acf-field-group', '', 0),
(164, 1, '2024-09-29 08:24:50', '2024-09-29 08:24:50', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Banner Section', '', 'publish', 'closed', 'closed', '', 'field_66f90ed23aca2', '', '', '2024-09-29 08:24:50', '2024-09-29 08:24:50', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=164', 0, 'acf-field', '', 0),
(165, 1, '2024-09-29 08:24:50', '2024-09-29 08:24:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'banner_heading', 'publish', 'closed', 'closed', '', 'field_66f90ed23b08f', '', '', '2024-09-29 08:24:50', '2024-09-29 08:24:50', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=165', 1, 'acf-field', '', 0),
(166, 1, '2024-09-29 08:24:50', '2024-09-29 08:24:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Content', 'banner_content', 'publish', 'closed', 'closed', '', 'field_66f90ed23b477', '', '', '2024-09-29 08:24:50', '2024-09-29 08:24:50', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=166', 2, 'acf-field', '', 0),
(167, 1, '2024-09-29 08:24:51', '2024-09-29 08:24:51', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Sustainability Section', 'sustainability_section', 'publish', 'closed', 'closed', '', 'field_66f90ed23b85c', '', '', '2024-09-30 09:56:20', '2024-09-30 09:56:20', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=167', 5, 'acf-field', '', 0),
(168, 1, '2024-09-29 08:24:51', '2024-09-29 08:24:51', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'sust_title', 'publish', 'closed', 'closed', '', 'field_66f90ed23bc44', '', '', '2024-09-30 09:56:20', '2024-09-30 09:56:20', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=168', 6, 'acf-field', '', 0),
(169, 1, '2024-09-29 08:24:51', '2024-09-29 08:24:51', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Image and Contennt', 'sust_imagecontent', 'publish', 'closed', 'closed', '', 'field_66f90ed23c054', '', '', '2024-09-30 09:56:20', '2024-09-30 09:56:20', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=169', 7, 'acf-field', '', 0),
(170, 1, '2024-09-29 08:24:51', '2024-09-29 08:24:51', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'sust_name', 'publish', 'closed', 'closed', '', 'field_66f90ed37a940', '', '', '2024-09-30 09:56:20', '2024-09-30 09:56:20', '', 169, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=170', 1, 'acf-field', '', 0),
(171, 1, '2024-09-29 08:24:51', '2024-09-29 08:24:51', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'sust_image', 'publish', 'closed', 'closed', '', 'field_66f90ed37ae47', '', '', '2024-09-30 09:56:20', '2024-09-30 09:56:20', '', 169, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=171', 0, 'acf-field', '', 0),
(172, 1, '2024-09-29 08:24:51', '2024-09-29 08:24:51', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'sust_content', 'publish', 'closed', 'closed', '', 'field_66f90ed37b134', '', '', '2024-09-30 09:56:20', '2024-09-30 09:56:20', '', 169, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=172', 2, 'acf-field', '', 0),
(175, 1, '2024-09-29 08:24:53', '2024-09-29 08:24:53', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Video section', 'video_section', 'publish', 'closed', 'closed', '', 'field_66f90ed23cc71', '', '', '2024-09-30 10:00:09', '2024-09-30 10:00:09', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=175', 8, 'acf-field', '', 0),
(176, 1, '2024-09-29 08:24:53', '2024-09-29 08:24:53', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'video_title', 'publish', 'closed', 'closed', '', 'field_66f90ed23cfd1', '', '', '2024-09-30 10:00:10', '2024-09-30 10:00:10', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=176', 9, 'acf-field', '', 0),
(177, 1, '2024-09-29 08:24:53', '2024-09-29 08:24:53', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'video_image', 'publish', 'closed', 'closed', '', 'field_66f90ed23d3b1', '', '', '2024-09-30 10:00:10', '2024-09-30 10:00:10', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=177', 10, 'acf-field', '', 0),
(178, 1, '2024-09-29 08:24:53', '2024-09-29 08:24:53', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Icon Image', 'icon_image', 'publish', 'closed', 'closed', '', 'field_66f90ed5a28ca', '', '', '2024-09-29 08:24:53', '2024-09-29 08:24:53', '', 177, 'http://localhost/crossthreads/site/?post_type=acf-field&p=178', 0, 'acf-field', '', 0),
(179, 1, '2024-09-29 08:24:53', '2024-09-29 08:24:53', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Content', 'icon_name', 'publish', 'closed', 'closed', '', 'field_66f90ed5a2cb0', '', '', '2024-09-29 08:24:53', '2024-09-29 08:24:53', '', 177, 'http://localhost/crossthreads/site/?post_type=acf-field&p=179', 1, 'acf-field', '', 0),
(180, 1, '2024-09-29 08:24:53', '2024-09-29 08:24:53', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Bottom Banner Section', 'bottom_banner_section', 'publish', 'closed', 'closed', '', 'field_66f90ed23d79d', '', '', '2024-09-30 10:44:53', '2024-09-30 10:44:53', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=180', 13, 'acf-field', '', 0),
(181, 1, '2024-09-29 08:24:54', '2024-09-29 08:24:54', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Background Image', 'bt_background_image', 'publish', 'closed', 'closed', '', 'field_66f90ed23db88', '', '', '2024-09-30 10:44:53', '2024-09-30 10:44:53', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=181', 14, 'acf-field', '', 0),
(182, 1, '2024-09-29 08:24:54', '2024-09-29 08:24:54', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'bt_heading', 'publish', 'closed', 'closed', '', 'field_66f90ed23df6c', '', '', '2024-09-30 10:44:53', '2024-09-30 10:44:53', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=182', 15, 'acf-field', '', 0),
(183, 1, '2024-09-29 08:24:54', '2024-09-29 08:24:54', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'bt_content', 'publish', 'closed', 'closed', '', 'field_66f90ed23e3ad', '', '', '2024-09-30 10:44:53', '2024-09-30 10:44:53', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=183', 16, 'acf-field', '', 0),
(184, 1, '2024-09-29 08:24:55', '2024-09-29 08:24:55', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'bt_button_text', 'publish', 'closed', 'closed', '', 'field_66f90ed23e73d', '', '', '2024-09-30 10:44:53', '2024-09-30 10:44:53', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=184', 17, 'acf-field', '', 0),
(185, 1, '2024-09-29 08:24:55', '2024-09-29 08:24:55', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Button Link', 'bt_button_link', 'publish', 'closed', 'closed', '', 'field_66f90ed23eb26', '', '', '2024-09-30 10:44:54', '2024-09-30 10:44:54', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=185', 18, 'acf-field', '', 0),
(217, 1, '2024-09-29 08:26:20', '2024-09-29 08:26:20', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-29 08:26:20', '2024-09-29 08:26:20', '', 81, 'http://localhost/crossthreads/site/?p=217', 0, 'revision', '', 0),
(218, 1, '2024-09-29 08:31:18', '2024-09-29 08:31:18', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'b_button_text', 'publish', 'closed', 'closed', '', 'field_66f9101fc3f27', '', '', '2024-09-29 08:31:18', '2024-09-29 08:31:18', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&p=218', 3, 'acf-field', '', 0),
(219, 1, '2024-09-29 08:31:19', '2024-09-29 08:31:19', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Link', 'b_button_link', 'publish', 'closed', 'closed', '', 'field_66f91024c3f28', '', '', '2024-09-29 08:31:19', '2024-09-29 08:31:19', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&p=219', 4, 'acf-field', '', 0),
(220, 1, '2024-09-29 12:53:25', '2024-09-29 12:53:25', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-29 12:53:25', '2024-09-29 12:53:25', '', 81, 'http://localhost/crossthreads/site/?p=220', 0, 'revision', '', 0),
(221, 1, '2024-09-29 15:13:32', '2024-09-29 15:13:32', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Content', 'sust_content', 'publish', 'closed', 'closed', '', 'field_66f96daf0462b', '', '', '2024-09-29 15:29:11', '2024-09-29 15:29:11', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=221', 14, 'acf-field', '', 0),
(222, 1, '2024-09-29 15:13:32', '2024-09-29 15:13:32', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'sust_image', 'publish', 'closed', 'closed', '', 'field_66f96e4104631', '', '', '2024-09-29 15:29:11', '2024-09-29 15:29:11', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=222', 15, 'acf-field', '', 0),
(223, 1, '2024-09-29 15:23:52', '2024-09-29 15:23:52', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Image(Right) with Content Section', '_copy', 'publish', 'closed', 'closed', '', 'field_66f96f41e5373', '', '', '2024-09-29 15:29:11', '2024-09-29 15:29:11', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=223', 16, 'acf-field', '', 0),
(224, 1, '2024-09-29 15:23:52', '2024-09-29 15:23:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'img_title', 'publish', 'closed', 'closed', '', 'field_66f96f68e5375', '', '', '2024-09-29 15:29:11', '2024-09-29 15:29:11', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=224', 17, 'acf-field', '', 0),
(225, 1, '2024-09-29 15:23:52', '2024-09-29 15:23:52', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Content', 'ab_right_content', 'publish', 'closed', 'closed', '', 'field_66f96f6de5376', '', '', '2024-09-29 15:29:11', '2024-09-29 15:29:11', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=225', 18, 'acf-field', '', 0),
(226, 1, '2024-09-29 15:23:52', '2024-09-29 15:23:52', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'ab_image_right', 'publish', 'closed', 'closed', '', 'field_66f96f64e5374', '', '', '2024-09-29 15:29:11', '2024-09-29 15:29:11', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=226', 19, 'acf-field', '', 0),
(227, 1, '2024-09-29 15:23:53', '2024-09-29 15:23:53', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Signature Section', 'signature_section', 'publish', 'closed', 'closed', '', 'field_66f9705de5377', '', '', '2024-09-29 15:29:11', '2024-09-29 15:29:11', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=227', 20, 'acf-field', '', 0),
(228, 1, '2024-09-29 15:23:53', '2024-09-29 15:23:53', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'sign_title', 'publish', 'closed', 'closed', '', 'field_66f970b4e5378', '', '', '2024-09-29 15:29:12', '2024-09-29 15:29:12', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=228', 21, 'acf-field', '', 0),
(229, 1, '2024-09-29 15:23:53', '2024-09-29 15:23:53', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:4:"text";s:12:"media_upload";i:0;s:7:"toolbar";s:4:"full";s:5:"delay";i:0;}', 'Content', 'sign_content', 'publish', 'closed', 'closed', '', 'field_66f970cce5379', '', '', '2024-09-29 15:29:12', '2024-09-29 15:29:12', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=229', 22, 'acf-field', '', 0),
(230, 1, '2024-09-29 15:23:53', '2024-09-29 15:23:53', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'sign_image', 'publish', 'closed', 'closed', '', 'field_66f970f3e537a', '', '', '2024-09-29 15:36:14', '2024-09-29 15:36:14', '', 109, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=230', 23, 'acf-field', '', 0),
(231, 1, '2024-09-29 15:26:32', '2024-09-29 15:26:32', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-29 15:26:32', '2024-09-29 15:26:32', '', 81, 'http://localhost/crossthreads/site/?p=231', 0, 'revision', '', 0),
(232, 1, '2024-09-29 15:29:52', '2024-09-29 15:29:52', '', 'left-img', '', 'inherit', 'open', 'closed', '', 'left-img', '', '', '2024-09-29 15:29:52', '2024-09-29 15:29:52', '', 81, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/left-img.jpg', 0, 'attachment', 'image/jpeg', 0),
(233, 1, '2024-09-29 15:30:09', '2024-09-29 15:30:09', '', 'quality', '', 'inherit', 'open', 'closed', '', 'quality', '', '', '2024-09-29 15:30:09', '2024-09-29 15:30:09', '', 81, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/quality.png', 0, 'attachment', 'image/png', 0),
(234, 1, '2024-09-29 15:31:39', '2024-09-29 15:31:39', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-29 15:31:39', '2024-09-29 15:31:39', '', 81, 'http://localhost/crossthreads/site/?p=234', 0, 'revision', '', 0),
(236, 1, '2024-09-29 15:35:59', '2024-09-29 15:35:59', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-29 15:35:59', '2024-09-29 15:35:59', '', 81, 'http://localhost/crossthreads/site/?p=236', 0, 'revision', '', 0),
(237, 1, '2024-09-29 15:36:42', '2024-09-29 15:36:42', '', 'signature', '', 'inherit', 'open', 'closed', '', 'signature', '', '', '2024-09-29 15:36:42', '2024-09-29 15:36:42', '', 81, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/signature.png', 0, 'attachment', 'image/png', 0),
(238, 1, '2024-09-29 15:36:51', '2024-09-29 15:36:51', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-29 15:36:51', '2024-09-29 15:36:51', '', 81, 'http://localhost/crossthreads/site/?p=238', 0, 'revision', '', 0),
(239, 1, '2024-09-29 15:40:12', '2024-09-29 15:40:12', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-29 15:40:12', '2024-09-29 15:40:12', '', 81, 'http://localhost/crossthreads/site/?p=239', 0, 'revision', '', 0),
(240, 1, '2024-09-30 09:15:02', '2024-09-30 09:15:02', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-09-30 09:15:02', '2024-09-30 09:15:02', '', 1, 'http://localhost/crossthreads/site/?p=240', 0, 'revision', '', 0),
(241, 1, '2024-09-30 09:41:25', '2024-09-30 09:41:25', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-09-30 09:41:25', '2024-09-30 09:41:25', '', 81, 'http://localhost/crossthreads/site/?p=241', 0, 'revision', '', 0),
(242, 1, '2024-09-30 09:46:27', '2024-09-30 09:46:27', '', 'Sustainability', '', 'publish', 'closed', 'closed', '', 'sustainability', '', '', '2024-09-30 11:08:35', '2024-09-30 11:08:35', '', 0, 'http://localhost/crossthreads/site/?page_id=242', 0, 'page', '', 0),
(243, 1, '2024-09-30 09:46:07', '2024-09-30 09:46:07', '', 'fashion-banner', '', 'inherit', 'open', 'closed', '', 'fashion-banner', '', '', '2024-09-30 09:46:07', '2024-09-30 09:46:07', '', 242, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/fashion-banner.jpg', 0, 'attachment', 'image/jpeg', 0),
(244, 1, '2024-09-30 09:46:27', '2024-09-30 09:46:27', '', 'Sustainability', '', 'inherit', 'closed', 'closed', '', '242-revision-v1', '', '', '2024-09-30 09:46:27', '2024-09-30 09:46:27', '', 242, 'http://localhost/crossthreads/site/?p=244', 0, 'revision', '', 0),
(245, 1, '2024-09-30 09:50:35', '2024-09-30 09:50:35', '', 'Sustainability', '', 'inherit', 'closed', 'closed', '', '242-revision-v1', '', '', '2024-09-30 09:50:35', '2024-09-30 09:50:35', '', 242, 'http://localhost/crossthreads/site/?p=245', 0, 'revision', '', 0),
(246, 1, '2024-09-30 09:56:19', '2024-09-30 09:56:19', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Content Section', 'sust_content_copy', 'publish', 'closed', 'closed', '', 'field_66fa750b5288b', '', '', '2024-09-30 09:56:19', '2024-09-30 09:56:19', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=246', 3, 'acf-field', '', 0),
(247, 1, '2024-09-30 09:56:20', '2024-09-30 09:56:20', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'sust_content', 'publish', 'closed', 'closed', '', 'field_66fa74c25288a', '', '', '2024-09-30 09:56:20', '2024-09-30 09:56:20', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=247', 4, 'acf-field', '', 0),
(248, 1, '2024-09-30 10:03:46', '2024-09-30 10:03:46', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'video_content', 'publish', 'closed', 'closed', '', 'field_66fa7755f843e', '', '', '2024-09-30 10:04:38', '2024-09-30 10:04:38', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=248', 11, 'acf-field', '', 0),
(249, 1, '2024-09-30 10:44:53', '2024-09-30 10:44:53', 'a:10:{s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:3:"mp4";}', 'Video', 'video_src', 'publish', 'closed', 'closed', '', 'field_66fa80e2efeee', '', '', '2024-09-30 10:44:53', '2024-09-30 10:44:53', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=249', 12, 'acf-field', '', 0),
(250, 1, '2024-09-30 11:01:37', '2024-09-30 11:01:37', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Signature Section', 'signature_section', 'publish', 'closed', 'closed', '', 'field_66fa84ba39721', '', '', '2024-09-30 11:01:37', '2024-09-30 11:01:37', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=250', 19, 'acf-field', '', 0),
(251, 1, '2024-09-30 11:01:38', '2024-09-30 11:01:38', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'signature_content', 'publish', 'closed', 'closed', '', 'field_66fa84cf39722', '', '', '2024-09-30 11:01:38', '2024-09-30 11:01:38', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=251', 20, 'acf-field', '', 0),
(252, 1, '2024-09-30 11:01:38', '2024-09-30 11:01:38', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Sign', 'upload_sign', 'publish', 'closed', 'closed', '', 'field_66fa84f839723', '', '', '2024-09-30 11:01:38', '2024-09-30 11:01:38', '', 163, 'http://localhost/crossthreads/site/?post_type=acf-field&p=252', 21, 'acf-field', '', 0),
(253, 1, '2024-09-30 11:04:10', '2024-09-30 11:04:10', '', 'earth', '', 'inherit', 'open', 'closed', '', 'earth', '', '', '2024-09-30 11:04:10', '2024-09-30 11:04:10', '', 242, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/earth.jpg', 0, 'attachment', 'image/jpeg', 0),
(254, 1, '2024-09-30 11:04:13', '2024-09-30 11:04:13', '', 'people', '', 'inherit', 'open', 'closed', '', 'people', '', '', '2024-09-30 11:04:13', '2024-09-30 11:04:13', '', 242, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/people.jpg', 0, 'attachment', 'image/jpeg', 0),
(255, 1, '2024-09-30 11:05:37', '2024-09-30 11:05:37', '', 'video-banner', '', 'inherit', 'open', 'closed', '', 'video-banner', '', '', '2024-09-30 11:05:37', '2024-09-30 11:05:37', '', 242, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/video-banner.jpg', 0, 'attachment', 'image/jpeg', 0),
(256, 1, '2024-09-30 11:06:32', '2024-09-30 11:06:32', '', 'purpose-banner', '', 'inherit', 'open', 'closed', '', 'purpose-banner', '', '', '2024-09-30 11:06:32', '2024-09-30 11:06:32', '', 242, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/purpose-banner.jpg', 0, 'attachment', 'image/jpeg', 0),
(257, 1, '2024-09-30 11:08:35', '2024-09-30 11:08:35', '', 'Sustainability', '', 'inherit', 'closed', 'closed', '', '242-revision-v1', '', '', '2024-09-30 11:08:35', '2024-09-30 11:08:35', '', 242, 'http://localhost/crossthreads/site/?p=257', 0, 'revision', '', 0),
(258, 1, '2024-09-30 11:10:00', '2024-09-30 11:10:00', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2024-09-30 11:10:31', '2024-09-30 11:10:31', '', 0, 'http://localhost/crossthreads/site/about-us-copy/', 0, 'page', '', 0),
(259, 1, '2024-09-30 11:10:31', '2024-09-30 11:10:31', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '258-revision-v1', '', '', '2024-09-30 11:10:31', '2024-09-30 11:10:31', '', 258, 'http://localhost/crossthreads/site/?p=259', 0, 'revision', '', 0),
(260, 1, '2024-09-30 11:11:35', '2024-09-30 11:11:35', ' ', '', '', 'publish', 'closed', 'closed', '', '260', '', '', '2024-09-30 11:11:35', '2024-09-30 11:11:35', '', 0, 'http://localhost/crossthreads/site/?p=260', 1, 'nav_menu_item', '', 0),
(261, 1, '2024-09-30 11:11:35', '2024-09-30 11:11:35', ' ', '', '', 'publish', 'closed', 'closed', '', '261', '', '', '2024-09-30 11:11:35', '2024-09-30 11:11:35', '', 0, 'http://localhost/crossthreads/site/?p=261', 2, 'nav_menu_item', '', 0),
(262, 1, '2024-09-30 11:11:37', '2024-09-30 11:11:37', ' ', '', '', 'publish', 'closed', 'closed', '', '262', '', '', '2024-09-30 11:11:37', '2024-09-30 11:11:37', '', 0, 'http://localhost/crossthreads/site/?p=262', 4, 'nav_menu_item', '', 0),
(263, 1, '2024-09-30 11:11:36', '2024-09-30 11:11:36', ' ', '', '', 'publish', 'closed', 'closed', '', '263', '', '', '2024-09-30 11:11:36', '2024-09-30 11:11:36', '', 0, 'http://localhost/crossthreads/site/?p=263', 3, 'nav_menu_item', '', 0),
(264, 1, '2024-09-30 11:15:21', '2024-09-30 11:15:21', '', 'home1', '', 'publish', 'closed', 'closed', '', 'sustainability-copy', '', '', '2024-09-30 11:15:53', '2024-09-30 11:15:53', '', 0, 'http://localhost/crossthreads/site/sustainability-copy/', 0, 'page', '', 0),
(265, 1, '2024-09-30 11:15:53', '2024-09-30 11:15:53', '', 'home1', '', 'inherit', 'closed', 'closed', '', '264-revision-v1', '', '', '2024-09-30 11:15:53', '2024-09-30 11:15:53', '', 264, 'http://localhost/crossthreads/site/?p=265', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(266, 1, '2024-10-01 06:55:20', '2024-10-01 06:55:20', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.</p>\r\n<ol>\r\n    <li>\r\n        1.General\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\r\n        </li>\r\n        <li>\r\n            1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\r\n        </li>\r\n        <li>\r\n            1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        2. Product Information and Availability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n        </li>\r\n        <li>\r\n            2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        3.Orders and Payment\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n        </li>\r\n        <li>\r\n            3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n        </li>\r\n        <li>\r\n            3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        4.Shipping and Delivery\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n        </li>\r\n        <li>\r\n            4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n        </li>\r\n        <li>\r\n            4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        5.Returns and Exchanges\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n        </li>\r\n        <li>\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.</li>\r\n        <li>5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        6.Intellectual Property\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n        </li>\r\n        <li>\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n        </li>\r\n        <li>\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        7.Limitation of Liability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n        </li>\r\n    </ol>\r\n</ol>', 'Terms and Conditions', '', 'publish', 'closed', 'closed', '', 'terms-and-conditions', '', '', '2024-10-01 07:25:03', '2024-10-01 07:25:03', '', 0, 'http://localhost/crossthreads/site/?page_id=266', 0, 'page', '', 0),
(267, 1, '2024-10-01 06:55:20', '2024-10-01 06:55:20', '', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 06:55:20', '2024-10-01 06:55:20', '', 266, 'http://localhost/crossthreads/site/?p=267', 0, 'revision', '', 0),
(268, 1, '2024-10-01 06:57:19', '2024-10-01 06:57:19', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.</p>\r\n                    <ol>\r\n                        <li>\r\n                            1.General\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\r\n\r\n                            </li>\r\n                            <li>\r\n                                1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\r\n\r\n                            </li>\r\n                            <li>\r\n\r\n                                1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\r\n\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                           2. Product Information and Availability\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n\r\n                            </li>\r\n                            <li>\r\n                                2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n                            </li>\r\n\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                            3.Orders and Payment\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n\r\n                            </li>\r\n                            <li>\r\n                                3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n                            </li>\r\n                            <li>\r\n\r\n                                3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                            4.Shipping and Delivery\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n\r\n                            </li>\r\n                            <li>\r\n                                4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n\r\n                            </li>\r\n                            <li>\r\n\r\n                                4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                           5.Returns and Exchanges\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                               5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n                            </li>\r\n                            <li>\r\n                               \r\n5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n                            </li>\r\n                            <li>\r\n\r\n                              \r\n5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                       <ol>\r\n                        <li>\r\n                           6.Intellectual Property\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                               5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n                            </li>\r\n                            <li>\r\n                               \r\n5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n                            </li>\r\n                            <li>\r\n\r\n                              \r\n5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                      <ol>\r\n                        <li>\r\n                           7.Limitation of Liability\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                              7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <!--banner-section-end-->\r\n\r\n\r\n', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 06:57:19', '2024-10-01 06:57:19', '', 266, 'http://localhost/crossthreads/site/?p=268', 0, 'revision', '', 0),
(269, 1, '2024-10-01 06:58:23', '2024-10-01 06:58:23', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.</p>\r\n                    <ol>\r\n                        <li>\r\n                            1.General\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\r\n\r\n                            </li>\r\n                            <li>\r\n                                1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\r\n\r\n                            </li>\r\n                            <li>\r\n\r\n                                1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\r\n\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                           2. Product Information and Availability\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n\r\n                            </li>\r\n                            <li>\r\n                                2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n                            </li>\r\n\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                            3.Orders and Payment\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n\r\n                            </li>\r\n                            <li>\r\n                                3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n                            </li>\r\n                            <li>\r\n\r\n                                3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                            4.Shipping and Delivery\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n\r\n                            </li>\r\n                            <li>\r\n                                4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n\r\n                            </li>\r\n                            <li>\r\n\r\n                                4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                           5.Returns and Exchanges\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                               5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n                            </li>\r\n                            <li>\r\n                               \r\n5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n                            </li>\r\n                            <li>\r\n\r\n                              \r\n5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                       <ol>\r\n                        <li>\r\n                           6.Intellectual Property\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                               5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n                            </li>\r\n                            <li>\r\n                               \r\n5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n                            </li>\r\n                            <li>\r\n\r\n                              \r\n5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                      <ol>\r\n                        <li>\r\n                           7.Limitation of Liability\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                              7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                </div>\r\n            </div>\r\n        </div>\r\n      \r\n\r\n\r\n', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 06:58:23', '2024-10-01 06:58:23', '', 266, 'http://localhost/crossthreads/site/?p=269', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(270, 1, '2024-10-01 07:21:20', '2024-10-01 07:21:20', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.</p>\n<ol>\n    <li>\n        1.General\n    </li>\n    <ol class="sub-list">\n        <li>\n            1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\n        </li>\n        <li>\n            1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\n        </li>\n        <li>\n            1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\n        </li>\n    </ol>\n</ol>\n<ol>\n    <li>\n        2. Product Information and Availability\n    </li>\n    <ol class="sub-list">\n        <li>\n            2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\n        </li>\n        <li>\n            2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\n        </li>\n    </ol>\n</ol>\n<ol>\n    <li>\n        3.Orders and Payment\n    </li>\n    <ol class="sub-list">\n        <li>\n            3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\n        </li>\n        <li>\n            3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\n        </li>\n        <li>\n            3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\n        </li>\n    </ol>\n\n</ol>\n<ol>\n    <li>\n        4.Shipping and Delivery\n    </li>\n    <ol class="sub-list">\n        <li>\n            4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\n\n        </li>\n        <li>\n            4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\n\n        </li>\n        <li>\n\n            4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\n        </li>\n    </ol>\n\n</ol>\n<ol>\n    <li>\n        5.Returns and Exchanges\n    </li>\n    <ol class="sub-list">\n        <li>\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\n            items, such as [mention any non-returnable items, like customized products], are not eligible for return.\n\n        </li>\n        <li>\n\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\n\n        </li>\n        <li>\n\n\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\n        </li>\n    </ol>\n\n</ol>\n<ol>\n    <li>\n        6.Intellectual Property\n    </li>\n    <ol class="sub-list">\n        <li>\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\n            items, such as [mention any non-returnable items, like customized products], are not eligible for return.\n\n        </li>\n        <li>\n\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\n\n        </li>\n        <li>\n\n\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\n        </li>\n    </ol>\n\n</ol>\n<ol>\n    <li>\n        7.Limitation of Liability\n    </li>\n    <ol class="sub-list">\n        <li>\n            7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not\n            limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\n        </li>\n    </ol>\n\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-autosave-v1', '', '', '2024-10-01 07:21:20', '2024-10-01 07:21:20', '', 266, 'http://localhost/crossthreads/site/?p=270', 0, 'revision', '', 0),
(271, 1, '2024-10-01 07:03:08', '2024-10-01 07:03:08', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.</p>\r\n                    <ol>\r\n                        <li>\r\n                            1.General\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\r\n                            </li>\r\n                            <li>\r\n                                1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\r\n                            </li>\r\n                            <li>\r\n                                1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\r\n                            </li>\r\n                        </ol>\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                           2. Product Information and Availability\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n                            </li>\r\n                            <li>\r\n                                2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n                            </li>\r\n                        </ol>\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                            3.Orders and Payment\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n                            </li>\r\n                            <li>\r\n                                3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n                            </li>\r\n                            <li>\r\n                                3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n                            </li>\r\n                        </ol>\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                            4.Shipping and Delivery\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                                4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n                            </li>\r\n                            <li>\r\n                                4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n\r\n                            </li>\r\n                            <li>\r\n                                4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n                            </li>\r\n                        </ol>\r\n\r\n                    </ol>\r\n                    <ol>\r\n                        <li>\r\n                           5.Returns and Exchanges\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                               5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n                            </li>\r\n                            <li>                               \r\n5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n                            </li>\r\n                            <li>                              \r\n5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n                            </li>\r\n                        </ol>\r\n                    </ol>\r\n                       <ol>\r\n                        <li>\r\n                           6.Intellectual Property\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                               5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n                            </li>\r\n                            <li>                               \r\n5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n                            </li>\r\n                            <li>                              \r\n5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n                            </li>\r\n                        </ol>\r\n                    </ol>\r\n                      <ol>\r\n                        <li>\r\n                           7.Limitation of Liability\r\n                        </li>\r\n                        <ol class="sub-list">\r\n                            <li>\r\n                              7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n                            </li>\r\n                        </ol>\r\n                    </ol>\r\n                </div>\r\n            </div>\r\n        </div>\r\n      \r\n\r\n\r\n', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:03:08', '2024-10-01 07:03:08', '', 266, 'http://localhost/crossthreads/site/?p=271', 0, 'revision', '', 0),
(272, 1, '2024-10-01 07:04:43', '2024-10-01 07:04:43', 'Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.\r\n<ol>\r\n 	<li>1.General\r\n<ol class="sub-list">\r\n 	<li>1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.</li>\r\n 	<li>1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.</li>\r\n 	<li>1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>2. Product Information and Availability\r\n<ol class="sub-list">\r\n 	<li>2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.</li>\r\n 	<li>2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>3.Orders and Payment\r\n<ol class="sub-list">\r\n 	<li>3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.</li>\r\n 	<li>3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.</li>\r\n 	<li>3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>4.Shipping and Delivery\r\n<ol class="sub-list">\r\n 	<li>4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.</li>\r\n 	<li>4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.</li>\r\n 	<li>4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>5.Returns and Exchanges\r\n<ol class="sub-list">\r\n 	<li>5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.</li>\r\n 	<li>5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.</li>\r\n 	<li>5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>6.Intellectual Property\r\n<ol class="sub-list">\r\n 	<li>5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.</li>\r\n 	<li>5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.</li>\r\n 	<li>5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>7.Limitation of Liability\r\n<ol class="sub-list">\r\n 	<li>7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.</li>\r\n</ol>\r\n</li>\r\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:04:43', '2024-10-01 07:04:43', '', 266, 'http://localhost/crossthreads/site/?p=272', 0, 'revision', '', 0),
(273, 1, '2024-10-01 07:10:22', '2024-10-01 07:10:22', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any\r\n    part of these terms, you should not use our website.</p>\r\n<ol>\r\n    <li>\r\n        1.General\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\r\n\r\n        </li>\r\n        <li>\r\n            1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\r\n\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        2. Product Information and Availability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct\r\n            any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n\r\n        </li>\r\n        <li>\r\n            2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n        </li>\r\n\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        3.Orders and Payment\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n\r\n        </li>\r\n        <li>\r\n            3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n        </li>\r\n        <li>\r\n\r\n            3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        4.Shipping and Delivery\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n\r\n        </li>\r\n        <li>\r\n            4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        5.Returns and Exchanges\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\n            items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n        </li>\r\n        <li>\r\n\r\n\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        6.Intellectual Property\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\n            items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n        </li>\r\n        <li>\r\n\r\n\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        7.Limitation of Liability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not\r\n            limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:10:22', '2024-10-01 07:10:22', '', 266, 'http://localhost/crossthreads/site/?p=273', 0, 'revision', '', 0),
(274, 1, '2024-10-01 07:17:07', '2024-10-01 07:17:07', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.</p>\r\n<ol>\r\n    <li>1.General</li>\r\n    <ol class="sub-list">\r\n        <li>1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.</li>\r\n        <li>1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.</li>\r\n        <li>1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.</li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        2. Product Information and Availability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct\r\n            any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n\r\n        </li>\r\n        <li>\r\n            2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n        </li>\r\n\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        3.Orders and Payment\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n\r\n        </li>\r\n        <li>\r\n            3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n        </li>\r\n        <li>\r\n\r\n            3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        4.Shipping and Delivery\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n\r\n        </li>\r\n        <li>\r\n            4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        5.Returns and Exchanges\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\n            items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n        </li>\r\n        <li>\r\n\r\n\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        6.Intellectual Property\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\n            items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n        </li>\r\n        <li>\r\n\r\n\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        7.Limitation of Liability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not\r\n            limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:17:07', '2024-10-01 07:17:07', '', 266, 'http://localhost/crossthreads/site/?p=274', 0, 'revision', '', 0),
(275, 1, '2024-10-01 07:17:52', '2024-10-01 07:17:52', 'Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.\r\n<ol>\r\n 	<li>1.General\r\n<ol class="sub-list">\r\n 	<li>1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.</li>\r\n 	<li>1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.</li>\r\n 	<li>1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li style="list-style-type: none;">\r\n<ol>\r\n 	<li>2. Product Information and Availability\r\n<ol class="sub-list">\r\n 	<li>2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct\r\nany errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.</li>\r\n 	<li>2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>3.Orders and Payment\r\n<ol class="sub-list">\r\n 	<li>3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.</li>\r\n 	<li>3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.</li>\r\n 	<li>3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>4.Shipping and Delivery\r\n<ol class="sub-list">\r\n 	<li>4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.</li>\r\n 	<li>4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.</li>\r\n 	<li>4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>5.Returns and Exchanges\r\n<ol class="sub-list">\r\n 	<li>5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\nitems, such as [mention any non-returnable items, like customized products], are not eligible for return.</li>\r\n 	<li>5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.</li>\r\n 	<li>5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>6.Intellectual Property\r\n<ol class="sub-list">\r\n 	<li>5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\nitems, such as [mention any non-returnable items, like customized products], are not eligible for return.</li>\r\n 	<li>5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.</li>\r\n 	<li>5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>7.Limitation of Liability\r\n<ol class="sub-list">\r\n 	<li>7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not\r\nlimited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.</li>\r\n</ol>\r\n</li>\r\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:17:52', '2024-10-01 07:17:52', '', 266, 'http://localhost/crossthreads/site/?p=275', 0, 'revision', '', 0),
(276, 1, '2024-10-01 07:19:19', '2024-10-01 07:19:19', 'Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.\r\n<ol>\r\n 	<li>1.General</li>\r\n<ol class="sub-list">\r\n 	<li>1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.</li>\r\n 	<li>1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.</li>\r\n 	<li>1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li style="list-style-type: none;">\r\n<ol>\r\n 	<li>2. Product Information and Availability\r\n<ol class="sub-list">\r\n 	<li>2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct\r\nany errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.</li>\r\n 	<li>2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>3.Orders and Payment\r\n<ol class="sub-list">\r\n 	<li>3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.</li>\r\n 	<li>3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.</li>\r\n 	<li>3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>4.Shipping and Delivery\r\n<ol class="sub-list">\r\n 	<li>4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.</li>\r\n 	<li>4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.</li>\r\n 	<li>4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>5.Returns and Exchanges\r\n<ol class="sub-list">\r\n 	<li>5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\nitems, such as [mention any non-returnable items, like customized products], are not eligible for return.</li>\r\n 	<li>5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.</li>\r\n 	<li>5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>6.Intellectual Property\r\n<ol class="sub-list">\r\n 	<li>5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\nitems, such as [mention any non-returnable items, like customized products], are not eligible for return.</li>\r\n 	<li>5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.</li>\r\n 	<li>5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<ol>\r\n 	<li>7.Limitation of Liability\r\n<ol class="sub-list">\r\n 	<li>7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not\r\nlimited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.</li>\r\n</ol>\r\n</li>\r\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:19:19', '2024-10-01 07:19:19', '', 266, 'http://localhost/crossthreads/site/?p=276', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(277, 1, '2024-10-01 07:20:12', '2024-10-01 07:20:12', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any\r\n    part of these terms, you should not use our website.</p>\r\n<ol>\r\n    <li>\r\n        1.General\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\r\n\r\n        </li>\r\n        <li>\r\n            1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\r\n\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        2. Product Information and Availability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct\r\n            any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n\r\n        </li>\r\n        <li>\r\n            2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n        </li>\r\n\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        3.Orders and Payment\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n\r\n        </li>\r\n        <li>\r\n            3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n        </li>\r\n        <li>\r\n\r\n            3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        4.Shipping and Delivery\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n\r\n        </li>\r\n        <li>\r\n            4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        5.Returns and Exchanges\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\n            items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n        </li>\r\n        <li>\r\n\r\n\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        6.Intellectual Property\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain\r\n            items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n\r\n        </li>\r\n        <li>\r\n\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n\r\n        </li>\r\n        <li>\r\n\r\n\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>\r\n<ol>\r\n    <li>\r\n        7.Limitation of Liability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not\r\n            limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n        </li>\r\n    </ol>\r\n\r\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:20:12', '2024-10-01 07:20:12', '', 266, 'http://localhost/crossthreads/site/?p=277', 0, 'revision', '', 0),
(278, 1, '2024-10-01 07:23:17', '2024-10-01 07:23:17', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.</p>\r\n<ol>\r\n    <li>\r\n        1.General\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\r\n        </li>\r\n        <li>\r\n            1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\r\n        </li>\r\n        <li>\r\n            1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        2. Product Information and Availability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n        </li>\r\n        <li>\r\n            2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        3.Orders and Payment\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n        </li>\r\n        <li>\r\n            3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n        </li>\r\n        <li>\r\n            3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        4.Shipping and Delivery\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n        </li>\r\n        <li>\r\n            4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n        </li>\r\n        <li>\r\n            4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        5.Returns and Exchanges\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n        </li>\r\n        <li>\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n        </li>\r\n        <li>\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        6.Intellectual Property\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n        </li>\r\n        <li>\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n        </li>\r\n        <li>\r\n\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        7.Limitation of Liability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n        </li>\r\n    </ol>\r\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:23:17', '2024-10-01 07:23:17', '', 266, 'http://localhost/crossthreads/site/?p=278', 0, 'revision', '', 0),
(279, 1, '2024-10-01 07:24:15', '2024-10-01 07:24:15', '<p>Welcome to Crossthreads. These Terms and Conditions outline the rules and regulations for using our website and purchasing our products. By accessing or using our website, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our website.</p>\r\n<ol>\r\n    <li>\r\n        1.General\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            1.1.Eligibility: By using our website, you represent that you are at least 18 years old or have the consent of a parent or guardian to use the website.\r\n        </li>\r\n        <li>\r\n            1.2. Modification of Terms: Crossthreads reserves the right to update or modify these Terms and Conditions at any time without prior notice. Your continued use of the website after any changes will constitute your acceptance of the new terms.\r\n        </li>\r\n        <li>\r\n            1.3. Privacy Policy: Your use of the website is also governed by our Privacy Policy, which is incorporated into these Terms and Conditions by reference.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        2. Product Information and Availability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            2.1. Product Descriptions: We strive to ensure that the product descriptions, images, and pricing on our website are accurate and complete. However, we do not warrant that the information is free from errors. Crossthreads reserves the right to correct any errors, inaccuracies, or omissions, and to change or update information at any time without prior notice.\r\n        </li>\r\n        <li>\r\n            2.2. Availability: All products are subject to availability, and we cannot guarantee that items will be in stock at the time of your order. We reserve the right to limit the quantity of any product we supply, refuse any order, or cancel an order if necessary.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        3.Orders and Payment\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            3.1. Order Acceptance: Once you place an order, you will receive an email confirmation. However, this email does not constitute acceptance of your order. We reserve the right to accept or decline your order at any time for any reason.\r\n        </li>\r\n        <li>\r\n            3.2. Pricing: All prices are listed in [currency] and are subject to change without notice. Prices do not include shipping costs, which will be calculated and added at checkout.\r\n        </li>\r\n        <li>\r\n            3.3. Payment: We accept [list of accepted payment methods]. Payment must be made in full before your order is shipped. By providing your payment information, you authorize us to charge the amount to the payment method you provide.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        4.Shipping and Delivery\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            4.1. Shipping: Shipping costs and delivery times vary depending on your location and the shipping method selected. Crossthreads is not responsible for any delays in shipping caused by third-party carriers.\r\n        </li>\r\n        <li>\r\n            4.2. International Shipping: For orders shipped internationally, you are responsible for paying any import duties, taxes, or customs fees required by your country.\r\n        </li>\r\n        <li>\r\n            4.3. Risk of Loss: All products purchased from Crossthreads are made pursuant to a shipment contract. The risk of loss and title for such products pass to you upon our delivery to the carrier.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        5.Returns and Exchanges\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n        </li>\r\n        <li>\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.</li>\r\n        <li>5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        6.Intellectual Property\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            5.1. Return Policy: If you are not completely satisfied with your purchase, you may return the item(s) within [number of days] days of receipt for a refund or exchange. Items must be in their original condition, unworn, and with all tags attached. Certain items, such as [mention any non-returnable items, like customized products], are not eligible for return.\r\n        </li>\r\n        <li>\r\n            5.2. Return Process: To initiate a return, please contact our customer service team at [contact information] for instructions. You will be responsible for return shipping costs unless the item is defective or we made an error with your order.\r\n        </li>\r\n        <li>\r\n\r\n            5.3. Refunds: Once we receive your returned item(s), we will process your refund within [number of days] days. Refunds will be issued to the original payment method used for the purchase.\r\n        </li>\r\n    </ol>\r\n</ol>\r\n<ol>\r\n    <li>\r\n        7.Limitation of Liability\r\n    </li>\r\n    <ol class="sub-list">\r\n        <li>\r\n            7.1. Disclaimer of Warranties: The website and all content, products, and services provided through the website are provided "as is" without any warranties of any kind, either express or implied. Crossthreads disclaims all warranties, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.\r\n        </li>\r\n    </ol>\r\n</ol>', 'Terms and Conditions', '', 'inherit', 'closed', 'closed', '', '266-revision-v1', '', '', '2024-10-01 07:24:15', '2024-10-01 07:24:15', '', 266, 'http://localhost/crossthreads/site/?p=279', 0, 'revision', '', 0),
(280, 1, '2024-10-01 07:48:31', '2024-10-01 07:48:31', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2024-10-01 07:48:31', '2024-10-01 07:48:31', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(281, 1, '2024-10-01 07:48:35', '2024-10-01 07:48:35', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2024-10-01 07:48:35', '2024-10-01 07:48:35', '', 0, 'http://localhost/crossthreads/site/shop/', 0, 'page', '', 0),
(282, 1, '2024-10-01 07:48:36', '2024-10-01 07:48:36', '<!-- wp:woocommerce/cart -->\n<div class="wp-block-woocommerce-cart alignwide is-loading"><!-- wp:woocommerce/filled-cart-block -->\n<div class="wp-block-woocommerce-filled-cart-block"><!-- wp:woocommerce/cart-items-block -->\n<div class="wp-block-woocommerce-cart-items-block"><!-- wp:woocommerce/cart-line-items-block -->\n<div class="wp-block-woocommerce-cart-line-items-block"></div>\n<!-- /wp:woocommerce/cart-line-items-block -->\n\n<!-- wp:woocommerce/cart-cross-sells-block -->\n<div class="wp-block-woocommerce-cart-cross-sells-block"><!-- wp:heading {"fontSize":"large"} -->\n<h2 class="wp-block-heading has-large-font-size">You may be interested in…</h2>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/cart-cross-sells-products-block -->\n<div class="wp-block-woocommerce-cart-cross-sells-products-block"></div>\n<!-- /wp:woocommerce/cart-cross-sells-products-block --></div>\n<!-- /wp:woocommerce/cart-cross-sells-block --></div>\n<!-- /wp:woocommerce/cart-items-block -->\n\n<!-- wp:woocommerce/cart-totals-block -->\n<div class="wp-block-woocommerce-cart-totals-block"><!-- wp:woocommerce/cart-order-summary-block -->\n<div class="wp-block-woocommerce-cart-order-summary-block"><!-- wp:woocommerce/cart-order-summary-heading-block -->\n<div class="wp-block-woocommerce-cart-order-summary-heading-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-heading-block -->\n\n<!-- wp:woocommerce/cart-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-cart-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/cart-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-cart-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/cart-order-summary-fee-block -->\n<div class="wp-block-woocommerce-cart-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-fee-block -->\n\n<!-- wp:woocommerce/cart-order-summary-discount-block -->\n<div class="wp-block-woocommerce-cart-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-discount-block -->\n\n<!-- wp:woocommerce/cart-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-cart-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/cart-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-cart-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/cart-order-summary-block -->\n\n<!-- wp:woocommerce/cart-express-payment-block -->\n<div class="wp-block-woocommerce-cart-express-payment-block"></div>\n<!-- /wp:woocommerce/cart-express-payment-block -->\n\n<!-- wp:woocommerce/proceed-to-checkout-block -->\n<div class="wp-block-woocommerce-proceed-to-checkout-block"></div>\n<!-- /wp:woocommerce/proceed-to-checkout-block -->\n\n<!-- wp:woocommerce/cart-accepted-payment-methods-block -->\n<div class="wp-block-woocommerce-cart-accepted-payment-methods-block"></div>\n<!-- /wp:woocommerce/cart-accepted-payment-methods-block --></div>\n<!-- /wp:woocommerce/cart-totals-block --></div>\n<!-- /wp:woocommerce/filled-cart-block -->\n\n<!-- wp:woocommerce/empty-cart-block -->\n<div class="wp-block-woocommerce-empty-cart-block"><!-- wp:heading {"textAlign":"center","className":"with-empty-cart-icon wc-block-cart__empty-cart__title"} -->\n<h2 class="wp-block-heading has-text-align-center with-empty-cart-icon wc-block-cart__empty-cart__title">Your cart is currently empty!</h2>\n<!-- /wp:heading -->\n\n<!-- wp:separator {"className":"is-style-dots"} -->\n<hr class="wp-block-separator has-alpha-channel-opacity is-style-dots"/>\n<!-- /wp:separator -->\n\n<!-- wp:heading {"textAlign":"center"} -->\n<h2 class="wp-block-heading has-text-align-center">New in store</h2>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/product-new {"columns":4,"rows":1} /--></div>\n<!-- /wp:woocommerce/empty-cart-block --></div>\n<!-- /wp:woocommerce/cart -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart-2', '', '', '2024-10-01 07:48:36', '2024-10-01 07:48:36', '', 0, 'http://localhost/crossthreads/site/cart-2/', 0, 'page', '', 0),
(283, 1, '2024-10-01 07:48:36', '2024-10-01 07:48:36', '<!-- wp:woocommerce/checkout -->\n<div class="wp-block-woocommerce-checkout alignwide wc-block-checkout is-loading"><!-- wp:woocommerce/checkout-fields-block -->\n<div class="wp-block-woocommerce-checkout-fields-block"><!-- wp:woocommerce/checkout-express-payment-block -->\n<div class="wp-block-woocommerce-checkout-express-payment-block"></div>\n<!-- /wp:woocommerce/checkout-express-payment-block -->\n\n<!-- wp:woocommerce/checkout-contact-information-block -->\n<div class="wp-block-woocommerce-checkout-contact-information-block"></div>\n<!-- /wp:woocommerce/checkout-contact-information-block -->\n\n<!-- wp:woocommerce/checkout-shipping-method-block -->\n<div class="wp-block-woocommerce-checkout-shipping-method-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-method-block -->\n\n<!-- wp:woocommerce/checkout-pickup-options-block -->\n<div class="wp-block-woocommerce-checkout-pickup-options-block"></div>\n<!-- /wp:woocommerce/checkout-pickup-options-block -->\n\n<!-- wp:woocommerce/checkout-shipping-address-block -->\n<div class="wp-block-woocommerce-checkout-shipping-address-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-address-block -->\n\n<!-- wp:woocommerce/checkout-billing-address-block -->\n<div class="wp-block-woocommerce-checkout-billing-address-block"></div>\n<!-- /wp:woocommerce/checkout-billing-address-block -->\n\n<!-- wp:woocommerce/checkout-shipping-methods-block -->\n<div class="wp-block-woocommerce-checkout-shipping-methods-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-methods-block -->\n\n<!-- wp:woocommerce/checkout-payment-block -->\n<div class="wp-block-woocommerce-checkout-payment-block"></div>\n<!-- /wp:woocommerce/checkout-payment-block -->\n\n<!-- wp:woocommerce/checkout-additional-information-block -->\n<div class="wp-block-woocommerce-checkout-additional-information-block"></div>\n<!-- /wp:woocommerce/checkout-additional-information-block -->\n\n<!-- wp:woocommerce/checkout-order-note-block -->\n<div class="wp-block-woocommerce-checkout-order-note-block"></div>\n<!-- /wp:woocommerce/checkout-order-note-block -->\n\n<!-- wp:woocommerce/checkout-terms-block -->\n<div class="wp-block-woocommerce-checkout-terms-block"></div>\n<!-- /wp:woocommerce/checkout-terms-block -->\n\n<!-- wp:woocommerce/checkout-actions-block -->\n<div class="wp-block-woocommerce-checkout-actions-block"></div>\n<!-- /wp:woocommerce/checkout-actions-block --></div>\n<!-- /wp:woocommerce/checkout-fields-block -->\n\n<!-- wp:woocommerce/checkout-totals-block -->\n<div class="wp-block-woocommerce-checkout-totals-block"><!-- wp:woocommerce/checkout-order-summary-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-block"><!-- wp:woocommerce/checkout-order-summary-cart-items-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-cart-items-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-cart-items-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-fee-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-fee-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-discount-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-discount-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/checkout-order-summary-block --></div>\n<!-- /wp:woocommerce/checkout-totals-block --></div>\n<!-- /wp:woocommerce/checkout -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2024-10-01 07:48:36', '2024-10-01 07:48:36', '', 0, 'http://localhost/crossthreads/site/checkout/', 0, 'page', '', 0),
(284, 1, '2024-10-01 07:48:38', '2024-10-01 07:48:38', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2024-10-01 07:48:38', '2024-10-01 07:48:38', '', 0, 'http://localhost/crossthreads/site/my-account/', 0, 'page', '', 0),
(285, 1, '2024-10-01 10:45:24', '2024-10-01 10:45:24', '<!-- wp:paragraph -->\r\n<p><b>This is a sample page.</b></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Overview</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Additional non-returnable items:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul>\r\n<li>Gift cards</li>\r\n<li>Downloadable software products</li>\r\n<li>Some health and personal care items</li>\r\n</ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>To complete your return, we require a receipt or proof of purchase.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Please do not send your purchase back to the manufacturer.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>There are certain situations where only partial refunds are granted:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul>\r\n<li>Book with obvious signs of use</li>\r\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\r\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\r\n<li>Any item that is returned more than 30 days after delivery</li>\r\n</ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Refunds</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h3 class="wp-block-heading">Late or missing refunds</h3>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h3 class="wp-block-heading">Sale items</h3>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Exchanges</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Gifts</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Shipping returns</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>To return your product, you should mail your product to: {physical address}.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Need help?</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Contact us at {email} for questions related to refunds and returns.</p>\r\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'publish', 'closed', 'closed', '', 'refund_returns', '', '', '2024-10-01 10:45:24', '2024-10-01 10:45:24', '', 0, 'http://localhost/crossthreads/site/?page_id=285', 0, 'page', '', 0),
(287, 1, '2024-10-01 08:12:33', '2024-10-01 08:12:33', 'It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Organic Linen Shirt', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the', 'publish', 'open', 'closed', '', 'organic-linen-shirt', '', '', '2024-10-01 09:15:09', '2024-10-01 09:15:09', '', 0, 'http://localhost/crossthreads/site/?post_type=product&#038;p=287', 0, 'product', '', 0),
(288, 1, '2024-10-01 08:11:37', '2024-10-01 08:11:37', '', 'img-five', '', 'inherit', 'open', 'closed', '', 'img-five', '', '', '2024-10-01 08:11:37', '2024-10-01 08:11:37', '', 287, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/img-five.jpg', 0, 'attachment', 'image/jpeg', 0),
(289, 1, '2024-10-01 09:11:40', '2024-10-01 09:11:40', 'It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Organic Linen Shirt', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the', 'inherit', 'closed', 'closed', '', '287-autosave-v1', '', '', '2024-10-01 09:11:40', '2024-10-01 09:11:40', '', 287, 'http://localhost/crossthreads/site/?p=289', 0, 'revision', '', 0),
(290, 1, '2024-10-01 09:44:32', '2024-10-01 09:44:32', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Footer Policy Section', 'footer_policy_section', 'publish', 'closed', 'closed', '', 'field_66fbc3e473ad4', '', '', '2024-10-01 09:44:32', '2024-10-01 09:44:32', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=290', 5, 'acf-field', '', 0),
(291, 1, '2024-10-01 09:44:32', '2024-10-01 09:44:32', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Icons and Content', 'footer_icons', 'publish', 'closed', 'closed', '', 'field_66fbc41673ad6', '', '', '2024-10-01 10:39:16', '2024-10-01 10:39:16', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=291', 6, 'acf-field', '', 0),
(292, 1, '2024-10-01 09:44:32', '2024-10-01 09:44:32', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Icon Image', 'f_icon', 'publish', 'closed', 'closed', '', 'field_66fbc41673ad7', '', '', '2024-10-01 09:44:32', '2024-10-01 09:44:32', '', 291, 'http://localhost/crossthreads/site/?post_type=acf-field&p=292', 0, 'acf-field', '', 0),
(293, 1, '2024-10-01 09:44:32', '2024-10-01 09:44:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'f_icon_title', 'publish', 'closed', 'closed', '', 'field_66fbc41673ad8', '', '', '2024-10-01 09:44:32', '2024-10-01 09:44:32', '', 291, 'http://localhost/crossthreads/site/?post_type=acf-field&p=293', 1, 'acf-field', '', 0),
(294, 1, '2024-10-01 09:44:33', '2024-10-01 09:44:33', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'f_icon_content', 'publish', 'closed', 'closed', '', 'field_66fbc46a73ad9', '', '', '2024-10-01 09:44:33', '2024-10-01 09:44:33', '', 291, 'http://localhost/crossthreads/site/?post_type=acf-field&p=294', 2, 'acf-field', '', 0),
(295, 1, '2024-10-01 09:46:08', '2024-10-01 09:46:08', '', 'icon-five', '', 'inherit', 'open', 'closed', '', 'icon-five', '', '', '2024-10-01 09:46:08', '2024-10-01 09:46:08', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/icon-five.svg', 0, 'attachment', 'image/svg+xml', 0),
(296, 1, '2024-10-01 09:46:27', '2024-10-01 09:46:27', '', 'icon-seven', '', 'inherit', 'open', 'closed', '', 'icon-seven', '', '', '2024-10-01 09:46:27', '2024-10-01 09:46:27', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/icon-seven.svg', 0, 'attachment', 'image/svg+xml', 0),
(297, 1, '2024-10-01 09:46:29', '2024-10-01 09:46:29', '', 'icon-six', '', 'inherit', 'open', 'closed', '', 'icon-six', '', '', '2024-10-01 09:46:29', '2024-10-01 09:46:29', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/icon-six.svg', 0, 'attachment', 'image/svg+xml', 0),
(298, 1, '2024-10-01 10:34:10', '2024-10-01 10:34:10', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Social Media Icon', 'ft_social_media', 'publish', 'closed', 'closed', '', 'field_66fbcfa782b0e', '', '', '2024-10-01 10:39:16', '2024-10-01 10:39:16', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&#038;p=298', 8, 'acf-field', '', 0),
(299, 1, '2024-10-01 10:34:11', '2024-10-01 10:34:11', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Icon', 'soc_icon', 'publish', 'closed', 'closed', '', 'field_66fbcfe082b0f', '', '', '2024-10-01 10:34:11', '2024-10-01 10:34:11', '', 298, 'http://localhost/crossthreads/site/?post_type=acf-field&p=299', 0, 'acf-field', '', 0),
(300, 1, '2024-10-01 10:34:11', '2024-10-01 10:34:11', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Link', 'soc_link', 'publish', 'closed', 'closed', '', 'field_66fbd00a82b10', '', '', '2024-10-01 10:34:11', '2024-10-01 10:34:11', '', 298, 'http://localhost/crossthreads/site/?post_type=acf-field&p=300', 1, 'acf-field', '', 0),
(301, 1, '2024-10-01 10:39:16', '2024-10-01 10:39:16', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Social Media Section', 'social_media_section', 'publish', 'closed', 'closed', '', 'field_66fbd05566974', '', '', '2024-10-01 10:39:16', '2024-10-01 10:39:16', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=301', 7, 'acf-field', '', 0),
(302, 1, '2024-10-01 10:39:16', '2024-10-01 10:39:16', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Copyright Settings', 'copyright_settings', 'publish', 'closed', 'closed', '', 'field_66fbd0b266977', '', '', '2024-10-01 10:39:16', '2024-10-01 10:39:16', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=302', 9, 'acf-field', '', 0),
(303, 1, '2024-10-01 10:39:17', '2024-10-01 10:39:17', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Copyright Text', 'copyright_text', 'publish', 'closed', 'closed', '', 'field_66fbd0c766978', '', '', '2024-10-01 10:39:17', '2024-10-01 10:39:17', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=303', 10, 'acf-field', '', 0),
(304, 1, '2024-10-01 10:39:17', '2024-10-01 10:39:17', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Footer Links', 'footer_links', 'publish', 'closed', 'closed', '', 'field_66fbd0f166979', '', '', '2024-10-01 10:39:17', '2024-10-01 10:39:17', '', 8, 'http://localhost/crossthreads/site/?post_type=acf-field&p=304', 11, 'acf-field', '', 0),
(305, 1, '2024-10-01 10:39:17', '2024-10-01 10:39:17', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Page Title', 'ft_page_title', 'publish', 'closed', 'closed', '', 'field_66fbd1156697a', '', '', '2024-10-01 10:39:17', '2024-10-01 10:39:17', '', 304, 'http://localhost/crossthreads/site/?post_type=acf-field&p=305', 0, 'acf-field', '', 0),
(306, 1, '2024-10-01 10:39:17', '2024-10-01 10:39:17', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";s:0:"";s:8:"taxonomy";s:0:"";s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Page Url', 'ft_page_url', 'publish', 'closed', 'closed', '', 'field_66fbd1236697b', '', '', '2024-10-01 10:39:17', '2024-10-01 10:39:17', '', 304, 'http://localhost/crossthreads/site/?post_type=acf-field&p=306', 1, 'acf-field', '', 0),
(307, 1, '2024-10-01 10:40:52', '2024-10-01 10:40:52', '', 'insta', '', 'inherit', 'open', 'closed', '', 'insta', '', '', '2024-10-01 10:40:52', '2024-10-01 10:40:52', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/insta.svg', 0, 'attachment', 'image/svg+xml', 0),
(308, 1, '2024-10-01 10:41:32', '2024-10-01 10:41:32', '', 'fb', '', 'inherit', 'open', 'closed', '', 'fb', '', '', '2024-10-01 10:41:32', '2024-10-01 10:41:32', '', 0, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/fb.svg', 0, 'attachment', 'image/svg+xml', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(309, 1, '2024-10-01 10:45:24', '2024-10-01 10:45:24', '<!-- wp:paragraph -->\r\n<p><b>This is a sample page.</b></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Overview</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Additional non-returnable items:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul>\r\n<li>Gift cards</li>\r\n<li>Downloadable software products</li>\r\n<li>Some health and personal care items</li>\r\n</ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>To complete your return, we require a receipt or proof of purchase.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Please do not send your purchase back to the manufacturer.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>There are certain situations where only partial refunds are granted:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul>\r\n<li>Book with obvious signs of use</li>\r\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\r\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\r\n<li>Any item that is returned more than 30 days after delivery</li>\r\n</ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Refunds</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h3 class="wp-block-heading">Late or missing refunds</h3>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h3 class="wp-block-heading">Sale items</h3>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Exchanges</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Gifts</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Shipping returns</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>To return your product, you should mail your product to: {physical address}.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<h2>Need help?</h2>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Contact us at {email} for questions related to refunds and returns.</p>\r\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'inherit', 'closed', 'closed', '', '285-revision-v1', '', '', '2024-10-01 10:45:24', '2024-10-01 10:45:24', '', 285, 'http://localhost/crossthreads/site/?p=309', 0, 'revision', '', 0),
(310, 1, '2024-10-01 10:45:57', '2024-10-01 10:45:57', '<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Who we are</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost/crossthreads/site.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Comments</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Media</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Cookies</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Who we share your data with</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">How long we retain your data</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:paragraph -->\r\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">What rights you have over your data</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\r\n<!-- /wp:paragraph -->\r\n<!-- wp:heading -->\r\n<h2 class="wp-block-heading">Where your data is sent</h2>\r\n<!-- /wp:heading -->\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\r\n<!-- /wp:paragraph -->\r\n', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2024-10-01 10:45:57', '2024-10-01 10:45:57', '', 3, 'http://localhost/crossthreads/site/?p=310', 0, 'revision', '', 0),
(311, 1, '2024-10-01 11:35:04', '2024-10-01 11:35:04', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'inherit', 'closed', 'closed', '', '284-autosave-v1', '', '', '2024-10-01 11:35:04', '2024-10-01 11:35:04', '', 284, 'http://localhost/crossthreads/site/?p=311', 0, 'revision', '', 0),
(312, 1, '2024-10-08 09:03:36', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-10-08 09:03:36', '0000-00-00 00:00:00', '', 0, 'http://localhost/crossthreads/site/?p=312', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(21, 2, 0),
(22, 2, 0),
(23, 2, 0),
(24, 2, 0),
(25, 2, 0),
(109, 1, 0),
(163, 1, 0),
(260, 3, 0),
(261, 3, 0),
(262, 3, 0),
(263, 3, 0),
(287, 4, 0),
(287, 18, 0),
(287, 22, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 5),
(3, 3, 'nav_menu', '', 0, 4),
(4, 4, 'product_type', '', 0, 1),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_type', '', 0, 0),
(7, 7, 'product_type', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_visibility', '', 0, 0),
(16, 16, 'product_visibility', '', 0, 0),
(17, 17, 'product_cat', '', 0, 0),
(18, 18, 'product_cat', '', 0, 1),
(19, 19, 'product_cat', '', 0, 0),
(20, 20, 'product_cat', '', 0, 0),
(21, 21, 'product_cat', '', 0, 0),
(22, 22, 'product_cat', '', 18, 1),
(23, 23, 'product_cat', '', 18, 0),
(24, 24, 'product_cat', '', 19, 0),
(25, 25, 'product_cat', '', 19, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 18, 'order', '0'),
(2, 18, 'display_type', ''),
(3, 18, 'thumbnail_id', '0'),
(4, 19, 'order', '0'),
(5, 19, 'display_type', ''),
(6, 19, 'thumbnail_id', '0'),
(7, 20, 'order', '0'),
(8, 20, 'display_type', ''),
(9, 20, 'thumbnail_id', '0'),
(10, 21, 'order', '0'),
(11, 21, 'display_type', ''),
(12, 21, 'thumbnail_id', '0'),
(13, 22, 'order', '0'),
(14, 22, 'display_type', ''),
(15, 22, 'thumbnail_id', '0'),
(16, 23, 'order', '0'),
(17, 23, 'display_type', ''),
(18, 23, 'thumbnail_id', '0'),
(19, 24, 'order', '0'),
(20, 24, 'display_type', ''),
(21, 24, 'thumbnail_id', '0'),
(22, 25, 'order', '0'),
(23, 25, 'display_type', ''),
(24, 25, 'thumbnail_id', '0'),
(25, 18, 'product_count_product_cat', '1'),
(26, 22, 'product_count_product_cat', '1') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Header Menu', 'header-menu', 0),
(3, 'Footer Menu', 'footer-menu', 0),
(4, 'simple', 'simple', 0),
(5, 'grouped', 'grouped', 0),
(6, 'variable', 'variable', 0),
(7, 'external', 'external', 0),
(8, 'exclude-from-search', 'exclude-from-search', 0),
(9, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(10, 'featured', 'featured', 0),
(11, 'outofstock', 'outofstock', 0),
(12, 'rated-1', 'rated-1', 0),
(13, 'rated-2', 'rated-2', 0),
(14, 'rated-3', 'rated-3', 0),
(15, 'rated-4', 'rated-4', 0),
(16, 'rated-5', 'rated-5', 0),
(17, 'Cloths', 'cloths', 0),
(18, 'Men', 'men', 0),
(19, 'Women', 'women', 0),
(20, 'Kids', 'kids', 0),
(21, 'Wellness', 'wellness', 0),
(22, 'Shirts', 'shirts', 0),
(23, 'Kurtha', 'kurtha', 0),
(24, 'Tops', 'tops', 0),
(25, 'Bottoms', 'bottoms', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin@crossthreads'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"92bb003bee3eac1953f4bb1c6731383c14152a1a8a02430d82b4aa3a4a9cf833";a:4:{s:10:"expiration";i:1727948171;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:5:"login";i:1726738571;}s:64:"30a5d86458661475c0b7fe7ccd42a57e2fbb6bf37d60bf2452ee318078a8318c";a:4:{s:10:"expiration";i:1728897194;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36";s:5:"login";i:1727687594;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '312'),
(19, 1, '_yoast_wpseo_profile_updated', '1726244377'),
(20, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(21, 1, 'wp_user-settings-time', '1727767156'),
(22, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(23, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:19:"add-post-type-blogs";i:1;s:23:"add-post-type-divisions";i:2;s:12:"add-post_tag";}'),
(24, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:81:"acf-group_66f6eab8e1dc0,wpseo_meta,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(25, 1, 'screen_layout_page', '2'),
(28, 1, 'nav_menu_recently_edited', '3'),
(29, 1, 'wp_yoast_notifications', 'a:3:{i:0;a:2:{s:7:"message";s:488:"<p><strong>Huge SEO Issue: You&#039;re blocking access to robots.</strong> If you want search engines to show this site in their results, you must <a href="http://localhost/crossthreads/site/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility. <button type="button" id="robotsmessage-dismiss-button" class="button-link hide-if-no-js" data-nonce="81a87b7b4f">I don&#039;t want this site to show in the search results.</button></p>";s:7:"options";a:10:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-search-engines-discouraged";s:7:"user_id";i:1;s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}i:1;a:2:{s:7:"message";s:208:"You&#039;ve added a new type of content. We recommend that you review the corresponding <a href="http://localhost/crossthreads/site/wp-admin/admin.php?page=wpseo_page_settings">Search appearance settings</a>.";s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:25:"content-types-made-public";s:7:"user_id";i:1;s:5:"nonce";N;s:8:"priority";d:0.8;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}i:2;a:2:{s:7:"message";s:466:"It looks like you aren\'t using our <strong>Yoast WooCommerce SEO addon</strong>. <a href="https://yoa.st/1o0?php_version=8.0&platform=wordpress&platform_version=6.6.2&software=free&software_version=23.5&days_active=25&user_language=en_US&screen=wp-migrate-db" aria-label="More information about Yoast WooCommerce SEO" target="_blank" rel="noopener noreferrer">Upgrade today</a> to unlock more tools and SEO features to make your products stand out in search results.";s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:44:"wpseo-suggested-plugin-yoast-woocommerce-seo";s:7:"user_id";i:1;s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:15:"install_plugins";}s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}}'),
(30, 1, '_woocommerce_tracks_anon_id', 'woo:Senzh6R+mKyvSu2+GaztMIrz'),
(31, 1, 'wc_last_active', '1728345600'),
(32, 1, 'meta-box-order_product', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:84:"submitdiv,postimagediv,woocommerce-product-images,product_catdiv,tagsdiv-product_tag";s:6:"normal";s:55:"woocommerce-product-data,wpseo_meta,slugdiv,postexcerpt";s:8:"advanced";s:0:"";}'),
(33, 1, 'screen_layout_product', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin@crossthreads', '$P$By.ETnwnBG/6nz8e4dh.S/PUyJCFyk.', 'admincrossthreads', 'divya@artemasdigital.com', 'http://localhost/crossthreads/site', '2024-09-13 15:51:52', '', 0, 'admin@crossthreads') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_note_actions`
#

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;


#
# Table structure of table `wp_wc_admin_note_actions`
#

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_note_actions`
#
INSERT INTO `wp_wc_admin_note_actions` ( `action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(1, 1, 'notify-refund-returns-page', 'Edit page', 'http://localhost/crossthreads/site/wp-admin/post.php?post=285&action=edit', 'actioned', '', NULL, NULL),
(84, 57, 'day-after-first-product', 'Learn more', 'https://woocommerce.com/document/woocommerce-customizer/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(85, 58, 'view-payment-gateways', 'Learn more', 'https://woocommerce.com/product-category/woocommerce-extensions/payment-gateways/?utm_medium=product', 'actioned', '', NULL, NULL),
(86, 59, 'tracking-opt-in', 'Activate usage tracking', '', 'actioned', '', NULL, NULL),
(87, 2, 'wayflyer_bnpl_q4_2021', 'Level up with funding', 'https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021', 'actioned', '', NULL, NULL),
(88, 3, 'wc_shipping_mobile_app_usps_q4_2021', 'Get WooCommerce Shipping', 'https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021', 'actioned', '', NULL, NULL),
(89, 4, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'actioned', '', NULL, NULL),
(90, 5, 'optimizing-the-checkout-flow', 'Learn more', 'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow', 'actioned', '', NULL, NULL),
(91, 6, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', '', NULL, NULL),
(92, 7, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', '', NULL, NULL),
(93, 8, 'get-started', 'Get started', 'https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started', 'actioned', '', NULL, NULL),
(94, 9, 'update-wc-subscriptions-3-0-15', 'View latest version', 'http://localhost/crossthreads/site/wp-admin/&page=wc-addons&section=helper', 'actioned', '', NULL, NULL),
(95, 10, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', '', NULL, NULL),
(96, 13, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(97, 14, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(98, 15, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(99, 15, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(100, 16, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(101, 16, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(102, 17, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(103, 17, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(104, 18, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(105, 18, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(106, 19, 'share-feedback', 'Share feedback', 'https://automattic.survey.fm/store-management', 'unactioned', '', NULL, NULL),
(107, 20, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(108, 20, 'woocommerce-core-paypal-march-2022-dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(109, 21, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(110, 21, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(111, 22, 'pinterest_03_2022_update', 'Update Instructions', 'https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3', 'actioned', '', NULL, NULL),
(112, 23, 'store_setup_survey_survey_q2_2022_share_your_thoughts', 'Tell us how it’s going', 'https://automattic.survey.fm/store-setup-survey-2022', 'actioned', '', NULL, NULL),
(113, 24, 'needs-update-eway-payment-gateway-rin-action-button-2022-12-20', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(114, 24, 'needs-update-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(115, 25, 'updated-eway-payment-gateway-rin-action-button-2022-12-20', 'See all updates', 'http://localhost/crossthreads/site/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(116, 25, 'updated-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(117, 26, 'share-navigation-survey-feedback', 'Share feedback', 'https://automattic.survey.fm/new-ecommerce-plan-navigation', 'actioned', '', NULL, NULL),
(118, 27, 'woopay-beta-merchantrecruitment-activate-04MAY23', 'Activate WooPay', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(119, 27, 'woopay-beta-merchantrecruitment-activate-learnmore-04MAY23', 'Learn More', 'https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-activate-learnmore-04MAY23', 'unactioned', '', NULL, NULL),
(120, 28, 'woocommerce-wcpay-march-2023-update-needed-button', 'See Blog Post', 'https://developer.woocommerce.com/2023/03/23/critical-vulnerability-detected-in-woocommerce-payments-what-you-need-to-know', 'unactioned', '', NULL, NULL),
(121, 28, 'woocommerce-wcpay-march-2023-update-needed-dismiss-button', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(122, 29, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'Simplify my payments', 'https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_no_wcpay', 'actioned', '', NULL, NULL),
(123, 30, 'extension-settings', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(124, 30, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(125, 31, 'woopay-beta-merchantrecruitment-update-WCPay-04MAY23', 'Update WooCommerce Payments', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(126, 31, 'woopay-beta-merchantrecruitment-update-activate-04MAY23', 'Activate WooPay', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(127, 32, 'woopay-beta-existingmerchants-noaction-documentation-27APR23', 'Documentation', 'https://woocommerce.com/document/woopay-merchant-documentation/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-existingmerchants-noaction-documentation-27APR23', 'actioned', '', NULL, NULL),
(128, 33, 'woopay-beta-existingmerchants-update-WCPay-27APR23', 'Update WooCommerce Payments', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'actioned', '', NULL, NULL),
(129, 34, 'woopay-beta-merchantrecruitment-short-activate-04MAY23', 'Activate WooPay', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(130, 34, 'woopay-beta-merchantrecruitment-short-activate-learnmore-04MAY23', 'Learn More', 'https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-04MAY23', 'actioned', '', NULL, NULL),
(131, 35, 'woopay-beta-merchantrecruitment-short-update-WCPay-04MAY23', 'Update WooCommerce Payments', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(132, 35, 'woopay-beta-merchantrecruitment-short-update-activate-04MAY23', 'Activate WooPay', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(133, 36, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTA', 'Activate WooPay Test A', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(134, 36, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'Learn More', 'https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'unactioned', '', NULL, NULL),
(135, 37, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTB', 'Activate WooPay Test B', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(136, 37, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'Learn More', 'https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'unactioned', '', NULL, NULL),
(137, 38, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTC', 'Activate WooPay Test C', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(138, 38, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTC', 'Learn More', 'https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTC', 'unactioned', '', NULL, NULL),
(139, 39, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTD', 'Activate WooPay Test D', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(140, 39, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTD', 'Learn More', 'https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTD', 'unactioned', '', NULL, NULL),
(141, 40, 'woopay-beta-merchantrecruitment-short-activate-button-09MAY23', 'Activate WooPay', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(142, 40, 'woopay-beta-merchantrecruitment-short-activate-learnmore-button2-09MAY23', 'Learn More', 'https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-button2-09MAY23', 'unactioned', '', NULL, NULL),
(143, 41, 'woopay-beta-merchantrecruitment-short-update-WCPay-09MAY23', 'Update WooCommerce Payments', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(144, 41, 'woopay-beta-merchantrecruitment-short-update-activate-09MAY23', 'Activate WooPay', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(145, 42, 'woocommerce-WCSubscriptions-June-2023-updated-needed-Plugin-Settings', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(146, 42, 'woocommerce-WCSubscriptions-June-2023-updated-needed-dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(147, 43, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(148, 43, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(149, 44, 'woocommerce-WCOPC-June-2023-updated-needed', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'actioned', '', NULL, NULL),
(150, 44, 'woocommerce-WCOPC-June-2023-updated-needed', 'Dismiss', 'http://localhost/crossthreads/site/wp-admin/#', 'actioned', '', NULL, NULL),
(151, 45, 'woocommerce-WCGC-July-2023-update-needed', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(152, 45, 'woocommerce-WCGC-July-2023-update-needed', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(153, 46, 'learn-more', 'Learn more', 'https://woocommerce.com/document/fedex/?utm_medium=product&utm_source=inbox_note&utm_campaign=learn-more#july-2023-api-outage', 'unactioned', '', NULL, NULL),
(154, 47, 'plugin-list', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(155, 47, 'dismiss', 'Dismiss', 'http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-admin', 'actioned', '', NULL, NULL),
(156, 48, 'woocommerce-WCStripe-Aug-2023-update-needed', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/update-core.php?', 'unactioned', '', NULL, NULL),
(157, 48, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(158, 49, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(159, 50, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(160, 51, 'avalara_q3-2023_noAvaTax', 'Automate my sales tax', 'https://woocommerce.com/products/woocommerce-avatax/?utm_source=inbox_note&utm_medium=product&utm_campaign=avalara_q3-2023_noAvaTax', 'unactioned', '', NULL, NULL),
(161, 52, 'woocommerce-usermeta-Sept2023-productvendors', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/plugins.php', 'unactioned', '', NULL, NULL),
(162, 52, 'dismiss', 'Dismiss', 'http://localhost/crossthreads/site/wp-admin/#', 'actioned', '', NULL, NULL),
(163, 53, 'woocommerce-STRIPE-Oct-2023-update-needed', 'See available updates', 'http://localhost/crossthreads/site/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(164, 53, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(165, 54, 'amazon-mcf-review-button-2023-12-07', 'Leave a review', 'https://woocommerce.com/products/woocommerce-amazon-fulfillment/?review&utm_source=inbox_note&utm_medium=product&utm_campaign=amazon-mcf-review-button-2023-12-07', 'actioned', '', NULL, NULL),
(166, 54, 'amazon-mcf-support-button-2023-12-07', 'Request support', 'https://woocommerce.com/my-account/contact-support/?utm_source=inbox_note&utm_medium=product&utm_campaign=amazon-mcf-support-button-2023-12-07', 'actioned', '', NULL, NULL),
(167, 55, 'view_docs', 'Learn about Deposit schedules', 'https://woocommerce.com/document/woopayments/deposits/deposit-schedule/?utm_source=inbox_note&utm_medium=product&utm_campaign=view_docs#available-funds', 'unactioned', '', NULL, NULL),
(168, 56, 'stripe_securityupdate_q4_2024_click', 'Review and update', 'https://woocommerce.com/document/stripe/admin-experience/updated-requirements-for-stripe-plugin-mid-2024/?utm_source=inbox_note&utm_medium=product&utm_campaign=stripe_securityupdate_q4_2024_click', 'unactioned', '', NULL, NULL) ;

#
# End of data contents of table `wp_wc_admin_note_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_notes`
#

DROP TABLE IF EXISTS `wp_wc_admin_notes`;


#
# Table structure of table `wp_wc_admin_notes`
#

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT 0,
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_notes`
#
INSERT INTO `wp_wc_admin_notes` ( `note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `is_read`, `icon`) VALUES
(1, 'wc-refund-returns-page', 'info', 'en_US', 'Setup a Refund and Returns Policy page to boost your store\'s credibility.', 'We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.', '[]', 'unactioned', 'woocommerce-core', '2024-10-01 07:48:54', NULL, 0, 'plain', '', 0, 0, 'info'),
(2, 'wayflyer_bnpl_q4_2021', 'marketing', 'en_US', 'Grow your business with funding through Wayflyer', 'Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:00', NULL, 0, 'plain', '', 0, 0, 'info'),
(3, 'wc_shipping_mobile_app_usps_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href="https://woocommerce.com/woocommerce-shipping/">WooCommerce Shipping</a> – all directly from your mobile device!', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:01', NULL, 0, 'plain', '', 0, 0, 'info'),
(4, 'your-first-product', 'info', 'en_US', 'Your first product', 'That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href="https://href.li/?https://woocommerce.com/shipping" target="_blank">WooCommerce Shipping</a>.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:01', NULL, 0, 'plain', '', 0, 0, 'info'),
(5, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:02', NULL, 0, 'plain', '', 0, 0, 'info'),
(6, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:02', NULL, 0, 'plain', '', 0, 0, 'info'),
(7, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:02', NULL, 0, 'plain', '', 0, 0, 'info'),
(8, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:02', NULL, 0, 'plain', '', 0, 0, 'info'),
(9, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href="https://woocommerce.com/my-dashboard">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href="https://woocommerce.com/my-account/create-a-ticket/">open a ticket</a>.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:02', NULL, 0, 'plain', '', 0, 0, 'info'),
(10, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:03', NULL, 0, 'plain', '', 0, 0, 'info'),
(11, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:03', NULL, 0, 'plain', '', 0, 0, 'info'),
(12, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:03', NULL, 0, 'plain', '', 0, 0, 'info'),
(13, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:04', NULL, 0, 'plain', '', 0, 0, 'info'),
(14, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">latest PayPal today</a> to continue to receive support and updates.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:04', NULL, 0, 'plain', '', 0, 0, 'info'),
(15, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:04', NULL, 0, 'plain', '', 0, 0, 'info'),
(16, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:04', NULL, 0, 'plain', '', 0, 0, 'info'),
(17, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:05', NULL, 0, 'plain', '', 0, 0, 'info'),
(18, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:05', NULL, 0, 'plain', '', 0, 0, 'info'),
(19, 'habit-moment-survey', 'marketing', 'en_US', 'We’re all ears! Share your experience so far with WooCommerce', 'We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(20, 'woocommerce-core-paypal-march-2022-updated', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal Payments</a> to accept PayPal.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(21, 'woocommerce-core-paypal-march-2022-updated-nopp', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(22, 'pinterest_03_2022_update', 'marketing', 'en_US', 'Your Pinterest for WooCommerce plugin is out of date!', 'Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(23, 'store_setup_survey_survey_q2_2022', 'survey', 'en_US', 'How is your store setup going?', 'Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.', '[]', 'unactioned', 'woocommerce.com', '2024-10-08 09:03:43', NULL, 0, 'plain', '', 0, 0, 'info'),
(24, 'needs-update-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'Security vulnerability patched in WooCommerce Eway Gateway', 'In response to a potential vulnerability identified in WooCommerce Eway Gateway versions 3.1.0 to 3.5.0, we’ve worked to deploy security fixes and have released an updated version.\r\nNo external exploits have been detected, but we recommend you update to your latest supported version 3.1.26, 3.2.3, 3.3.1, 3.4.6, or 3.5.1', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:09', NULL, 0, 'plain', '', 0, 0, 'info'),
(25, 'updated-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'WooCommerce Eway Gateway has been automatically updated', 'Your store is now running the latest secure version of WooCommerce Eway Gateway. We worked with the WordPress Plugins team to deploy a software update to stores running WooCommerce Eway Gateway (versions 3.1.0 to 3.5.0) in response to a security vulnerability that was discovered.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:10', NULL, 0, 'plain', '', 0, 0, 'info'),
(26, 'ecomm-wc-navigation-survey-2023', 'info', 'en_US', 'Navigating WooCommerce on WordPress.com', 'We are improving the WooCommerce navigation on WordPress.com and would love your help to make it better! Please share your experience with us in this 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:10', NULL, 0, 'plain', '', 0, 0, 'info'),
(27, 'woopay-beta-merchantrecruitment-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'WooPay, a new express checkout feature built into WooCommerce Payments, is now available —and we’re inviting you to be one of the first to try it. \r\n<br><br>\r\nBoost conversions by offering your customers a simple, secure way to pay with a single click.\r\n<br><br>\r\nGet started in seconds.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:11', NULL, 0, 'plain', '', 0, 0, 'info'),
(28, 'woocommerce-wcpay-march-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Payments', '<strong>Your store requires a security update for WooCommerce Payments</strong>. Please update to the latest version of WooCommerce Payments immediately to address a potential vulnerability discovered on March 22. For more information on how to update, visit this WooCommerce Developer Blog Post.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:11', NULL, 0, 'plain', '', 0, 0, 'info'),
(29, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'marketing', 'en_US', 'Accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone and WooCommerce Payments is quick, secure, and simple to set up — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(30, 'woocommerce-WCPreOrders-april-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Pre-Orders extension', '<strong>Your store requires a security update for the WooCommerce Pre-Orders extension</strong>. Please update the WooCommerce Pre-Orders extension immediately to address a potential vulnerability discovered on April 11.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(31, 'woopay-beta-merchantrecruitment-update-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'WooPay, a new express checkout feature built into WooCommerce Payments, is now available — and you’re invited to try it. \r\n<br /><br />\r\nBoost conversions by offering your customers a simple, secure way to pay with a single click.\r\n<br /><br />\r\nUpdate WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(32, 'woopay-beta-existingmerchants-noaction-27APR23', 'info', 'en_US', 'WooPay is back!', 'Thanks for previously trying WooPay, the express checkout feature built into WooCommerce Payments. We’re excited to announce that WooPay availability has resumed. No action is required on your part.\r\n<br /><br />\r\nYou can now continue boosting conversions by offering your customers a simple, secure way to pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:13', NULL, 0, 'plain', '', 0, 0, 'info'),
(33, 'woopay-beta-existingmerchants-update-27APR23', 'info', 'en_US', 'WooPay is back!', 'Thanks for previously trying WooPay, the express checkout feature built into WooCommerce Payments. We’re excited to announce that WooPay availability has resumed.\r\n<br /><br />\r\n\r\nUpdate to the latest WooCommerce Payments version to continue boosting conversions by offering your customers a simple, secure way to pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:13', NULL, 0, 'plain', '', 0, 0, 'info'),
(34, 'woopay-beta-merchantrecruitment-short-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:14', NULL, 0, 'plain', '', 0, 0, 'info'),
(35, 'woopay-beta-merchantrecruitment-short-update-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, our new express checkout feature. <br>Boost conversions by letting customers pay with a single click. <br><br>Update to the latest version of WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:14', NULL, 0, 'plain', '', 0, 0, 'info'),
(36, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTA', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:14', NULL, 0, 'plain', '', 0, 0, 'info'),
(37, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTB', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:14', NULL, 0, 'plain', '', 0, 0, 'info'),
(38, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTC', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:15', NULL, 0, 'plain', '', 0, 0, 'info'),
(39, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTD', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:15', NULL, 0, 'plain', '', 0, 0, 'info'),
(40, 'woopay-beta-merchantrecruitment-short-09MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:16', NULL, 0, 'plain', '', 0, 0, 'info'),
(41, 'woopay-beta-merchantrecruitment-short-update-09MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, our new express checkout feature. <br>Boost conversions by letting customers pay with a single click. <br><br>Update to the latest version of WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:17', NULL, 0, 'plain', '', 0, 0, 'info'),
(42, 'woocommerce-WCSubscriptions-June-2023-updated-needed', 'marketing', 'en_US', 'Action required: Security update of WooCommerce Subscriptions', '<strong>Your store requires a security update for the WooCommerce Subscriptions plugin</strong>. Please update the WooCommerce Subscriptions plugin immediately to address a potential vulnerability.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:17', NULL, 0, 'plain', '', 0, 0, 'info'),
(43, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Returns and Warranty Requests extension', '<strong>Your store requires a security update for the Returns and Warranty Requests extension</strong>.  Please update to the latest version of the WooCommerce Returns and Warranty Requests extension immediately to address a potential vulnerability discovered on May 31.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:17', NULL, 0, 'plain', '', 0, 0, 'info'),
(44, 'woocommerce-WCOPC-June-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce One Page Checkout', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce One Page Checkout extension</strong>. The fix for this vulnerability was released for this extension on June 13th. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:18', NULL, 0, 'plain', '', 0, 0, 'info'),
(45, 'woocommerce-WCGC-July-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce GoCardless Extension', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce GoCardless extension</strong>. The fix for this vulnerability was released on July 4th. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:18', NULL, 0, 'plain', '', 0, 0, 'info'),
(46, 'woocommerce-shipping-fedex-api-outage-2023-07-16', 'warning', 'en_US', 'Scheduled FedEx API outage — July 2023', 'On July 16 there will be a full outage of the FedEx API from 04:00 to 08:00 AM UTC. Due to planned maintenance by FedEx, you\'ll be unable to provide FedEx shipping rates during this time. Follow the link below for more information and recommendations on how to minimize impact.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:19', NULL, 0, 'plain', '', 0, 0, 'info'),
(47, 'wcship-2023-07-hazmat-update-needed', 'update', 'en_US', 'Action required: USPS HAZMAT compliance update for WooCommerce Shipping & Tax extension', '<strong>Your store requires an update for the WooCommerce Shipping extension</strong>. Please update to the latest version of the WooCommerce Shipping &amp; Tax extension immediately to ensure compliance with new USPS HAZMAT rules currently in effect.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:20', NULL, 0, 'plain', '', 0, 0, 'info'),
(48, 'woocommerce-WCStripe-Aug-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Stripe plugin', '<strong>Your shop requires an important security update for the  WooCommerce Stripe plugin</strong>. The fix for this vulnerability was released on July 31. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:20', NULL, 0, 'plain', '', 0, 0, 'info'),
(49, 'woocommerce-WCStripe-Aug-2023-security-updated', 'update', 'en_US', 'Security update of WooCommerce Stripe plugin', '<strong>Your store has been updated to the latest secure version of the WooCommerce Stripe plugin</strong>. This update was released on July 31.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:20', NULL, 0, 'plain', '', 0, 0, 'info'),
(50, 'woocommerce-WooPayments-Aug-2023-security-updated', 'update', 'en_US', 'Security update of WooPayments (WooCommerce Payments) plugin', '<strong>Your store has been updated to the more secure version of WooPayments (WooCommerce Payments)</strong>. This update was released on July 31.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:21', NULL, 0, 'plain', '', 0, 0, 'info'),
(51, 'avalara_q3-2023_noAvaTax', 'marketing', 'en_US', 'Automatically calculate VAT in real time', 'Take the effort out of determining tax rates and sell confidently across borders with automated tax management from Avalara AvaTax— including built-in VAT calculation when you sell into or across the EU and UK. Save time and stay compliant when you let Avalara do the heavy lifting.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:21', NULL, 0, 'plain', '', 0, 0, 'info'),
(52, 'woocommerce-usermeta-Sept2023-productvendors', 'update', 'en_US', 'Your store requires a security update', '<strong>Your shop needs an update to address a vulnerability in WooCommerce.</strong> The fix was released on Sept 15. Please update WooCommerce to the latest version immediately. <a href="https://developer.woocommerce.com/2023/09/16/woocommerce-vulnerability-reintroduced-from-7-0-1/" />Read our developer update</a> for more information.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:21', NULL, 0, 'plain', '', 0, 0, 'info'),
(53, 'woocommerce-STRIPE-Oct-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Stripe Gateway', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce Stripe Gateway</strong>. The fix for this vulnerability was released on October 17. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:23', NULL, 0, 'plain', '', 0, 0, 'info'),
(54, 'amazon-mcf-reviews-2023-12-07', 'marketing', 'en_US', 'Enjoying Amazon MCF for WooCommerce?', 'We\'re Never Settle, the developers behind Amazon MCF for WooCommerce, and would be deeply honored to have your review. Reviews help immensely as other users can learn how MCF can solve their needs too! Not happy or need help? Please reach out for support and we’d love to make things right!', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:24', NULL, 0, 'plain', '', 0, 0, 'info'),
(55, 'remove_estimated_deposits_2024', 'marketing', 'en_US', 'Estimated deposits are going away', 'To provide more accurate deposit information and support the expansion of instant deposits, estimated deposit details will no longer be available in WooPayments. We recommend upgrading to the latest version of WooPayments for more detailed balance status information.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:25', NULL, 0, 'plain', '', 0, 0, 'info'),
(56, 'stripe_securityupdate_q3_2024', 'update', 'en_US', 'Security update required for your Stripe extension', 'To continue securely accepting payments, you must update your Stripe extension to at least version 8.6, re-authenticate, and turn on the new checkout experience. Review the documentation for instructions on how to make the necessary changes from your WooCommerce dashboard.', '[]', 'pending', 'woocommerce.com', '2024-10-01 07:49:26', NULL, 0, 'plain', '', 0, 0, 'info'),
(57, 'wc-admin-customizing-product-catalog', 'info', 'en_US', 'How to customize your product catalog', 'You want your product catalog and images to look great and align with your brand. This guide will give you all the tips you need to get your products looking great in your store.', '[]', 'unactioned', 'woocommerce-admin', '2024-10-08 09:03:30', NULL, 0, 'plain', '', 0, 0, 'info'),
(58, 'wc-admin-onboarding-payments-reminder', 'info', 'en_US', 'Start accepting payments on your store!', 'Take payments with the provider that’s right for you - choose from 100+ payment gateways for WooCommerce.', '[]', 'unactioned', 'woocommerce-admin', '2024-10-08 09:03:31', NULL, 0, 'plain', '', 0, 0, 'info'),
(59, 'wc-admin-usage-tracking-opt-in', 'info', 'en_US', 'Help WooCommerce improve with usage tracking', 'Gathering usage data allows us to improve WooCommerce. Your store will be considered as we evaluate new features, judge the quality of an update, or determine if an improvement makes sense. You can always visit the <a href="http://localhost/crossthreads/site/wp-admin/admin.php?page=wc-settings&#038;tab=advanced&#038;section=woocommerce_com" target="_blank">Settings</a> and choose to stop sharing data. <a href="https://woocommerce.com/usage-tracking?utm_medium=product" target="_blank">Read more</a> about what data we collect.', '[]', 'unactioned', 'woocommerce-admin', '2024-10-08 09:03:31', NULL, 0, 'plain', '', 0, 0, 'info') ;

#
# End of data contents of table `wp_wc_admin_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_category_lookup`
#

DROP TABLE IF EXISTS `wp_wc_category_lookup`;


#
# Table structure of table `wp_wc_category_lookup`
#

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_category_lookup`
#
INSERT INTO `wp_wc_category_lookup` ( `category_tree_id`, `category_id`) VALUES
(17, 17),
(18, 18),
(18, 22),
(18, 23),
(19, 19),
(19, 24),
(19, 25),
(20, 20),
(21, 21),
(22, 22),
(23, 23),
(24, 24),
(25, 25) ;

#
# End of data contents of table `wp_wc_category_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_customer_lookup`
#

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;


#
# Table structure of table `wp_wc_customer_lookup`
#

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_customer_lookup`
#

#
# End of data contents of table `wp_wc_customer_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_download_log`
#

DROP TABLE IF EXISTS `wp_wc_download_log`;


#
# Table structure of table `wp_wc_download_log`
#

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_download_log`
#

#
# End of data contents of table `wp_wc_download_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_addresses`
#

DROP TABLE IF EXISTS `wp_wc_order_addresses`;


#
# Table structure of table `wp_wc_order_addresses`
#

CREATE TABLE `wp_wc_order_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `address_type` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `first_name` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `last_name` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `address_1` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `address_2` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `city` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `state` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `postcode` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `email` varchar(320) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_type_order_id` (`address_type`,`order_id`),
  KEY `order_id` (`order_id`),
  KEY `email` (`email`(191)),
  KEY `phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_addresses`
#

#
# End of data contents of table `wp_wc_order_addresses`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_coupon_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;


#
# Table structure of table `wp_wc_order_coupon_lookup`
#

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_coupon_lookup`
#

#
# End of data contents of table `wp_wc_order_coupon_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_operational_data`
#

DROP TABLE IF EXISTS `wp_wc_order_operational_data`;


#
# Table structure of table `wp_wc_order_operational_data`
#

CREATE TABLE `wp_wc_order_operational_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `created_via` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `woocommerce_version` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `prices_include_tax` tinyint(1) DEFAULT NULL,
  `coupon_usages_are_counted` tinyint(1) DEFAULT NULL,
  `download_permission_granted` tinyint(1) DEFAULT NULL,
  `cart_hash` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `new_order_email_sent` tinyint(1) DEFAULT NULL,
  `order_key` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `order_stock_reduced` tinyint(1) DEFAULT NULL,
  `date_paid_gmt` datetime DEFAULT NULL,
  `date_completed_gmt` datetime DEFAULT NULL,
  `shipping_tax_amount` decimal(26,8) DEFAULT NULL,
  `shipping_total_amount` decimal(26,8) DEFAULT NULL,
  `discount_tax_amount` decimal(26,8) DEFAULT NULL,
  `discount_total_amount` decimal(26,8) DEFAULT NULL,
  `recorded_sales` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `order_key` (`order_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_operational_data`
#

#
# End of data contents of table `wp_wc_order_operational_data`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_product_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;


#
# Table structure of table `wp_wc_order_product_lookup`
#

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_product_lookup`
#

#
# End of data contents of table `wp_wc_order_product_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_stats`
#

DROP TABLE IF EXISTS `wp_wc_order_stats`;


#
# Table structure of table `wp_wc_order_stats`
#

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_stats`
#

#
# End of data contents of table `wp_wc_order_stats`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_tax_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;


#
# Table structure of table `wp_wc_order_tax_lookup`
#

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT 0,
  `order_tax` double NOT NULL DEFAULT 0,
  `total_tax` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_tax_lookup`
#

#
# End of data contents of table `wp_wc_order_tax_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_orders`
#

DROP TABLE IF EXISTS `wp_wc_orders`;


#
# Table structure of table `wp_wc_orders`
#

CREATE TABLE `wp_wc_orders` (
  `id` bigint(20) unsigned NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `currency` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `tax_amount` decimal(26,8) DEFAULT NULL,
  `total_amount` decimal(26,8) DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `billing_email` varchar(320) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_created_gmt` datetime DEFAULT NULL,
  `date_updated_gmt` datetime DEFAULT NULL,
  `parent_order_id` bigint(20) unsigned DEFAULT NULL,
  `payment_method` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_method_title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `customer_note` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `date_created` (`date_created_gmt`),
  KEY `customer_id_billing_email` (`customer_id`,`billing_email`(171)),
  KEY `billing_email` (`billing_email`(191)),
  KEY `type_status_date` (`type`,`status`,`date_created_gmt`),
  KEY `parent_order_id` (`parent_order_id`),
  KEY `date_updated` (`date_updated_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_orders`
#

#
# End of data contents of table `wp_wc_orders`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_orders_meta`
#

DROP TABLE IF EXISTS `wp_wc_orders_meta`;


#
# Table structure of table `wp_wc_orders_meta`
#

CREATE TABLE `wp_wc_orders_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meta_key_value` (`meta_key`(100),`meta_value`(82)),
  KEY `order_id_meta_key_meta_value` (`order_id`,`meta_key`(100),`meta_value`(82))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_orders_meta`
#

#
# End of data contents of table `wp_wc_orders_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_attributes_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_attributes_lookup`;


#
# Table structure of table `wp_wc_product_attributes_lookup`
#

CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_attributes_lookup`
#

#
# End of data contents of table `wp_wc_product_attributes_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_download_directories`
#

DROP TABLE IF EXISTS `wp_wc_product_download_directories`;


#
# Table structure of table `wp_wc_product_download_directories`
#

CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_download_directories`
#
INSERT INTO `wp_wc_product_download_directories` ( `url_id`, `url`, `enabled`) VALUES
(1, 'file://E:/XAMPP/htdocs/crossthreads/site/wp-content/uploads/woocommerce_uploads/', 1),
(2, 'http://localhost/crossthreads/site/wp-content/uploads/woocommerce_uploads/', 1) ;

#
# End of data contents of table `wp_wc_product_download_directories`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_meta_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;


#
# Table structure of table `wp_wc_product_meta_lookup`
#

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `global_unique_id` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`),
  KEY `sku` (`sku`(50))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_meta_lookup`
#
INSERT INTO `wp_wc_product_meta_lookup` ( `product_id`, `sku`, `global_unique_id`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(287, '', '', 0, 0, '49.9900', '49.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', '') ;

#
# End of data contents of table `wp_wc_product_meta_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_rate_limits`
#

DROP TABLE IF EXISTS `wp_wc_rate_limits`;


#
# Table structure of table `wp_wc_rate_limits`
#

CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `rate_limit_expiry` bigint(20) unsigned NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_rate_limits`
#

#
# End of data contents of table `wp_wc_rate_limits`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_reserved_stock`
#

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;


#
# Table structure of table `wp_wc_reserved_stock`
#

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT 0,
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_reserved_stock`
#

#
# End of data contents of table `wp_wc_reserved_stock`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_tax_rate_classes`
#

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;


#
# Table structure of table `wp_wc_tax_rate_classes`
#

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_tax_rate_classes`
#
INSERT INTO `wp_wc_tax_rate_classes` ( `tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate') ;

#
# End of data contents of table `wp_wc_tax_rate_classes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_webhooks`
#

DROP TABLE IF EXISTS `wp_wc_webhooks`;


#
# Table structure of table `wp_wc_webhooks`
#

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT 0,
  `pending_delivery` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_webhooks`
#

#
# End of data contents of table `wp_wc_webhooks`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_api_keys`
#

#
# End of data contents of table `wp_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_attribute_taxonomies`
#

#
# End of data contents of table `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_log`
#

DROP TABLE IF EXISTS `wp_woocommerce_log`;


#
# Table structure of table `wp_woocommerce_log`
#

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_log`
#

#
# End of data contents of table `wp_woocommerce_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_itemmeta`
#

#
# End of data contents of table `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_items`
#

#
# End of data contents of table `wp_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wp_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;


#
# Table structure of table `wp_woocommerce_payment_tokens`
#

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokens`
#

#
# End of data contents of table `wp_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_sessions`
#
INSERT INTO `wp_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(2, '1', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:767:"a:28:{s:2:"id";s:1:"1";s:13:"date_modified";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:24:"divya@artemasdigital.com";s:7:"address";s:0:"";s:9:"address_1";s:0:"";s:9:"address_2";s:0:"";s:4:"city";s:0:"";s:5:"state";s:2:"TN";s:8:"postcode";s:0:"";s:7:"country";s:2:"IN";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_1";s:0:"";s:18:"shipping_address_2";s:0:"";s:13:"shipping_city";s:0:"";s:14:"shipping_state";s:2:"TN";s:17:"shipping_postcode";s:0:"";s:16:"shipping_country";s:2:"IN";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:9:"meta_data";a:0:{}}";}', 1728551059) ;

#
# End of data contents of table `wp_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wp_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `zone_id` (`zone_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_locations`
#

#
# End of data contents of table `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wp_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_methods`
#

#
# End of data contents of table `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;


#
# Table structure of table `wp_woocommerce_shipping_zones`
#

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zones`
#

#
# End of data contents of table `wp_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT 0,
  `tax_rate_shipping` int(1) NOT NULL DEFAULT 1,
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rates`
#

#
# End of data contents of table `wp_woocommerce_tax_rates`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable`
#

DROP TABLE IF EXISTS `wp_yoast_indexable`;


#
# Table structure of table `wp_yoast_indexable`
#

CREATE TABLE `wp_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permalink_hash` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_sub_type` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `breadcrumb_title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT 0,
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT 0,
  `is_robots_noindex` tinyint(1) DEFAULT 0,
  `is_robots_nofollow` tinyint(1) DEFAULT 0,
  `is_robots_noarchive` tinyint(1) DEFAULT 0,
  `is_robots_noimageindex` tinyint(1) DEFAULT 0,
  `is_robots_nosnippet` tinyint(1) DEFAULT 0,
  `twitter_title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_description` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_source` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_description` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_source` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_meta` mediumtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  `language` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_page_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_article_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT 0,
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL,
  `inclusive_language_score` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable`
#
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`, `inclusive_language_score`) VALUES
(1, 'http://localhost/crossthreads/site/', '35:560473a4a7879134cd7ef43c2184d71c', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%page%% %%sep%% %%sitedesc%%', '', 'Home', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '%%sitename%%', '', '', '0', NULL, NULL, NULL, NULL, NULL, '2024-09-13 16:19:15', '2024-10-01 10:45:59', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 10:45:57', '2024-09-13 15:51:53', NULL),
(2, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Page not found %%sep%% %%sitename%%', NULL, 'Error 404: Page not found', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-13 16:19:39', '2024-09-27 15:48:30', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL),
(3, NULL, NULL, NULL, 'system-page', 'search-result', NULL, NULL, 'You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-19 09:34:10', '2024-09-27 16:44:43', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL),
(4, NULL, NULL, NULL, 'date-archive', NULL, NULL, NULL, '%%date%% %%page%% %%sep%% %%sitename%%', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-19 09:34:10', '2024-09-27 16:44:43', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL),
(5, 'http://localhost/crossthreads/site/privacy-policy/', '50:6f593d10b4976f4803d90d206b150208', 3, 'post', 'page', 1, 0, NULL, NULL, 'Privacy Policy', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-09-19 09:34:10', '2024-10-01 10:45:58', 1, NULL, NULL, NULL, NULL, 0, 3, 2, '2024-10-01 10:45:57', '2024-09-13 15:51:53', 0),
(7, 'http://localhost/crossthreads/site/sample-page/', '47:6d0c4296497ee7e6ba76b95dece86f4b', 2, 'post', 'page', 1, 0, NULL, NULL, 'Sample Page', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-09-19 09:34:10', '2024-09-27 15:48:35', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-09-13 15:51:53', '2024-09-13 15:51:53', 0),
(8, 'http://localhost/crossthreads/site/?p=1', '39:6f21fd3122d1c515410848b77f058d40', 1, 'post', 'post', 1, 0, NULL, NULL, 'Hello world!', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-09-19 09:34:10', '2024-09-30 09:15:04', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-09-30 09:15:02', '2024-09-13 15:51:53', 0),
(9, NULL, NULL, NULL, 'post-type-archive', 'blogs', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Blogs', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-19 09:34:10', '2024-09-19 15:04:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL),
(11, 'http://localhost/crossthreads/site/category/uncategorized/', '58:cb398070890470ef9efbd7c401448f2f', 1, 'term', 'category', NULL, NULL, NULL, NULL, 'Uncategorized', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-09-19 09:34:10', '2024-09-27 16:44:45', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-09-13 15:51:53', '2024-09-13 15:51:53', NULL),
(12, 'http://localhost/crossthreads/site/', '35:560473a4a7879134cd7ef43c2184d71c', 5, 'post', 'page', 1, 0, NULL, NULL, 'Home', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner.webp', NULL, '7', 'featured-image', NULL, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner.webp', '7', 'featured-image', '{"width":1920,"height":1094,"filesize":1847584,"url":"http:\\/\\/localhost\\/crossthreads\\/site\\/wp-content\\/uploads\\/2024\\/09\\/banner.webp","path":"E:\\\\XAMPP\\\\htdocs\\\\crossthreads\\\\site\\/wp-content\\/uploads\\/2024\\/09\\/banner.webp","size":"full","id":7,"alt":"","pixels":2100480,"type":"image\\/webp"}', 0, NULL, NULL, '2024-09-19 09:36:48', '2024-09-29 08:13:49', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-09-29 08:13:24', '2024-09-19 09:36:56', 0),
(13, NULL, NULL, NULL, 'post-type-archive', 'blogs', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Blogs', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-19 09:42:28', '2024-09-27 21:14:19', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL),
(15, 'http://localhost/crossthreads/site/blogs/', '41:285f4d892ff972b13f8d6c96f477b6cd', NULL, 'post-type-archive', 'blogs', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Blogs', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-27 16:44:44', '2024-09-27 16:44:44', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL),
(17, 'http://localhost/crossthreads/site/about-us/', '44:4fa881c34d57523b0b31e0bd6f0e3eb2', 81, 'post', 'page', 1, 0, NULL, NULL, 'About Us', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-two.jpg', NULL, '88', 'featured-image', NULL, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-two.jpg', '88', 'featured-image', '{"width":1920,"height":1024,"filesize":937152,"url":"http:\\/\\/localhost\\/crossthreads\\/site\\/wp-content\\/uploads\\/2024\\/09\\/banner-two.jpg","path":"E:\\\\XAMPP\\\\htdocs\\\\crossthreads\\\\site\\/wp-content\\/uploads\\/2024\\/09\\/banner-two.jpg","size":"full","id":88,"alt":"","pixels":1966080,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-09-27 18:57:01', '2024-09-30 09:41:37', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-09-30 09:41:25', '2024-09-27 18:57:01', 0),
(18, 'http://localhost/crossthreads/site/?p=109', '41:ef6930047f2b0d1f5046a1c03da0067a', 109, 'post', 'post', 1, 0, NULL, NULL, 'group_66f90eb83c79d', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-29 08:24:24', '2024-09-29 08:24:24', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(19, 'http://localhost/crossthreads/site/?p=163', '41:02c12120375efd22883639f3b3fcd7d9', 163, 'post', 'post', 1, 0, NULL, NULL, 'group_66f90ed16a123', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-29 08:24:49', '2024-09-29 08:24:49', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(20, 'http://localhost/crossthreads/site/sustainability/', '50:58681d6cc3c9dbe64c2d961728f2a12f', 242, 'post', 'page', 1, 0, NULL, NULL, 'Sustainability', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/fashion-banner.jpg', NULL, '243', 'featured-image', NULL, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/fashion-banner.jpg', '243', 'featured-image', '{"width":1920,"height":760,"filesize":1754723,"url":"http:\\/\\/localhost\\/crossthreads\\/site\\/wp-content\\/uploads\\/2024\\/09\\/fashion-banner.jpg","path":"E:\\\\XAMPP\\\\htdocs\\\\crossthreads\\\\site\\/wp-content\\/uploads\\/2024\\/09\\/fashion-banner.jpg","size":"full","id":243,"alt":"","pixels":1459200,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-09-30 09:45:45', '2024-09-30 11:08:44', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-09-30 11:08:35', '2024-09-30 09:46:27', 0),
(21, 'http://localhost/crossthreads/site/contact/', '43:7003918838402925ffc4e4abf83cc04f', 258, 'post', 'page', 1, 0, NULL, NULL, 'Contact', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-two.jpg', NULL, '88', 'featured-image', NULL, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/banner-two.jpg', '88', 'featured-image', '{"width":1920,"height":1024,"filesize":937152,"url":"http:\\/\\/localhost\\/crossthreads\\/site\\/wp-content\\/uploads\\/2024\\/09\\/banner-two.jpg","path":"E:\\\\XAMPP\\\\htdocs\\\\crossthreads\\\\site\\/wp-content\\/uploads\\/2024\\/09\\/banner-two.jpg","size":"full","id":88,"alt":"","pixels":1966080,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-09-30 11:10:00', '2024-09-30 11:10:33', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-09-30 11:10:31', '2024-09-30 11:10:00', 0),
(22, 'http://localhost/crossthreads/site/sustainability-copy/', '55:ae2c511f545560563fc4e67d9f59f46d', 264, 'post', 'page', 1, 0, NULL, NULL, 'home1', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/fashion-banner.jpg', NULL, '243', 'featured-image', NULL, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/09/fashion-banner.jpg', '243', 'featured-image', '{"width":1920,"height":760,"filesize":1754723,"url":"http:\\/\\/localhost\\/crossthreads\\/site\\/wp-content\\/uploads\\/2024\\/09\\/fashion-banner.jpg","path":"E:\\\\XAMPP\\\\htdocs\\\\crossthreads\\\\site\\/wp-content\\/uploads\\/2024\\/09\\/fashion-banner.jpg","size":"full","id":243,"alt":"","pixels":1459200,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-09-30 11:15:21', '2024-09-30 11:15:54', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-09-30 11:15:53', '2024-09-30 11:15:21', 0),
(23, 'http://localhost/crossthreads/site/terms-and-conditions/', '56:e96362589d83ef1f92b262a2452737d7', 266, 'post', 'page', 1, 0, NULL, NULL, 'Terms and Conditions', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 06:55:15', '2024-10-01 07:25:04', 1, NULL, NULL, NULL, NULL, 0, 4, 2, '2024-10-01 07:25:03', '2024-10-01 06:55:20', 0),
(24, 'http://localhost/crossthreads/site/product-category/cloths/', '59:4a35e148e8c0746ec69796f4ad4ddb6e', 17, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Cloths', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 07:48:29', '2024-10-01 07:59:02', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 07:59:02', NULL, NULL),
(25, 'http://localhost/crossthreads/site/shop/', '40:2855642f54c786f2f81c9c6f68cfaaf9', 281, 'post', 'page', 1, 0, NULL, NULL, 'Shop', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 07:48:35', '2024-10-01 07:48:35', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 07:48:35', '2024-10-01 07:48:35', 0),
(26, 'http://localhost/crossthreads/site/cart-2/', '42:f94663e16c9f2314c78187c24a3dcc44', 282, 'post', 'page', 1, 0, NULL, NULL, 'Cart', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 07:48:36', '2024-10-01 07:48:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 07:48:36', '2024-10-01 07:48:36', 0),
(27, 'http://localhost/crossthreads/site/checkout/', '44:259d7dabf962001e15ce75ae507d85c0', 283, 'post', 'page', 1, 0, NULL, NULL, 'Checkout', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 07:48:37', '2024-10-01 07:48:37', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 07:48:36', '2024-10-01 07:48:36', 0),
(28, 'http://localhost/crossthreads/site/my-account/', '46:d32cce3290b8c29d502ee7788511e47b', 284, 'post', 'page', 1, 0, NULL, NULL, 'My account', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 07:48:38', '2024-10-01 07:48:38', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 07:48:38', '2024-10-01 07:48:38', 0),
(29, 'http://localhost/crossthreads/site/refund_returns/', '50:7ebd9be4b8a6cd53293f378eb0db56e5', 285, 'post', 'page', 1, 0, NULL, NULL, 'Refund and Returns Policy', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 60, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 07:48:38', '2024-10-01 10:45:26', 1, NULL, NULL, NULL, NULL, 0, 3, 2, '2024-10-01 10:45:24', '2024-10-01 10:45:24', 0),
(30, 'http://localhost/crossthreads/site/product-category/men/', '56:858acc2a4acbf01c1d4c80018aff7502', 18, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Men', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 08:00:36', '2024-10-01 09:15:13', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 09:15:09', NULL, NULL),
(31, 'http://localhost/crossthreads/site/product-category/women/', '58:95a7b4cd073b4325c938945232af01c2', 19, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Women', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 08:01:10', '2024-10-01 08:01:10', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 08:01:10', NULL, NULL),
(32, 'http://localhost/crossthreads/site/product-category/kids/', '57:b3390811b9b12a6087ca4cfeaea8aa68', 20, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Kids', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 08:01:33', '2024-10-01 08:01:34', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 08:01:34', NULL, NULL),
(33, 'http://localhost/crossthreads/site/product-category/wellness/', '61:ef7f527f35125dcb482ba27464e3ca26', 21, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Wellness', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 08:01:50', '2024-10-01 08:01:50', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 08:01:50', NULL, NULL),
(34, 'http://localhost/crossthreads/site/product-category/men/shirts/', '63:5c9e75580c26e8aef1e779d717f4aa91', 22, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Shirts', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 08:03:49', '2024-10-01 09:15:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-01 09:15:09', NULL, NULL),
(35, 'http://localhost/crossthreads/site/product-category/men/kurtha/', '63:6a77266db9d2789f673be890bd1ec908', 23, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Kurtha', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 08:04:12', '2024-10-01 08:04:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-01 08:04:13', NULL, NULL),
(36, 'http://localhost/crossthreads/site/product-category/women/tops/', '63:75be6d3f7d122e28cd659d886a24c21e', 24, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Tops', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 08:04:32', '2024-10-01 08:04:32', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-01 08:04:32', NULL, NULL),
(37, 'http://localhost/crossthreads/site/product-category/women/bottoms/', '66:724f3282debb164a07af4fdf7b485e15', 25, 'term', 'product_cat', NULL, NULL, NULL, NULL, 'Bottoms', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-01 08:04:56', '2024-10-01 08:04:57', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-01 08:04:57', NULL, NULL),
(38, 'http://localhost/crossthreads/site/product/organic-linen-shirt/', '63:ad1fb240888ed87772ea25a9b68f5daf', 287, 'post', 'product', 1, 0, NULL, NULL, 'Organic Linen Shirt', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 60, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/img-five.jpg', NULL, '288', 'featured-image', NULL, NULL, 'http://localhost/crossthreads/site/wp-content/uploads/2024/10/img-five.jpg', '288', 'featured-image', '{"width":568,"height":669,"filesize":163862,"url":"http:\\/\\/localhost\\/crossthreads\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-five.jpg","path":"E:\\\\XAMPP\\\\htdocs\\\\crossthreads\\\\site\\/wp-content\\/uploads\\/2024\\/10\\/img-five.jpg","size":"full","id":288,"alt":"","pixels":379992,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-10-01 08:10:31', '2024-10-01 09:15:13', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-10-01 09:15:09', '2024-10-01 08:12:33', 0),
(39, 'http://localhost/crossthreads/site/shop/', '40:2855642f54c786f2f81c9c6f68cfaaf9', NULL, 'post-type-archive', 'product', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Products', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-01 09:13:23', '2024-10-01 09:15:13', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-01 09:15:09', '2024-10-01 08:12:33', NULL) ;

#
# End of data contents of table `wp_yoast_indexable`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable_hierarchy`
#

DROP TABLE IF EXISTS `wp_yoast_indexable_hierarchy`;


#
# Table structure of table `wp_yoast_indexable_hierarchy`
#

CREATE TABLE `wp_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable_hierarchy`
#
INSERT INTO `wp_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(5, 0, 0, 1),
(7, 0, 0, 1),
(8, 0, 0, 1),
(11, 0, 0, 1),
(12, 0, 0, 1),
(17, 0, 0, 1),
(18, 0, 0, 1),
(19, 0, 0, 1),
(20, 0, 0, 1),
(21, 0, 0, 1),
(22, 0, 0, 1),
(23, 0, 0, 1),
(24, 0, 0, 1),
(25, 0, 0, 1),
(26, 0, 0, 1),
(27, 0, 0, 1),
(28, 0, 0, 1),
(29, 0, 0, 1),
(30, 0, 0, 1),
(31, 0, 0, 1),
(32, 0, 0, 1),
(33, 0, 0, 1),
(34, 30, 1, 1),
(35, 30, 1, 1),
(36, 31, 1, 1),
(37, 31, 1, 1),
(38, 0, 0, 1) ;

#
# End of data contents of table `wp_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_migrations`
#

DROP TABLE IF EXISTS `wp_yoast_migrations`;


#
# Table structure of table `wp_yoast_migrations`
#

CREATE TABLE `wp_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wp_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_migrations`
#
INSERT INTO `wp_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404'),
(24, '20230417083836') ;

#
# End of data contents of table `wp_yoast_migrations`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_primary_term`
#

DROP TABLE IF EXISTS `wp_yoast_primary_term`;


#
# Table structure of table `wp_yoast_primary_term`
#

CREATE TABLE `wp_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_primary_term`
#
INSERT INTO `wp_yoast_primary_term` ( `id`, `post_id`, `term_id`, `taxonomy`, `created_at`, `updated_at`, `blog_id`) VALUES
(1, 287, 18, 'product_cat', '2024-10-01 08:12:41', '2024-10-01 09:15:12', 1) ;

#
# End of data contents of table `wp_yoast_primary_term`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_yoast_seo_links`
#
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`, `indexable_id`, `target_indexable_id`, `height`, `width`, `size`, `language`, `region`) VALUES
(1, 'http://localhost/crossthreads/site/wp-admin/', 2, NULL, 'internal', 7, NULL, NULL, NULL, NULL, NULL, NULL) ;

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

